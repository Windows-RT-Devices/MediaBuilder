@echo off

REM ====== Set =========================================================================================================================================================

Set WinREConfigFilesStage=%1

If "%WinREConfigFilesStage%" == "" (
	goto ConfigFilesComplete
) else (
	goto %WinREConfigFilesStage%
)

:ConfigFiles

REM ====== Get required size of recovery partition =====================================================================================================================

REM For /f "USEBACKQ skip=3 tokens=1 delims=. " %%a IN (`""!CD!\Bin\Diruse\DIRUSE.EXE" /m "!MediaFolderPath!""`) DO (
REM 	Set RecoveryPartitionSize=%%a
REM 	Set /a RecoveryPartitionSize=%%a-256
REM )

For /f "tokens=1" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; \"{0:0}\" -f ((gci -force "'!MediaFolderPath!'" -Recurse -ErrorAction SilentlyContinue| measure Length -s).sum / 1MB)"') do (
	Set /a RecoveryPartitionSize=%%a-256
)

REM ====== Write CreatePartitions-UEFI.txt =============================================================================================================================

(
	echo clean
	echo convert gpt
	echo create partition primary size=310
	echo set id=DE94BBA4-06D1-4D40-A16A-BFD50179D6AC
	echo gpt attributes=0x8000000000000001
	echo format quick fs=ntfs label="Windows RE tools"
	echo assign letter=T
	echo create partition efi size=200
	echo format quick fs=fat32 label="System"
	echo assign letter=S
	echo create partition msr size=128
	echo create partition primary 
	echo shrink minimum=%RecoveryPartitionSize%
	echo gpt attributes=0x0000000000000000
	echo format quick fs=ntfs label="Windows"
	echo assign letter=W
	echo create partition primary 
	echo set id=de94bba4-06d1-4d40-a16a-bfd50179d6ac
	echo gpt attributes=0x8000000000000001
	echo format quick fs=ntfs label="Recovery image"
	echo assign letter=R
	echo rescan
	echo exit
) > "%MediaFolderPath%\sources\CreatePartitions-UEFI.txt"

REM ====== Write ResetConfig.xml =======================================================================================================================================

(
	echo ^<?xml version="1.0" encoding="utf-8"?^>
	echo ^<Reset^>
	echo     ^<SystemDisk^>
	echo         ^<MinSize^>5000^</MinSize^>
	echo         ^<DiskpartScriptPath^>CreatePartitions-UEFI.txt^</DiskpartScriptPath^>
	echo         ^<OSPartition^>4^</OSPartition^>
	echo         ^<RestoreFromIndex^>1^</RestoreFromIndex^>
	echo         ^<WindowsREPartition^>1^</WindowsREPartition^>
	echo         ^<WindowsREPath^>Recovery\WindowsRE^</WindowsREPath^>
	echo         ^<RecoveryImagePartition^>5^</RecoveryImagePartition^>
	echo         ^<RecoveryImagePath^>RecoveryImage^</RecoveryImagePath^>
	echo         ^<RecoveryImageIndex^>1^</RecoveryImageIndex^>
	echo     ^</SystemDisk^>
	echo ^</Reset^>
) > "%MediaFolderPath%\sources\ResetConfig.xml"

goto ConfigFilesComplete

REM ====== End =========================================================================================================================================================

:ConfigFilesComplete

If "%WinREConfigFilesStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "WinREConfigFilesStage="