@echo off

REM ====== Make Install Media ==========================================================================================================================================

Set MediaMode=%1
Set MediaLabel=%2
Set MediaSource=%3

If "%MediaMode%" == "MediaMenu" (
	goto MediaMenu
) else (
	goto MediaComplete
)

REM ====== Media =======================================================================================================================================================

:MediaMenu

If "!MBServiceFound-smphost!" == "False" goto MakeWinISOMediaSelect

:MakeWinUSBMediaSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
If "%WimFAT32Warning%" == "True" (
	If "%InstallESD%" == "True" (
		Set InstallFileExt=esd
	) else (
		Set InstallFileExt=wim
	)
	echo %White%Install.!InstallFileExt! is larger than the 4GB, files larger than 4GB can not be stored on a FAT32 volume.%ef%
	echo Skipping creation of USB Installation Media.
	Set WimFAT32Warning=
	goto MakeWinISOMediaSelect
)
Set MakeWinUSBMediaPrompt=

If "%SetupMode%" == "WimOnly" (
	Set USBMessage=Would you copy the selected files to USB ^(Non-bootable^) ^(Y/N^)? 
) else (
	Set USBMessage=Would you like to create USB Installation Media ^(Y/N^)? 
)

Set /p MakeWinUSBMediaPrompt=!USBMessage!
rem Set /p MakeWinUSBMediaPrompt=Would you like to create USB Installation Media (Y/N)? 
If /i "%MakeWinUSBMediaPrompt%"=="Y" goto USB
If /i "%MakeWinUSBMediaPrompt%"=="N" goto MakeWinISOMediaSelect
If "%MakeWinUSBMedia%" == "" goto MakeWinUSBMediaSelect

:MakeWinISOMediaSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
If "%SetupMode%" == "WimOnly" (
rem	echo %White%Selected output is WIM Files Only and is not bootable.%ef%
	echo %White%Selected output is not bootable.%ef%
	echo Skipping creation of ISO.
	Set SetupMode=
	goto MediaComplete
)
Set MakeWinISOMediaPrompt=
Set /p MakeWinISOMediaPrompt=Would you like to create an ISO image (Y/N)? 
If /i "%MakeWinISOMediaPrompt%"=="Y" goto ISO
If /i "%MakeWinISOMediaPrompt%"=="N" goto MediaComplete
If "%MakeWinISOMedia%" == "" goto MakeWinISOMediaSelect

Goto MediaComplete

REM ====== Make USB ====================================================================================================================================================

:USB

REM For /f "USEBACKQ skip=3 tokens=1 delims=. " %%a IN (`""!CD!\Bin\Diruse\DIRUSE.EXE" /m !MediaSource!"`) DO (
REM 	Set /a DriveSizeReq=%%a+256
REM )

For /f "tokens=1" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; \"{0:0}\" -f ((gci -force "'!MediaSource!'" -File -Recurse -ErrorAction SilentlyContinue| measure Length -s).sum / 1MB)"') do (
	Set /a DriveSizeReq=%%a+256
)

Set FAT32Check=True
Set /a FAT32Limit=32768

If "%USBInstallMediaFixedOnly%" == "True" (
	Set DriveTypes=$_.DriveType -eq 3
	Set DriveTypesText=Fixed Only
) else (
	Set DriveTypes=$_.DriveType -eq 3 -or $_.DriveType -eq 2
	Set DriveTypesText=Fixed ^& Removable
)

If exist "%CD%\Includes\Mod_USB.cmd" (
	Call "%CD%\Includes\Mod_USB.cmd" USBSelect
) else (
	echo.
	echo %red%Error: "%CD%\Includes\Mod_USB.cmd" not found.%ef%
	Set USBCancel=True
	Set USBSelected=False
)
If "!USBCancel!" == "True" goto MakeWinISOMediaSelect
If "!USBSelected!" == "True" goto MakeUSB
goto MediaComplete

:MakeUSB

:FormatUSBSelect
echo.
rem echo %red%Warning: All data on disk drive "%Destination%" will be lost^^!%ef%
echo %red%Warning: All data on !DriveName!, drive^(s^) "!PartitionsOnDrive!" will be lost^^!%ef%
Set FormatUSBPrompt=
Set /p FormatUSBPrompt=Proceed with Format (Y/N)? 
If /i "%FormatUSBPrompt%"=="Y" goto MakeUSB_Format
If /i "%FormatUSBPrompt%"=="N" goto MakeUSB_NoFormat
goto FormatUSBSelect

:MakeUSB_NoFormat
echo.
echo Aborting, "%Destination%" will not be formatted.
goto MakeWinISOMediaSelect

:MakeUSB_Format

If not exist "%TmpPath%\" md "%TmpPath%\"

Set DiskpartScript="%TmpPath%\DiskpartScript.txt"
(
	echo select volume=%Destination%
	echo clean
	echo convert mbr
If "!LargerThan32GB!"=="True" (
	echo create partition primary size=32768
	echo format fs=fat32 label=%MediaLabel% quick
	echo assign letter %Destination%
	echo active
rem	echo create partition primary size=!DriveSizeReq!
rem	echo format fs=fat32 label=%MediaLabel% quick
rem	echo assign letter %Destination%
rem	echo active
rem	echo create partition primary
rem	echo format fs=ntfs quick
rem	echo assign
) else (
	echo create partition primary
	echo format fs=fat32 label=%MediaLabel% quick
	echo assign letter %Destination%
	echo active
)
) > %DiskpartScript%

echo.
echo %white%Formatting "%Destination%".%ef%
echo Please wait.
diskpart /s %DiskpartScript% > nul

If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to format "%Destination%"...%ef%
	echo %red%DiskPart Error: "!=ExitCode!"%ef%
	goto MakeWinISOMediaSelect
) else (
	echo %green%Formatted "%Destination%".%ef%
)

echo.
echo %white%Setting boot code on "%Destination%".%ef%
echo Please wait..
"%CD%\Bin\BCDBoot\%PROCESSOR_ARCHITECTURE%\bootsect.exe" /nt60 %Destination% /force /mbr > nul
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to set the boot code on "%Destination%".%ef%
	echo %red%Bootsect Error: "!ErrorLevel!"%ef%
	goto MakeWinISOMediaSelect
) else (
	echo %green%Boot code on "%Destination%" set.%ef%
)

compact /u %MediaSource% > nul
If "!ErrorLevel!" NEQ "0" (
	echo.
	echo %red%Error: Failed to decompress...%ef%
	echo %red%Compact Error: "!ErrorLevel!"%ef%
	goto MakeWinISOMediaSelect
)

If not "%ShowUSBCopyProgress%" == "True" goto USBOldCopy

echo.
echo %white%Copying files to "%Destination%".%ef%
echo Please wait...
If "%UseCMDColours%" == "True" (
echo.
echo.
)
echo.
rem echo. 

Set MediaSourceTemp=%MediaSource:"=%

Set /a FileCount=0
For /f "tokens=*" %%a in ('dir !MediaSource! /s /b /a-d') do (
	Set /a FileCount+=1
)

Set /a DirCount=0
For /f "tokens=*" %%a in ('dir !MediaSource! /s /b /ad') do (
	Set /a DirCount+=1
)

Set /a DirCreate=0
For /f "tokens=*" %%a in ('dir !MediaSource! /s /b /ad') do (
	Set /a DirCreate+=1
	Set CurrentSourcePath=%%a
	Set "CurrentDestinationPath=!CurrentSourcePath:%MediaSourceTemp%=!"

	If "%UseCMDColours%" == "True" (
		echo !NL!^^
	)
	echo %Line3%%white%Creating Directory !DirCreate! of !DirCount!.%ef%
	If "%UseCMDColours%" == "True" (
		echo !NL!^^
	)
	echo %Line2%%Destination%!CurrentDestinationPath!

	If not exist "%Destination%!CurrentDestinationPath!" md "%Destination%!CurrentDestinationPath!"
	If !ErrorLevel! NEQ 0 (
		echo %red%Error: Failed to create directory "%Destination%!CurrentDestinationPath!".%ef%
		echo %red%Error: "!ErrorLevel!"%ef%
		goto MakeWinISOMediaSelect
	)
	rem timeout /nobreak /t 1 > nul
)

If "%UseCMDColours%" == "True" (
echo %Line2%
) else (
echo.
)
echo %Line2%%green%Directories successfully created on "%Destination%".%ef%
If "%UseCMDColours%" == "True" (
echo.
echo.
echo.
)
echo.

Set /a FileCopy=0
For /f "tokens=*" %%a in ('dir !MediaSource! /s /b /a-d') do (
	Set /a FileCopy+=1
	Set CurrentFileSourcePath=%%~dpa
	Set "CurrentFileDestinationPath=!CurrentFileSourcePath:%MediaSourceTemp%=!"

	If "%UseCMDColours%" == "True" (
		echo !NL!^^
	)
	echo %Line4%%white%Copying File !FileCopy! of !FileCount!.%ef%
	If "%UseCMDColours%" == "True" (
		echo !NL!^^
	)
	echo %Line2%%Destination%!CurrentFileDestinationPath!%%~nxa

rem	If not exist "%Destination%!CurrentFileDestinationPath!" md "%Destination%!CurrentFileDestinationPath!"

	attrib -s -h -r /s /d "%%a" > NUL 2>&1

	Copy /v /y /z "%%a" "%Destination%!CurrentFileDestinationPath!"
	If !ErrorLevel! NEQ 0 (
		echo %red%Error: Failed to copy files to "%Destination%".%ef%
		echo %red%Error: "!ErrorLevel!"%ef%
		goto MakeWinISOMediaSelect
	)
)

If "%UseCMDColours%" == "True" (
echo %Line1%%Line2%
) else (
echo.
)
rem If "%UseCMDColours%" == "True" echo %Line1%%Line2%
echo %Line2%%green%Files copied to "%Destination%".%ef%

Goto DiskPartCleanup

:USBOldCopy
echo.
echo %white%Copying files to "%Destination%".%ef%
echo Please wait...
xcopy /herky %MediaSource%\*.* %Destination%\ > nul
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to copy files to "%Destination%".%ef%
	echo %red%XCOPY Error: "!ErrorLevel!"%ef%
	goto MakeWinISOMediaSelect
) else (
	echo %green%Files copied to "%Destination%".%ef%
)

:DiskPartCleanup

del /F /Q %DiskpartScript% 1> nul
If exist %DiskpartScript% (
	echo.
	echo %red%Error: Failed to delete temporary DiskPart script...%ef%
	goto MakeWinISOMediaSelect
)

Goto MakeWinISOMediaSelect

REM ====== Create ISO image ============================================================================================================================================

:ISO

Set Destination="%OutputPath%\%MediaFolderName%.iso"

If not exist %Destination% goto ISO_OscdImg

:ISO_OverwriteSelect
echo.
echo %red%Warning: Destination file already exists...
echo %Destination%%ef%
Set OverwriteISOPrompt=
Set /p OverwriteISOPrompt=Would you like to overwrite it (Y/N)? 
If /i "%OverwriteISOPrompt%"=="Y" goto ISO_OverwriteDestinationFile
If /i "%OverwriteISOPrompt%"=="N" goto ISO_DestinationFileExists
goto ISO_OverwriteSelect

:ISO_DestinationFileExists
echo.
echo Aborting, existing file will not be overwritten...
goto MediaComplete

:ISO_OverwriteDestinationFile
echo.
del /F /Q %Destination% 1> nul
If exist %Destination% (
	echo %red%Error: Failed to overwrite file...%ef%
	goto MediaComplete
) else (
	echo %green%Overwriting existing file...%ef%
)

:ISO_OscdImg

Set Bootdata=%MediaSource:"=%
If exist %MediaSource%\boot\etfsboot.com (
	Set Bootdata=2#p0,e,b"%Bootdata%\boot\etfsboot.com"#pEF,e,b"%Bootdata%\efi\microsoft\boot\efisys.bin"
) else (
	Set Bootdata=1#pEF,e,b"%Bootdata%\efi\microsoft\boot\efisys.bin"
)

echo.
echo %white%Creating ISO.%ef%
echo Please wait....
echo.
"%CD%\bin\Oscdimg\%PROCESSOR_ARCHITECTURE%\oscdimg.exe" -bootdata:%Bootdata% -l%MediaLabel% -h -u1 -udfver102 %MediaSource% %Destination% > nul
echo.
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to create ISO...%ef%
	echo %red%%Destination%%ef%
	echo %red%OSCDIMG Error: "!ErrorLevel!"%ef%
) else (
	echo %green%ISO Created...%ef%
	echo %green%%Destination%%ef%
	If /i "!OpenFolderISO!" == "True" (
		If exist %Destination% (
			:ISOFolderSelect
			echo. %ef%
			Set /p OpenISOFolderPrompt=Would you like to open the containing folder ^(Y/N^)? 
			If /i "!OpenISOFolderPrompt!"=="Y" (
				explorer.exe /select,%Destination%
				goto MediaComplete
			)
			If /i "!OpenISOFolderPrompt!"=="N" goto MediaComplete
			goto ISOFolderSelect
		)
	)
)

Goto MediaComplete

REM ====== End =========================================================================================================================================================

:MediaComplete

If "%MediaMode%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)