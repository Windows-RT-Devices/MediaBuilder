@echo off
@setlocal enableextensions
@setlocal EnableDelayedExpansion
cls

Set /a MBVerNumber=254

Set MBName=Windows RT 8.1 IR5 Media Builder
Set MBVer=v%MBVerNumber:~0,1%.%MBVerNumber:~1,2%
Set MBDate=26-07-2024
@Title %MBName% - %MBVer%

REM
REM	This media builder can be maintained by updating the text files listed below:
REM
REM	\Download_Lists\Windows.txt:
REM	URL's to Windows RT 8.1 IR5 ESD Files.
REM	
REM	\Download_Lists\Windows_Updates.txt:
REM	URL�s to post Windows RT 8.1 IR5 Windows Updates including updates which can prevent the ability to jailbreak.
REM	
REM	Download_Lists\Windows_Updates_Jailbreak_Safe_Longhorn.txt:
REM	URL�s to post Windows RT 8.1 IR5 Windows Updates excluding those that disable the jailbreak from Longhorn.
REM
REM	\Download_Lists\Windows_Updates_Jailbreak_Safe_Myriachan.txt:
REM	URL�s to post Windows RT 8.1 IR5 Windows Updates excluding those that disable the jailbreak from Myriachan.
REM
REM	\Download_Lists\Windows_Updates_Update_3.txt:
REM	URL�s to Update 3/Start Menu Update only.
REM
REM	\Download_Lists\Windows_Updates_Servicing_Stack.txt:
REM	URL�s to Servicing Stack Updates that are applied and committed separately before applying other Windows Updates.
REM	These updates are the minimum required for Windows Update to work after installation. These updates are also common
REM	to all other update modes.
REM
REM	Microsoft apps included as standard with Windows RT 8.1 can be optionally updated. Although these are the latest 
REM	available versions, some may not be functional anymore due to the services they depend on being discontinued.
REM	Attempting to update or remove provisioneda pps in Windows RT 8.1 IR5 for Saudi Arabia, Bulgaria, Germany, Croatia,
REM	Hungary, Russia and Slovakia results in the following error:
REM
REM	"App packages (.appx) cannot be serviced on an offline image after a user has logged into the image."
REM
REM	App removal and update options are not offered if these languages are selected.
REM
REM	Updates for Office 2013 RT are currently not included as they cannot be applied via DISM and I am unsure if there 
REM	is a solution to include these updates due to the limitations of post install setup on Windows RT. For the moment
REM	Office Updates are included as a seperate package on the generated media that will require manual installation.
REM
REM	Drivers are currently included for these devices:
REM
REM	Microsoft Surface RT 
REM	Microsoft Surface 2
REM	Lenovo IdeaPad Yoga 11
REM	ASUS VivoTab RT
REM	Dell XPS 10
REM	Nokia Lumia 2520
REM	Samsung Ativ Tab
REM
REM	jwa4
REM	https://forum.xda-developers.com/t/windows-rt-8-1-ir5-media-builder.4184449/

REM ====== Network Drive/Share Check ===================================================================================================================================

If "%~d0" == "\\" (
	Set BuildAbort=True
)

"%SystemRoot%\System32\net.exe" use > NUL 2>&1
If "!ErrorLevel!" EQU "2" goto SkipMappedDriveCheck

"%SystemRoot%\System32\net.exe" use | "%SystemRoot%\System32\findstr.exe" /I /L /C:" %~d0 " >nul
If not "!ErrorLevel!" EQU "1" (
	Set BuildAbort=True
)

:SkipMappedDriveCheck

If "%BuildAbort%" == "True" (
	echo Error: Media Builder cannot be run from a mapped drive or network share.
	goto ExitNoTempClear
)

@cd /d "%~dp0"

REM ====== Check only one instance is running ==========================================================================================================================

9>&2 2>nul (Call :LockAndRestoreStdErr %* 8>>"%~f0") || (
	echo %red%Error: Only one instance allowed. >&2%ef%
)
goto ExitNoTempClear

:LockAndRestoreStdErr
Call :SingleInstance %* 2>&9
exit /b 0

:SingleInstance

9>&2 2>nul (call :LockAndRestoreStdErr1 %* 8>>"!CD!\Cleanup.cmd") || (
	echo %red%Error: Only one instance allowed. >&2%ef%
)
goto ExitNoTempClear

:LockAndRestoreStdErr1
call :SingleInstance1 %* 2>&9
exit /b 0

:SingleInstance1

REM ====== Checks ======================================================================================================================================================

Set MBFirstRun=True

:Start
setlocal

If /i "!MBFirstRun!" == "True" (
	endlocal & Set MBFirstRun=False
	setlocal & Set MBFirstRunInt=True
)

If exist "%CD%\Includes\Build_Common.cmd" (
	echo Please Wait...
	Call "%CD%\Includes\Build_Common.cmd" BuildCommon %~nx0
) else (
	echo %red%Error: File Missing...%ef%
	echo "!CD!\Includes\Build_Common.cmd"
	Set BuildAbort=True
)

If "%BuildRestart%"=="True" (
	cls
	endlocal
	goto Start
)

If "%BuildAbort%"=="True" goto ExitNoTempClear

REM ====== Menu Text ===================================================================================================================================================

If exist "%CD%\Download_Lists\Last_Updated" (
	Set /p WindowsUpdateListsUpdated=< "%CD%\Download_Lists\Last_Updated"
	For /f "tokens=1-2 delims=#" %%a in ("!WindowsUpdateListsUpdated!") do (
		Set WindowsUpdateListsRelease=%%a
		Set WindowsUpdateListsUpdated=%%b
	)
) else (
	Set WindowsUpdateListsRelease=Unknown Release
	Set WindowsUpdateListsUpdated=Unknown Date
)

Set NL=^


Set MenuText=%white%%ul%___________________________________________________%ef%!NL!^
!NL!^
%white%%MBName% %MBVer% - %MBDate%%ef%!NL!^
%white%%ul%___________________________________________________%ef% !NL!^
!NL!^
7-Zip - Copyright (C) 1999-2019, Igor Pavlov. !NL!^
DecryptESD - Copyright (C) 2017, Thomas Hounsell. !NL!^
GNU Wget - Copyright (C) 1996-2008, Free Software Foundation, Inc. !NL!^
QEMU - Copyright (C) 2003-2021 Fabrice Bellard and the QEMU Project developers. (Thanks to @x86corez ^& @driver1998)!NL!^
SetACL - Copyright (C) 2012, Helge Klein. !NL!^
tget - Copyright (C) 2024, sweetbbak. !NL!^
!NL!^
This media builder will download Windows RT 8.1 IR5, download and integrate the selected Windows Updates to !NL!^
%WindowsUpdateListsUpdated%, integrate drivers and generate custom installation media ready for use on the selected device. !NL!^
!NL!^
%red%The use of this media builder or the media it produces is entirely at your own risk.%ef% !NL!^
%ul%________________________________________________________________________________________________________________________%ef%

Set InfoBar=%info%  INFO                                INFO                                    INFO                                INFO  %ef%
Set WarningBar=%warn% WARNING                             WARNING                                WARNING                             WARNING %ef%

REM ====== Main Menu ===================================================================================================================================================

:MainMenu
cls

If exist "%CD%\Includes\Build_Preset.cmd" (
	Call "%CD%\Includes\Build_Preset.cmd" FindPreset
)

echo !MenuText!

If exist "%CD%\Includes\Mod_Media.cmd" (
	If exist "%CD%\Includes\Mod_Media_Rewrite.cmd" (
		Set ExistingMedia=W: Write Existing Installation Files
	) else (
		Set ExistingMedia=%black%%ef%
	)
) else (
	Set ExistingMedia=%black%%ef%
)

If exist "%CD%\Includes\Build_Settings.cmd" (
	Set SettingsText=S: Media Builder Settings
) else (
	Set SettingsText=%black%%ef%
)

If exist "%CD%\Includes\Build_Misc.cmd" (
	Set MiscText=M: Miscellaneous
) else (
	Set MiscText=%black%%ef%
)


If "%CreatePreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" MenuItemsDesc
) else (
	If exist "%CD%\Includes\Build_Preset.cmd" (
		Call "%CD%\Includes\Build_Preset.cmd" MenuItemsPreset
	) else (
			echo.
			echo %white%Options:%ef%	 %ExistingMedia%
			echo 		 %SettingsText%
			echo 		 %MiscText%
	)
)

echo.
echo %white%Select Device:%ef%	 1: Microsoft Surface RT		5: Dell XPS 10
echo			 2: Microsoft Surface 2			6: Nokia Lumia 2520
echo			 3: Lenovo IdeaPad Yoga 11		7: Samsung Ativ Tab
echo			 4: ASUS VivoTab RT			8: None (No Drivers)
echo.
If "%CreatePreset%" == "True" (
	echo			 E: %red%Exit Preset Mode%ef%
) else (
	echo			 E: %red%Exit%ef%				!%MBMessageColour%!%MBMessage%%ef%
)
echo.
Set /p Target=%white%Enter Selection: %ef%

:SkipTarget

If "%Target%"=="1" goto SurfaceRT
If "%Target%"=="2" goto Surface2
If "%Target%"=="3" goto Yoga11
If "%Target%"=="4" goto VivoTab
If "%Target%"=="5" goto XPS10
If "%Target%"=="6" goto Lumia2520
If "%Target%"=="7" goto ATIVTab
If "%Target%"=="8" goto Generic

rem If not "%CreatePreset%" == "True" If /i "%Target%"=="QEMU" goto QEMU

If not "%CreatePreset%" == "True" If exist "%CD%\Includes\Build_Misc.cmd" If /i "%Target%"=="M" (
	Call "%CD%\Includes\Build_Misc.cmd" MiscMenu
	If /i "!MiscTarget!" == "Q" (
		goto QEMU
	)
	If /i "!MiscTarget!" == "B" (
		Call "%CD%\Includes\Build_Common.cmd" ForceUpdateCheck %~nx0 True
	)
	cls
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

If /i "%Target%"=="E" (
	If "%CreatePreset%" == "True" (
		endlocal & Set SkipDriveCheckInt=True
		goto Start
	) else (
		goto Exit
	)
)

If exist "%CD%\Includes\Build_Preset.cmd" If /i "%Target%"=="C" (
	Call "%CD%\Includes\Build_Preset.cmd" CreatePreset
)

If exist "%CD%\Includes\Build_Preset.cmd" If /i "%Target%"=="D" (
	Call "%CD%\Includes\Build_Preset.cmd" DownloadPreset
	If "!DownloadPreset!" == "True" goto SkipTarget
)

If exist "%CD%\Includes\Build_Preset.cmd" If /i "%Target%"=="B" (
	Call "%CD%\Includes\Build_Preset.cmd" BuildPreset
	If "!BuildPreset!" == "True" goto SkipTarget
)

If not "%CreatePreset%" == "True" If exist "%CD%\Includes\Mod_Media.cmd" If exist "%CD%\Includes\Mod_Media_Rewrite.cmd" If /i "%Target%"=="W" (
	Call "%CD%\Includes\Mod_Media_Rewrite.cmd" Windows_Media_Select_Start
	If /i "!Windows_Media_Selection!" == "C" (
		cls
		endlocal & Set SkipDriveCheckInt=True
		goto Start
	)
	goto ReturnMainMenu
)

If not "%CreatePreset%" == "True" If exist "%CD%\Includes\Build_Settings.cmd" If /i "%Target%"=="S" (
	Set PathChange=False
	Call "%CD%\Includes\Build_Settings.cmd" Build_Settings_Start
	cls
	If "!PathChange!" == "True" endlocal & Set SkipDriveCheckInt=False
	If "!PathChange!" == "False" endlocal & Set SkipDriveCheckInt=True
rem	endlocal & Set SkipDriveCheckInt=False
	goto Start
)

goto MainMenu

:SurfaceRT
Set Device=SurfaceRT
Set SoC=Nvidia
goto Continue

:Surface2
Set Device=Surface2
Set SoC=Nvidia
goto Continue

:Yoga11
Set Device=Yoga11
Set SoC=Nvidia
goto Continue

:VivoTab
Set Device=VivoTabRT
Set SoC=Nvidia
goto Continue

:XPS10
Set Device=XPS10
Set SoC=Qualcomm
goto Continue

:Lumia2520
Set Device=Lumia2520
Set SoC=Qualcomm
goto Continue

:ATIVTab
Set Device=ATIVTab
Set SoC=Qualcomm
goto Continue

:Generic
Set Device=Generic
Set Name=None
Set SoC=None
goto Continue

:QEMU
Set Device=QEMU
Set SoC=Emulated
goto Continue

:Continue
If not "%SoC%" == "None" (
	Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" DeviceInfo
)

If /i "!WindowsUpdateForceAltDownload!" == "True" Set WindowUpdateListExt=_Alt

If "%BuildAbort%"=="True" goto ExitNoTempClear

REM ====== Windows Update Mode =========================================================================================================================================

:SelectWUDesc
If "!ReadPreset!" == "True" goto SkipMode
cls
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Select Windows Update Mode:%ef%
echo.
echo		1: All updates for Windows
echo		2: Longhorn Jailbreak Safe
echo		3: Myriachan Jailbreak Safe
echo		4: Service Stack ^& Update 3 Only
echo		5: Service Stack Only
echo		6: No Updates
echo. %white%
Set /p Mode=Enter Selection: 
echo. %ef%

:SkipMode

:SkipModeSelect
if "%Mode%"=="1" goto All
if "%Mode%"=="2" goto Longhorn
if "%Mode%"=="3" goto Myriachan
if "%Mode%"=="4" goto Update3
if "%Mode%"=="5" goto StackOnly
if "%Mode%"=="6" goto None
goto SelectWUDesc

:All
Set WUDesc=All Updates to %WindowsUpdateListsUpdated%
Set WUList=Windows_Updates_All!WindowUpdateListExt!.txt
Set WUDir=Windows_Updates_All
Set WUListStack=Windows_Updates_Servicing_Stack!WindowUpdateListExt!.txt
Set WUDirStack=Windows_Updates_Servicing_Stack
Set WUJBKill=True
Set WUInstall=True
Set WUInstallStack=True
Set WUInstallUpdate3=True
goto SetConfig

:Longhorn
Set WUDesc=Longhorn Jailbreak Safe
Set WUList=Windows_Updates_Jailbreak_Safe_Longhorn!WindowUpdateListExt!.txt
Set WUDir=Windows_Updates_Jailbreak_Safe_Longhorn
Set WUListStack=Windows_Updates_Servicing_Stack!WindowUpdateListExt!.txt
Set WUDirStack=Windows_Updates_Servicing_Stack
Set WUJBKill=False
Set WUInstall=True
Set WUInstallStack=True
Set WUInstallUpdate3=True
goto SetConfig

:Myriachan
Set WUDesc=Myriachan Jailbreak Safe
Set WUList=Windows_Updates_Jailbreak_Safe_Myriachan!WindowUpdateListExt!.txt
Set WUDir=Windows_Updates_Jailbreak_Safe_Myriachan
Set WUListStack=Windows_Updates_Servicing_Stack!WindowUpdateListExt!.txt
Set WUDirStack=Windows_Updates_Servicing_Stack
Set WUJBKill=False
Set WUInstall=True
Set WUInstallStack=True
Set WUInstallUpdate3=True
goto SetConfig

:Update3
Set WUDesc=Service Stack and Update 3 Only
Set WUList=Windows_Updates_Update_3!WindowUpdateListExt!.txt
Set WUDir=Windows_Updates_Update_3
Set WUListStack=Windows_Updates_Servicing_Stack!WindowUpdateListExt!.txt
Set WUDirStack=Windows_Updates_Servicing_Stack
Set WUJBKill=False
Set WUInstall=True
Set WUInstallStack=True
Set WUInstallUpdate3=True
goto SetConfig

:StackOnly
Set WUDesc=Service Stack Only
Set WUList=False
Set WUDir=False
Set WUListStack=Windows_Updates_Servicing_Stack!WindowUpdateListExt!.txt
Set WUDirStack=Windows_Updates_Servicing_Stack
Set WUJBKill=False
Set WUInstall=False
Set WUInstallStack=True
Set WUInstallUpdate3=False
goto SetConfig

:None
Set WUDesc=None
Set WUList=False
Set WUDir=False
Set WUListStack=False
Set WUDirStack=False
Set WUJBKill=False
Set WUInstall=False
Set WUInstallStack=False
Set WUInstallUpdate3=False
goto SetConfig

:SetConfig
cls

REM === Select alternative language ====================================================================================================================================

:ChangeDefaultLanguage
If "!ReadPreset!" == "True" goto UseDefaultLanguage
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p LangPrompt=The default language is English (United States), would you like to select another language (Y/N)? 
If /i "%LangPrompt%"=="Y" goto LangSelect
If /i "%LangPrompt%"=="N" (
	Set FindLanguage=en-us
	goto UseDefaultLanguage
)
If "%FindLanguage%" == "" goto ChangeDefaultLanguage

REM === Language code lookup ===========================================================================================================================================

:LangSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Select Language:%ef%
echo.
echo		 1: Arabic (Saudi Arabia)	14: Croatian (Croatia)		27: Russian (Russia)
echo		 2: Bulgarian (Bulgaria)	15: Hungarian (Hungary)		28: Slovak (Slovakia)
echo		 3: Czech (Czech Republic)	16: Italian (Italy)		29: Slovenian (Slovenia)
echo		 4: Danish (Denmark)		17: Japanese (Japan)		30: Serbian (Latin, Serbia)
echo		 5: German (Germany)		18: Korean (Korea)		31: Swedish (Sweden)
echo		 6: Greek (Greece)		19: Lithuanian (Lithuania)	32: Thai (Thailand)
echo		 7: English (United Kingdom)	20: Latvian (Latvia)		33: Turkish (Turkey)
echo		 8: English (United States)	21: Norwegian (Norway)		34: Ukrainian (Ukraine)
echo		 9: Spanish (Spain)		22: Dutch (Netherlands)		35: Chinese (PRC)
echo		10: Estonian (Estonia)		23: Polish (Poland)		36: Chinese (Hong Kong)
echo		11: Finnish (Finland)		24: Portuguese (Brazil)		37: Chinese (Taiwan)
echo		12: French (France)		25: Portuguese (Portugal)
echo		13: Hebrew (Israel)		26: Romanian (Romania)
echo. %white%
Set /p LanguageSelection=Select Language: 
echo. %ef%

If "%LanguageSelection%"=="1" Set FindLanguage=ar-sa
If "%LanguageSelection%"=="2" Set FindLanguage=bg-bg
If "%LanguageSelection%"=="3" Set FindLanguage=cs-cz
If "%LanguageSelection%"=="4" Set FindLanguage=da-dk
If "%LanguageSelection%"=="5" Set FindLanguage=de-de
If "%LanguageSelection%"=="6" Set FindLanguage=el-gr
If "%LanguageSelection%"=="7" Set FindLanguage=en-gb
If "%LanguageSelection%"=="8" Set FindLanguage=en-us
If "%LanguageSelection%"=="9" Set FindLanguage=es-es
If "%LanguageSelection%"=="10" Set FindLanguage=et-ee
If "%LanguageSelection%"=="11" Set FindLanguage=fi-fi
If "%LanguageSelection%"=="12" Set FindLanguage=fr-fr
If "%LanguageSelection%"=="13" Set FindLanguage=he-il
If "%LanguageSelection%"=="14" Set FindLanguage=hr-hr
If "%LanguageSelection%"=="15" Set FindLanguage=hu-hu
If "%LanguageSelection%"=="16" Set FindLanguage=it-it
If "%LanguageSelection%"=="17" Set FindLanguage=ja-jp
If "%LanguageSelection%"=="18" Set FindLanguage=ko-kr
If "%LanguageSelection%"=="19" Set FindLanguage=lt-lt
If "%LanguageSelection%"=="20" Set FindLanguage=lv-lv
If "%LanguageSelection%"=="21" Set FindLanguage=nb-no
If "%LanguageSelection%"=="22" Set FindLanguage=nl-nl
If "%LanguageSelection%"=="23" Set FindLanguage=pl-pl
If "%LanguageSelection%"=="24" Set FindLanguage=pt-br
If "%LanguageSelection%"=="25" Set FindLanguage=pt-pt
If "%LanguageSelection%"=="26" Set FindLanguage=ro-ro
If "%LanguageSelection%"=="27" Set FindLanguage=ru-ru
If "%LanguageSelection%"=="28" Set FindLanguage=sk-sk
If "%LanguageSelection%"=="29" Set FindLanguage=sl-si
If "%LanguageSelection%"=="30" Set FindLanguage=sr-latn-rs
If "%LanguageSelection%"=="31" Set FindLanguage=sv-se
If "%LanguageSelection%"=="32" Set FindLanguage=th-th
If "%LanguageSelection%"=="33" Set FindLanguage=tr-tr
If "%LanguageSelection%"=="34" Set FindLanguage=uk-ua
If "%LanguageSelection%"=="35" Set FindLanguage=zh-cn
If "%LanguageSelection%"=="36" Set FindLanguage=zh-hk
If "%LanguageSelection%"=="37" Set FindLanguage=zh-tw

If "%FindLanguage%" == "" goto LangSelect

:UseDefaultLanguage

Set WindowsDownloadList="%CD%\Download_Lists\Windows.txt"

For /F "usebackq tokens=* skip=1" %%a in (%WindowsDownloadList%) do (
	For /f "tokens=1-19 delims=," %%a in ("%%a") do (
		If /i "%%a" == "%FindLanguage%" (
			Set Windows_Tag=%%a
			Set Windows_Language=%%b
			Set Windows_Country=%%c
			Set Windows_LCID=%%d
			Set Windows_UNUSED1=%%e
			Set Windows_AppxSafe=%%f

			If /i "!WindowsForceAltDownload!" == "True" (

				Set Windows_HTTPSourceName=%%n
				Set Windows_URL=%%o
				Set Windows_FileName=%%~NXo
				For /f "tokens=1-16 delims=_." %%a in ("!Windows_FileName!") do (
					Set Windows_Encrypted_SHA1=%%o
				)

				Set Windows_TorrentSourceName=%%p
				Set Windows_TorrentURL=%%q
				Set Windows_TorrentFileName=%%~NXq
				Set Windows_TorrentDir=!Windows_TorrentFileName:_archive.torrent=!
				Set Windows_TorrentM=%%r
				Set Windows_TorrentIndex=%%s

			) else (

				Set Windows_HTTPSourceName=%%g
				Set Windows_URL=%%h
				Set Windows_FileName=%%~NXh
				For /f "tokens=1-16 delims=_." %%a in ("!Windows_FileName!") do (
					Set Windows_Encrypted_SHA1=%%o
				)

				Set Windows_TorrentSourceName=%%i
				Set Windows_TorrentURL=%%j
				Set Windows_TorrentFileName=%%~NXj
				Set Windows_TorrentDir=!Windows_TorrentFileName:_archive.torrent=!
				Set Windows_TorrentM=%%k
				Set Windows_TorrentIndex=%%l

			)

			Set Windows_Decrypted_SHA1=%%m

		)
	)
)

If exist "%CD%\Temp.cmd" Call "%CD%\Temp.cmd" Windows_List

REM ====== Start Menu ==================================================================================================================================================

If exist "%CD%\Includes\Mod_Install_StartMenu.cmd" (
	Call "%CD%\Includes\Mod_Install_StartMenu.cmd" StartMenuDefaultMenu
)

REM ====== Can Accept Appx Changes =====================================================================================================================================

If exist "%CD%\Includes\Uninstall_Appx.cmd" If /i "%Windows_AppxSafe%" == "False" (
	If not "!ReadPreset!" == "True" (
	cls
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %InfoBar%
	echo.
	echo		%white%The selected language does not currently support the removal or updating of provisioned apps, app
	echo		options will be skipped.%ef%
	echo.
	echo %InfoBar%
	echo.
	pause
	)
	Set UninstallAppx=False
	Set UpdateAppx=False
	goto SkipAppx
)

REM ====== Install Appx ================================================================================================================================================

If exist "%CD%\Addons\Appx\Install_Appx.cmd" (
	Call "%CD%\Addons\Appx\Install_Appx.cmd" AppxMenu
)

REM ====== Uninstall Appx ==============================================================================================================================================

If exist "%CD%\Includes\Uninstall_Appx.cmd" (
	Call "%CD%\Includes\Uninstall_Appx.cmd" UninstallAppxMenu

	If "!UninstallAppx!" == "True" (
		If exist "%CD%\Includes\Uninstall_Camera.cmd" (
			Call "%CD%\Includes\Uninstall_Camera.cmd" UninstallCameraMenu
		)
		If exist "%CD%\Includes\Uninstall_OneDrive.cmd" (
			Call "%CD%\Includes\Uninstall_OneDrive.cmd" UninstallOneDriveMenu
		)
		If exist "%CD%\Includes\Uninstall_Store.cmd" (
			Call "%CD%\Includes\Uninstall_Store.cmd" UninstallStoreMenu
		)
		If exist "%CD%\Includes\Uninstall_ImmersiveControlPanel.cmd" (
			Call "%CD%\Includes\Uninstall_ImmersiveControlPanel.cmd" UninstallImmersiveControlPanelMenu
		)



	)
)

REM ====== Install Device Appx =========================================================================================================================================

If "%DeviceApps%" == "True" If exist "%CD%\Addons\Appx\Install_Appx_%Device%.cmd" (
	Call "%CD%\Addons\Appx\Install_Appx_%Device%.cmd" DeviceAppxMenu 81
)

:SkipAppx

REM ====== BitLocker ===================================================================================================================================================

If exist "%CD%\Includes\Uninstall_BitLocker.cmd" (
	Call "%CD%\Includes\Uninstall_BitLocker.cmd" UninstallBitLockerMenu
)

REM ====== Extra Stuff =================================================================================================================================================

If exist "%CD%\Includes\Uninstall_Office.cmd" (
	Call "%CD%\Includes\Uninstall_Office.cmd" UninstallOfficeMenu
)

If exist "%CD%\Includes\Uninstall_Defender.cmd" (
	Call "%CD%\Includes\Uninstall_Defender.cmd" UninstallDefenderMenu
)

If exist "%CD%\Includes\Uninstall_Flash.cmd" (
	Call "%CD%\Includes\Uninstall_Flash.cmd" UninstallAdobeFlashMenu
)

If exist "%CD%\Includes\Uninstall_VPN.cmd" (
	Call "%CD%\Includes\Uninstall_VPN.cmd" UninstallVPNPackagesMenu
)

REM ====== Defender Update =============================================================================================================================================

If not "!UninstallDefender!" == "True" If exist "%CD%\Addons\Defender\Windows_Defender.cmd" (
	Call "%CD%\Addons\Defender\Windows_Defender.cmd" DefenderMenu
)

REM ====== Office 2013 RT Update =======================================================================================================================================

If exist "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" (
	Call "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" Office2013RTMenu
)

REM ====== Custom ======================================================================================================================================================

Set BuildCustom=False
If "%CustomAddon%" == "True" If exist "%CD%\Addons\Custom\Custom.cmd" (
	Call "%CD%\Addons\Custom\Custom.cmd" CustomMenu
) else (
	Set BuildCustom=False
)

REM ====== Will output be unmodified IR5 ===============================================================================================================================

rem If "%WUInstall%" == "False" If "%WUInstallStack%" == "False" If "%UninstallAppx%" == "False" If "%UpdateAppx%" == "False" If "%StartMenuDefault%" == "False" If "%Device%" == "Generic" If "%BuildCustom%" == "False" Set IR5Only=True
If "%WUInstall%" == "False" If "%WUInstallStack%" == "False" If "%UninstallAppx%" == "False" If "%UpdateAppx%" == "False" If "%StartMenuDefault%" == "False" If "%Device%" == "Generic" If "%BuildCustom%" == "False" If "%UninstallBitLocker%" == "False" If "%UninstallOffice%" == "False" If "%UninstallDefender%" == "False" If "%UninstallAdobeFlash%" == "False" If "%UninstallVPNPackages%" == "False" Set IR5Only=True

REM ====== Installer ===================================================================================================================================================

:SelectSetupMode
If "!ReadPreset!" == "True" goto SkipSetupModeSelection

If "%CustomSetup%" == "True" (
	If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" SetupMode
	goto SetupModeSelected
)

cls
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Select Windows Setup Mode:%ef%
echo.
echo		1: %dblue%Windows Setup (Default)%ef%
echo.
echo		Creates installation media using default Windows Setup, this mode is not as touch friendly as the
echo		Windows Recovery Environment and does not create a recovery partition.
echo.
echo		2: %blue%Windows Recovery Environment (WinRE)%ef%
echo.
echo		Creates installation media using the Windows Recovery Environment, this mode is touch friendly and
echo		will create a recovery partition.
echo.
echo		3: %white%Modified WIM Files Only (No Setup)%ef%
echo.
echo		Creates modified WIM files for manual installation.
echo. %white%
Set /p SetupModeSelection=Enter Selection: 
echo. %ef%

:SkipSetupModeSelection

If "%SetupModeSelection%"=="1" goto Setup
If "%SetupModeSelection%"=="2" goto WinRE
If "%SetupModeSelection%"=="3" goto WIM
goto SelectSetupMode

:Setup
Set SetupMode=Setup
Set OfferInstallESD=True
Set SetupModeDesc=Windows Setup
Set WinREInInstall=True
goto SetupModeSelected

:WinRE
Set SetupMode=WinRE
Set OfferInstallESD=True
Set SetupModeDesc=Windows Recovery Environment
Set WinREInInstall=False
goto SetupModeSelected

:WIM
Set SetupMode=WimOnly
Set OfferInstallESD=False
Set SetupModeDesc=WIM

:WinREInInstallSelect
If "!ReadPreset!" == "True" (
	If "%WinREInInstall%" == "True" (
		Set WinREInInstallPrompt=Y
	) else (
		Set WinREInInstallPrompt=N
	)
	Goto SkipWinREInInstallPrompt
)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p WinREInInstallPrompt=Include Winre.wim in Install.wim (Y/N)? 

:SkipWinREInInstallPrompt

If /i "%WinREInInstallPrompt%"=="Y" (
	Set WinREInInstall=True
	Set SetupModeDescNote=Include Winre.wim in Install.wim
	goto SetupModeSelected
)

If /i "%WinREInInstallPrompt%"=="N" (
	Set WinREInInstall=False
	Set SetupModeDescNote=Do not include Winre.wim in Install.wim
	goto SetupModeSelected
)

goto WinREInInstallSelect

:SetupModeSelected

If "%OfferInstallESD%" == "False" (
	Set InstallESD=False
	goto SkipInstallESDPrompt
)

:InstallESDSelect
cls
If "!ReadPreset!"=="True" Goto SkipInstallESDPrompt
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %White%Windows Image Compression Mode:%ef%
echo.
echo		1: %green%Windows Imaging Format (WIM) Format%ef%
echo.
echo		Offers shorter image creation time at the expense of lower compression.
echo.
echo		2: %red%Electronic Software Delivery (ESD) Format%ef%
echo.
echo		Offers higher compression at the expense of longer image creation time. Using this option will result in
echo		lower disk space usage on the installation USB and where applicable result in a smaller recovery partition.
echo. %white%
Set /p InstallESDPrompt=Enter Selection: 
echo. %ef%

If "%InstallESDPrompt%"=="1" Set InstallESD=False
If "%InstallESDPrompt%"=="2" Set InstallESD=True

:SkipInstallESDPrompt

If "%InstallESD%" == "True" (
	Set InstallFormat=ESD
) else (
	Set InstallFormat=WIM
)

If "%InstallESD%" == "" goto InstallESDSelect

REM ====== Confirm =====================================================================================================================================================

:ConfirmSelect
cls
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %red%Excluding download time this process may take up to one hour, please confirm the following selections are correct:%ef%
echo.

Call "%CD%\Includes\Mod_Info_Files.cmd" infopreview 0 mediabuilder

If "%SoC%" == "Qualcomm" (
	Set Bar=%WarningBar%
) else (
	Set Bar=%InfoBar%
)

If "%SkipNotes%" == "True" goto SkipNotes

echo %Bar%
echo.

If not "%SoC%" == "None" (

	If "%SoC%" == "Nvidia" (
		echo		%white%Nvidia based devices can be temporarily prevented from using the Longhorn Jailbreak ^(Secure Boot
	)

	If "%SoC%" == "Qualcomm" (
		echo		%white%Qualcomm based devices can be %ul%PERMANENTLY%ef%%white% prevented from using the Longhorn Jailbreak ^(Secure Boot
	)

	echo		Debug Policy^) if they are updated beyond a certain point.
	echo.

) else (

	If "%IR5Only%" == "True" (
		echo		%white%The options selected will result in an unmodified copy of Windows RT 8.1 IR5. No drivers or updates 
		echo		will be integrated, only conversion of the downloaded ESD file will be performed.%ef%
		echo.
	) else (
		echo		%white%The options selected will result in a modified copy of Windows RT 8.1 IR5 without drivers.%ef%
		echo.
	)

)

If "%WUJBKill%" == "True" (
	echo		%white%The Windows Update Mode you have selected %ul%DOES%ef%%white% contain "Jailbreak Killing" updates which will prevent
	echo		attempts to install the Longhorn Jailbreak.%ef%
	echo.
) else (
	If "%WUInstallStack%" == "True" (
		echo		%white%Every effort has been made to make sure the Windows Update Mode you have selected does not contain 
		echo		any "Jailbreak Killing" updates however should you proceed it is done so entirely at your own risk.%ef%
		echo.
	)
	If not "%SoC%" == "None" (
			echo		%white%After installation, it is recommended that Windows Update is disabled before the device is connected 
			echo		to the internet to prevent installation of updates which may prevent the use of the Longhorn Jailbreak.%ef%	
			echo.
	)
)

If "%BuildCustom%" == "True" (
	Call "%CD%\Addons\Custom\Custom.cmd" CustomInfo
)

echo %Bar%
echo.
:SkipNotes

echo %red%Please do not close this window while downloads and image modifications are in progress.%ef%
echo.

If "%CreatePreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" CreatePresetInfo
)

If "%DownloadPreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" DownloadPresetInfo
)

If not "%DownloadPreset%" == "True" If "%ReadPreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" BuildPresetInfo
)

Set /p ConfirmPrompt=Would you like to continue%ConfirmPromptText%? (Y/N)? 
If /i "%ConfirmPrompt%"=="Y" (

	If "%CreatePreset%" == "True" (
		Call "%CD%\Includes\Build_Preset.cmd" SavePreset
		Call "%CD%\Includes\Build_Preset.cmd" CreatePresetComplete
		endlocal & Set SkipDriveCheckInt=True
		goto Start
	)

	goto Confirmed

)

If /i "%ConfirmPrompt%"=="N" (
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

goto ConfirmSelect

:Confirmed

REM ====== Timer =======================================================================================================================================================

Set "startTime=%time: =0%"

REM ====== Make sure Tmp folder empty ==================================================================================================================================

Set Retry=0

:RetryTempClear

If exist "%TmpPath%\" If "%Retry%" == "1" (
	echo.
	echo %red%Error: Unable to clear "%TmpPath%" folder, please reboot and try again.%ef%
	goto ExitNoTempClear
)

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %white%Clearing Temporary Files.%ef%
	echo Please wait.
	echo.
	If exist "%TmpPath%\Mount\boot\" start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\boot" /discard >NUL
	echo Please wait..
	echo.
	If exist "%TmpPath%\Mount\winre\" start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre" /discard >NUL
	echo Please wait...
	echo.
	If exist "%TmpPath%\Mount\install\" start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\install" /discard >NUL
	echo Please wait....

	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1

	If not exist "%TmpPath%\" (
		echo.
		echo %green%"%TmpPath%" Cleared.%ef%
	) else (
		Set Retry=1
		goto RetryTempClear
	)
)

REM ====== Create folders ==============================================================================================================================================

For %%d in (
	"%CD%\Addons\Appx\Apps\"
	"%CD%\Addons\Appx\Dependency\"
	"%CD%\Addons\Custom\"
	"%CD%\Addons\Office\"
	"%DownloadsPath%\Windows\"
	"%TmpPath%\ScratchDir"
	"%TmpPath%\Source\"
	"%TmpPath%\UpdateListCheck\"
	"%TmpPath%\Mount\boot\"
	"%TmpPath%\Mount\winre\"
	"%TmpPath%\Mount\install\"
	"%TmpPath%\Updated\boot\"
	"%TmpPath%\Updated\winre\"
	"%TmpPath%\Updated\install\"
	"%TmpPath%\Logs"
) do (
	If not exist %%d md %%d 1> nul
)

If not "%WUListStack%" == "False" (
	If not exist "%DownloadsPath%\%WUDirStack%\" md "%DownloadsPath%\%WUDirStack%\" 1> nul
)

If not "%WUList%" == "False" (
	If not exist "%DownloadsPath%\%WUDir%\" md "%DownloadsPath%\%WUDir%\" 1> nul
)

REM ====== Check if Windows already downloaded =========================================================================================================================

:WindowsRetry
:WindowsUpdateRetry
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Downloading Windows RT 8.1 IR5 Files.%ef%
echo Please wait...
echo.

If exist "%DownloadsPath%\Windows\%Windows_FileName%" (
	echo %white%Windows RT 8.1 IR5 ^(%Windows_Tag%^) found, skipping download.%ef%
	goto SkipArchiveOrgDownload
)

REM ====== Download Windows ESD / Windows Updates ======================================================================================================================

If /i "%Windows_TorrentIndex%" == "False" goto WindowsWget

If "%Windows_TorrentIndex%" == "True" (
	Set TorrentSelect=
) else (
	Set TorrentSelect=--select-file=%Windows_TorrentIndex%
)

If /i "%ArchiveOrgTorrent%" == "True" (
	netsh advfirewall firewall add rule name="Windows Media Builder - tget" dir=in action=allow program="%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" enable=yes 1> nul
	"%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" /1 /t "%Windows_TorrentURL%" /o "%TmpPath%" /n
	Set TorrentClientStatus=!ErrorLevel!
	netsh advfirewall firewall delete rule name="Windows Media Builder - tget" program="%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" 1> nul
)

If /i "%ArchiveOrgTorrent%" == "True" (
	If !TorrentClientStatus! EQU 0 (
		Move /y "%TmpPath%\%Windows_TorrentDir%\%Windows_FileName%" "%DownloadsPath%\Windows\" 1> nul
		goto SkipArchiveOrgDownload
	) else (
		echo.
		echo %red%Error: Unable to download Windows.%ef%
		echo %red%Error: !TorrentClientStatus!%ef%
		Goto Exit
	)
)

:WindowsWget

"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" %Windows_URL% -P "%DownloadsPath%\Windows" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
If "!ErrorLevel!" NEQ "0" (
	echo Error: Unable to download Windows.
	echo Wget Error: !ErrorLevel!
	Goto Exit
)

:SkipArchiveOrgDownload

If "%WUInstallStack%" == "True" (
	"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -i "%CD%\Download_Lists\%WUListStack%" -P "%DownloadsPath%\%WUDirStack%" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
	If "!ErrorLevel!" NEQ "0" (
		echo Error: Unable to download Windows Updates - %WUListStack%
		echo Wget Error: !ErrorLevel!
		Goto Exit
	)

)

If "%WUInstall%" == "True" (
	"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -i "%CD%\Download_Lists\%WUList%" -P "%DownloadsPath%\%WUDir%" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
	If "!ErrorLevel!" NEQ "0" (
		echo Error: Unable to download Windows Updates - %WUList%
		echo Wget Error: !ErrorLevel!
		Goto Exit
	)
)


REM ====== Windows SHA1 Check ==========================================================================================================================================

If "%SHA1CheckNewDownload%" == "True" (
	Set TempSHA1Check=%SHA1Check%
	Set SHA1Check=True
)

If /i "%SHA1Check%" == "True" (
	echo.
	echo %white%Verifying Windows ESD File.%ef%
	echo Please wait...
	echo.

	For /f "delims=" %%_ in ('%SystemRoot%\System32\certutil.exe -hashfile "%DownloadsPath%\Windows\%Windows_FileName%" SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
		Set x=%%_
		Set Windows_FileFoundSHA1=!x: =!
	)

	If /I !Windows_Encrypted_SHA1! equ !Windows_FileFoundSHA1! (
		Set WindowsEncryptedESD=True
		Set WindowsSHA1Match=True
	)

	If /I !Windows_Decrypted_SHA1! equ !Windows_FileFoundSHA1! (
		Set WindowsEncryptedESD=False
		Set WindowsSHA1Match=True
	)

	If not "!WindowsSHA1Match!" == "True" (

		echo %red%File Bad: %Windows_FileName%%ef%

		If "!Windows_RetryCount!" == "1" (
			echo %red%Error: Failed to replace corrupt Windows Installation Media.%ef%
			goto Exit
		)

		:RenameExistingDownloadSelect
		echo.
		Set /p RenameExistingDownloadPrompt=Would you like to move the corrupt file and download a new copy ^(Y/N^)? 
		If /i "!RenameExistingDownloadPrompt!"=="Y" Set RenameExistingDownload=True
		If /i "!RenameExistingDownloadPrompt!"=="N" Set RenameExistingDownload=False
		If "!RenameExistingDownload!" == "" goto RenameExistingDownloadSelect

		If "!RenameExistingDownload!" == "True" (
			echo.
			Attrib -r -s -h "%DownloadsPath%\Windows\%Windows_FileName%" 1> nul
			for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a
			If Not Exist "%DownloadsPath%\Windows_Corrupt\!RenameTime:~0,14!\" md "%DownloadsPath%\Windows_Corrupt\!RenameTime:~0,14!\" 1> nul

			Move /y "%DownloadsPath%\Windows\%Windows_FileName%" "%DownloadsPath%\Windows_Corrupt\!RenameTime:~0,14!\" 1> nul

			If exist "%DownloadsPath%\Windows\%Windows_FileName%" (
				echo %red%Error: Unable to move:%ef%
				echo %red%"%DownloadsPath%\Windows\%Windows_FileName%"%ef%
				goto Exit
			) else (
				echo Moved To: "%DownloadsPath%\Windows_Corrupt\!RenameTime:~0,14!\"
				echo.
				echo Retrying...
				Set Windows_RetryCount=1
				goto WindowsRetry
			)

		) else (
			goto Exit
		)

	) else (
		echo %green%File OK: %Windows_FileName%%ef%
	)
rem	echo.

)

If "%SHA1CheckNewDownload%" == "True" (
	Set SHA1Check=%TempSHA1Check%
	Set SHA1CheckNewDownload=False
)

REM ====== Check Windows Update downlod directory and move updates not on the list =====================================================================================

If "%WUInstallStack%" == "True" (

	echo.
	echo %white%Verifying Windows Updates.%ef%
	echo Please wait...
	echo.
	If not "%WUListStack%" == "False" Set WindowsUpdateList=!WindowsUpdateList!;"%DownloadsPath%\%WUDirStack%#%CD%\Download_Lists\%WUListStack%"
	If not "%WUList%" == "False" Set WindowsUpdateList=!WindowsUpdateList!;"%DownloadsPath%\%WUDir%#%CD%\Download_Lists\%WUList%"

	for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a

	For %%i in (
		!WindowsUpdateList!
	) do (
		For /f "tokens=1,2 delims=#" %%a in (%%i) do (

			Set WindowsUpdatePath=%%a
			Set WindowsUpdatePathOld=%%a_Unlisted\!RenameTime:~0,14!
			Set WindowsUpdateListFileName=%%~Nb

			rem echo.
			echo %green%Checking List: %%b %ef%

			For /F "usebackq tokens=*" %%a in ("%%b") do (
				For %%b in ("%%a") do (
					echo %%~NXb>>"%TmpPath%\UpdateListCheck\!WindowsUpdateListFileName!_Expected.txt"
				)
			)

			For %%a in ("%%a\*") do (
				Attrib -a -r -s -h "%%a" 1> nul
				For %%b in ("%%a") do (
					echo %%~NXb>>"%TmpPath%\UpdateListCheck\!WindowsUpdateListFileName!_Found.txt"
				)
			)

			"%SystemRoot%\System32\Findstr.exe" /b /e /ivg:"%TmpPath%\UpdateListCheck\!WindowsUpdateListFileName!_Expected.txt" "%TmpPath%\UpdateListCheck\!WindowsUpdateListFileName!_Found.txt" > "%TmpPath%\UpdateListCheck\!WindowsUpdateListFileName!_Delete.txt"

			For %%f in ("%TmpPath%\UpdateListCheck\!WindowsUpdateListFileName!_Delete.txt") do (
				If %%~zf gtr 0 (

					If Not Exist "!WindowsUpdatePathOld!" md "!WindowsUpdatePathOld!" 1> nul

					For /F "usebackq tokens=*" %%a in ("%TmpPath%\UpdateListCheck\!WindowsUpdateListFileName!_Delete.txt") do (
						If Exist "!WindowsUpdatePath!\%%a" (
							Move /Y "!WindowsUpdatePath!\%%a" "!WindowsUpdatePathOld!\" 1> nul

							If Exist "!WindowsUpdatePath!\%%a" (
								echo.
								echo %red%Error: Unable to move unlisted update...%ef%
								echo %red%"!WindowsUpdatePath!\%%a"%ef%
								goto Exit
							) else (
								echo %red%Unlisted File: %%a%ef%
								Set WindowsUpdatesMoved=True
							)

						)

					)
					If "!WindowsUpdatesMoved!" == "True" echo Moved To: "!WindowsUpdatePathOld!"

				)
			)

		)

	)

	attrib -s -h -r /s /d "%TmpPath%\UpdateListCheck\*.*" > NUL 2>&1
	del "%TmpPath%\UpdateListCheck\*.*" /F /Q /S > NUL 2>&1
	echo.
	If /i not "%SHA1Check%" == "True" (
		If "!WindowsUpdatesMoved!" == "True" (
			echo %white%Unlisted Updates Found ^& Moved.%ef%
		) else (
			echo %white%No Unlisted Updates Found.%ef%
		)
	)

	Set WindowsUpdatesMoved=

)

REM ====== Check Windows Updates SHA1 ==================================================================================================================================

If /i "%SHA1Check%" == "True" If "%WUInstallStack%" == "True" (

	for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a

	For %%i in (
		!WindowsUpdateList!
	) do (

		For /f "tokens=1,2 delims=#" %%a in (%%i) do (

			Set WindowsUpdatePathBroken=%%a_Corrupt

			For %%a in ("%%a\*") do (
				Attrib -a -r -s -h "%%a" 1> nul

				Set WindowsUpdate_FileName=%%~NXa
				For /f "tokens=1-3 delims=_." %%a in ("!WindowsUpdate_FileName!") do (
					Set WindowsUpdate_SHA1=%%c
				)

		 		For /f "delims=" %%d in ('%SystemRoot%\System32\certutil.exe -hashfile "%%a" SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
					Set z=%%d
					Set WindowsUpdate_FileFoundSHA1=!z: =!
				)

				If /I not !WindowsUpdate_SHA1! equ !WindowsUpdate_FileFoundSHA1! (
					echo %red%File Bad: %%~nxa%ef%

					attrib -s -h -r /s /d "%%a" 1> nul

					If Not Exist "!WindowsUpdatePathBroken!\!RenameTime:~0,14!\" md "!WindowsUpdatePathBroken!\!RenameTime:~0,14!\" 1> nul
					Move /y "%%a" "!WindowsUpdatePathBroken!\!RenameTime:~0,14!\" 1> nul
					If exist "%%a" (
						echo.
						echo %red%Error: Unable to move corrupt update...%ef%
						echo %red%"%%a"%ef%
						goto Exit
					) else (
						echo Moved To: "!WindowsUpdatePathBroken!\!RenameTime:~0,14!\"
					)

					Set WindowsUpdate_Retry=True
				) else (
					echo %green%File OK: %%~nxa%ef%
				)

			)

		)
	)

	If "!WindowsUpdate_Retry!" == "True" (
		echo.

		If "!WindowsUpdate_RetryCount!" == "1" (
			echo %red%Error: Failed to replace corrupt Windows Update files.%ef%
			goto Exit
		) else (
			echo %white%Corrupt Windows Update Files Found ^& Moved.%ef%
			echo.
			echo Retrying...
			Set WindowsUpdateList=
			Set WindowsUpdate_Retry=False
			Set WindowsUpdate_RetryCount=1
			Goto WindowsUpdateRetry
		)

	) else (
		echo.
		echo %white%Verified Windows Updates.%ef%
	)

)



REM ====== Download Windows Defender Updates ===========================================================================================================================

If "%UpdateDefender%" == "True" (
	Call "%CD%\Addons\Defender\Windows_Defender.cmd" DefenderDownload
)

REM ====== Office 2013 RT ==============================================================================================================================================

:OfficeUpdateRetry

For %%o in (
	Office2013RTDownload#%Office2013RT_Install%
	Office2013RTVerify#%Office2013RT_Install%
	Office2013RTUpdates#%Office2013RT_Update%
) do (
	For /f "tokens=1,2 delims=#" %%a in ("%%o") do (
		Set Office2013RT_Stage=%%a
		Set Office2013RT_Run=%%b
		If "!Office2013RT_Run!" == "True" (
			Call "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" !Office2013RT_Stage!
			If "!Office2013RT_Abort!" == "True" goto Exit
		)
	)
)

If "%OfficeUpdate_Retry%" == "True" (
	set OfficeUpdate_Retry=False
	goto OfficeUpdateRetry
)

REM ====== Preset Download Only ========================================================================================================================================

If "%DownloadPreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" DownloadPresetComplete
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

REM ====== Decrypt ESD & Export WIM ====================================================================================================================================

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Exporting WIM Files from ESD File.%ef%

Attrib -a -r -s -h "%DownloadsPath%\Windows\%Windows_FileName%" 1> nul

If "%WindowsEncryptedESD%" == "True" (
	"%CD%\Bin\DecryptESD\DecryptESD.exe" decrypt -f "%DownloadsPath%\Windows\%Windows_FileName%" 1> nul
)

If "%IR5Only%" == "True" (
	Set CompLevel=Max
) else (
	Set CompLevel=None
)

If not "%SetupMode%" == "WimOnly" (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%DownloadsPath%\Windows\%Windows_FileName%" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Source\media.wim" /Compress:%CompLevel%
	Set DismError=!ErrorLevel!
	If not !DismError! EQU 0 (
		Set ExportFail=True
		Goto ExportFailed
	)
)

If not "%SetupMode%" == "WinRE" (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%DownloadsPath%\Windows\%Windows_FileName%" /SourceIndex:2 /DestinationImageFile:"%TmpPath%\Source\boot.wim" /Compress:%CompLevel%
	Set DismError=!ErrorLevel!
	If not !DismError! EQU 0 (
		Set ExportFail=True
		Goto ExportFailed
	)
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%DownloadsPath%\Windows\%Windows_FileName%" /SourceIndex:3 /DestinationImageFile:"%TmpPath%\Source\boot.wim" /Compress:%CompLevel%
	Set DismError=!ErrorLevel!
	If not !ErrorLevel! EQU 0 (
		Set ExportFail=True
		Goto ExportFailed
	)
)

If "%IR5Only%" == "True" (
	If "%WinREInInstall%" == "True" (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%DownloadsPath%\Windows\%Windows_FileName%" /SourceIndex:4 /DestinationImageFile:"%TmpPath%\Source\install.wim" /Compress:Max
		Set DismError=!ErrorLevel!
		If not !DismError! EQU 0 (
			Set ExportFail=True
			Goto ExportFailed
		)
	) else (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%DownloadsPath%\Windows\%Windows_FileName%" /SourceIndex:4 /DestinationImageFile:"%TmpPath%\Source\install.wim" /Compress:None
		Set DismError=!ErrorLevel!
		If not !DismError! EQU 0 (
			Set ExportFail=True
			Goto ExportFailed
		)
	)
) else (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%DownloadsPath%\Windows\%Windows_FileName%" /SourceIndex:4 /DestinationImageFile:"%TmpPath%\Source\install.wim" /Compress:None
	Set DismError=!ErrorLevel!
	If not !DismError! EQU 0 (
		Set ExportFail=True
		Goto ExportFailed
	)
)

:ExportFailed
If "!ExportFail!" == "True" (
	If !DismError! EQU 13 (
		Set SHA1CheckNewDownload=True
		Set ExportFail=False
		echo.
		echo %white%Attemping Recovery...%ef%
		goto WindowsRetry
	)
	If !DismError! EQU 1314 (
		echo.
		echo %red%Error: User "%username%" may not have "Manage auditing and security log" permission, unable to export ESD to WIM.%ef%
	) else (
		echo.
		echo %red%Error: Unable to export ESD to WIM.%ef%
	)
	echo DISM Error: !DismError!
	goto ExitNoTempClear
)

REM ====== Mount Install.wim first to get Winre.wim ====================================================================================================================

If "%IR5Only%" == "True" If "%WinREInInstall%" == "True" goto SkipGetWinRE

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Mount-Wim /WimFile:"%TmpPath%\Source\install.wim" /index:1 /MountDir:"%TmpPath%\Mount\install"
Set DismError=!ErrorLevel!

If not !DismError! EQU 0 (
	If !DismError! EQU 1314 (
		echo.
		echo %red%Error: User "%username%" may not have "Manage auditing and security log" permission, unable to mount install.wim.%ef%
	) else (
		echo.
		echo %red%Error: Unable to mount install.wim.%ef%
	)
	echo DISM Error: !DismError!
	goto exit
)

Attrib -a -r -s -h "%TmpPath%\Mount\install\Windows\System32\Recovery\winre.wim" 1> nul
Move /Y "%TmpPath%\Mount\install\Windows\System32\Recovery\winre.wim" "%TmpPath%\Source\" 1> nul

:SkipGetWinRE

REM ======= Skip WIM Updates ===========================================================================================================================================

If "%IR5Only%" == "True" (
	If "%WinREInInstall%" == "False" (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\install" /Commit
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\install.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\install\install.wim" /Compress:max
		Del "%TmpPath%\Source\install.wim" /F /Q 1> nul
	)
	goto IR5OnlySkipWimUpdate
)

REM ====== Boot.wim ====================================================================================================================================================

If not "%SetupMode%" == "WinRE" (

	For /l %%e in (1,1,2) do (

		echo %ul%________________________________________________________________________________________________________________________%ef%
		echo.
		echo %white%Modifying Boot.wim - Index:%%e%ef%

		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Mount-Wim /WimFile:"%TmpPath%\Source\boot.wim" /index:%%e /MountDir:"%TmpPath%\Mount\boot"

		If "%WUInstallStack%" == "True" (
			For  %%i in ("%DownloadsPath%\%WUDirStack%\*") do (
		  		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\boot" /Add-Package:"%%i"
				start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Commit-Image /MountDir:"%TmpPath%\Mount\boot"
			)
		)

		If not "%Device%" == "Generic" (
			If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" boot
		)

		If "%BuildCustom%" == "True" (
			Call "%CD%\Addons\Custom\Custom.cmd" boot
		)

		If "%%e" == "2" (
			If exist "%CD%\Includes\Mod_Setup.cmd" Call "%CD%\Includes\Mod_Setup.cmd" ModSetupIndex2
		)

		Call "%CD%\Includes\Mod_Info_Files.cmd" boot %%e mounted

		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\boot" /Commit

		If "%ExportBootWinREWIM%" == "True" (
			start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\boot.wim" /SourceIndex:%%e /DestinationImageFile:"%TmpPath%\Updated\boot\boot.wim" /Compress:max
			If "%%e" == "2" Del "%TmpPath%\Source\boot.wim" /F /Q 1> nul
		) else (
			echo.
			echo %white%Skipping WIM Export%ef%
			If "%%e" == "2" Move /y "%TmpPath%\Source\boot.wim" "%TmpPath%\Updated\boot" 1> nul
		)
	)
	Call "%CD%\Includes\Mod_Info_Files.cmd" boot 1 unmounted
	Call "%CD%\Includes\Mod_Info_Files.cmd" boot 2 unmounted
)

REM ====== Winre.wim ===================================================================================================================================================

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Modifying Winre.wim - Index:1%ef%

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Mount-Wim /WimFile:"%TmpPath%\Source\winre.wim" /index:1 /MountDir:"%TmpPath%\Mount\winre"

If "%WUInstallStack%" == "True" (

	For  %%i in ("%DownloadsPath%\%WUDirStack%\*") do (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\winre" /Add-Package:"%%i"
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Commit-Image /MountDir:"%TmpPath%\Mount\winre"
	)

)

If not "%Device%" == "Generic" (
	If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" winre
)

If "%BuildCustom%" == "True" (
	Call "%CD%\Addons\Custom\Custom.cmd" winre
)

Call "%CD%\Includes\Mod_Info_Files.cmd" winre 1 mounted

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre" /Commit

If "%ExportBootWinREWIM%" == "True" (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\winre.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\winre\winre.wim" /Compress:max
	Del "%TmpPath%\Source\winre.wim" /F /Q 1> nul
) else (
	echo.
	echo %white%Skipping WIM Export%ef%
	Move /y "%TmpPath%\Source\winre.wim" "%TmpPath%\Updated\winre" 1> nul
)

Call "%CD%\Includes\Mod_Info_Files.cmd" winre 1 unmounted

REM ====== Install.wim =================================================================================================================================================

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Modifying Install.wim - Index:1%ef%

If "%UpdateAppx%" == "True" (
	Call "%CD%\Addons\Appx\Install_Appx.cmd" AppxCopy
)

If "%UninstallAppx%" == "True" (
	Call "%CD%\Includes\Uninstall_Appx.cmd" UninstallProvisionedAppx
)

If "%ManufacturerAppxInstall%" == "True" (
	Call "%CD%\Addons\Appx\Install_Appx_%Device%.cmd" ManufacturerAppx 81
)

If "%OperatorAppxInstall%" == "True" (
	Call "%CD%\Addons\Appx\Install_Appx_%Device%.cmd" OperatorAppx 81
)

If "%UninstallCamera%" == "True" (
	Call "%CD%\Includes\Uninstall_Camera.cmd" UninstallCamera
)

If "%UninstallOneDrive%" == "True" (
	Call "%CD%\Includes\Uninstall_OneDrive.cmd" UninstallOneDrive
)

If "%UninstallStore%" == "True" (
	Call "%CD%\Includes\Uninstall_Store.cmd" UninstallStore
)

If "%UninstallImmersiveControlPanel%" == "True" (
	Call "%CD%\Includes\Uninstall_ImmersiveControlPanel.cmd" UninstallImmersiveControlPanel
)

If "%UninstallBitLocker%" == "True" (
	Call "%CD%\Includes\Uninstall_BitLocker.cmd" UninstallBitLocker
)

If "%UninstallOffice%" == "True" (
	Call "%CD%\Includes\Uninstall_Office.cmd" UninstallOffice
)

If "%UninstallDefender%" == "True" (
	Call "%CD%\Includes\Uninstall_Defender.cmd" UninstallDefender
)

If "%UninstallAdobeFlash%" == "True" (
	Call "%CD%\Includes\Uninstall_Flash.cmd" UninstallAdobeFlash
)

If "%UninstallVPNPackages%" == "True" (
	Call "%CD%\Includes\Uninstall_VPN.cmd" UninstallVPNPackages
)

If "%WUInstallStack%" == "True" (
	For  %%i in ("%DownloadsPath%\%WUDirStack%\*") do (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\install" /Add-Package:"%%i"
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Commit-Image /MountDir:"%TmpPath%\Mount\install"
	)
)

If "%WUInstall%" == "True" (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\install" /Add-Package /PackagePath:"%DownloadsPath%\%WUDir%"
)

If "%WinREInInstall%" == "True" (
	copy "%TmpPath%\Updated\winre\winre.wim" "%TmpPath%\Mount\install\Windows\System32\Recovery\winre.wim" 1> nul
)

If not "%Device%" == "Generic" (
	If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" install
)

Call "%CD%\Includes\Mod_Install.cmd" InstallWim

If "%ActivationBackupScript%" == "True" (
	Call "%CD%\Includes\Mod_ActivationBackup.cmd" WriteActivationBackup 81
)

If "%WindowsUpdateScript%" == "True" (
	Call "%CD%\Includes\Mod_WindowsUpdate.cmd" WriteWindowsUpdate 81
)

If "%ResetBaseScript%" == "True" If "%WUInstallStack%" == "True" (
	Call "%CD%\Includes\Mod_ResetBase.cmd" WriteResetBase 81
)

If "%StartMenuDefault%" == "True" (
	Call "%CD%\Includes\Mod_Install_StartMenu.cmd" StartMenuDefault
)

If "%BuildCustom%" == "True" (
	Call "%CD%\Addons\Custom\Custom.cmd" install
)

Call "%CD%\Includes\Mod_Info_Files.cmd" install 1 mounted

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\install" /Commit

If "%InstallESD%" == "True" (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\install.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\install\install.esd" /Compress:recovery
) else (
	If "%ExportInstallWIM%" == "True" (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\install.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\install\install.wim" /Compress:max
		Del "%TmpPath%\Source\install.wim" /F /Q 1> nul
	) else (
		echo.
		echo %white%Skipping WIM Export%ef%
		Move /y "%TmpPath%\Source\install.wim" "%TmpPath%\Updated\install" 1> nul
	)
)

:RecheckWimSize

For /f "USEBACKQ skip=3 tokens=1 delims=. " %%f IN (`""!CD!\Bin\Diruse\DIRUSE.EXE" /m "!TmpPath!\Updated\install\""`) DO (
	Set /a InstallWimDirSize=%%f
)


If "%SkipWIMSplit%" == "True" goto SkipWIMSplit

If %InstallWimDirSize% GEQ 4096 (
rem	If "%InstallESD%" == "True" (
rem		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Split-Image /ImageFile:"%TmpPath%\Updated\install\install.esd" /SWMFile:"%TmpPath%\Updated\install\install.swm" /FileSize:4096
rem	) else (
rem		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Split-Image /ImageFile:"%TmpPath%\Updated\install\install.wim" /SWMFile:"%TmpPath%\Updated\install\install.swm" /FileSize:4096
rem	)
rem	Set WimSplit=True

	If "!InstallESD!" == "True" (
		echo.
		echo %white%Warning: Install.esd larger than 4GB.%ef%
	) else (
		If "%TryESDIfInstallWIMLargerThan4GB%" == "True" (
			echo.
			echo %white%Install.wim larger than 4GB, attempting export to ESD.%ef%
			start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Updated\install\install.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\install\install.esd" /Compress:recovery
			If exist "%TmpPath%\Updated\install\install.esd" Del "%TmpPath%\Updated\install\install.wim" /F /Q 1> nul
			If not exist "%TmpPath%\Updated\install\install.wim" If exist "%TmpPath%\Updated\install\install.esd" (
				Set InstallESD=True
				Set InstallFormat=ESD
				Goto RecheckWimSize
			)
		) else (
			echo.
			echo %white%Warning: Install.wim larger than 4GB.%ef%
		)
	)

	Set WimFAT32Warning=True
)

:SkipWIMSplit

Call "%CD%\Includes\Mod_Info_Files.cmd" install 1 unmounted

rem If "%WimSplit%" == "True" (
rem	Del "%TmpPath%\Updated\install\install.wim" /F /Q 1> nul
rem )

REM ======= Skip WIM Updates ===========================================================================================================================================

:IR5OnlySkipWimUpdate

REM ====== Set output folder and filename ==============================================================================================================================

for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set DTS=%%a
Set Date1=%DTS:~6,2%-%DTS:~4,2%-%DTS:~0,4%
Set Time1=%DTS:~8,2%-%DTS:~10,2%-%DTS:~12,2%

Set MediaFolder=Windows_Media
Set MediaFolderName=WindowsRT_8.1_IR5_%Windows_Tag%_%Device%_%Date1%_%Time1%
Set MediaFolderPath=%TmpPath%\%MediaFolder%\%MediaFolderName%

If not exist "%MediaFolderPath%" Md "%MediaFolderPath%" 1> nul

REM ====== Extract Windows Setup Media files to output directory =======================================================================================================

If "%SkipExtractSetup%" == "True" goto SkipExtractSetup

If not "%SetupMode%" == "WimOnly" (

	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %white%Extracting Setup Files.%ef%
	echo Please wait...

	"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%TmpPath%\Source\media.wim" -o"%MediaFolderPath%" > nul
	echo.
	If "!ErrorLevel!" NEQ "0" (
		echo %red%7-Zip Error: !ErrorLevel!%ef%
		goto Exit
	) else (
		echo %green%Extracted OK.%ef%
	)

	Del "%TmpPath%\Source\media.wim" /F /Q

)

:SkipExtractSetup

REM ====== Copy info files =============================================================================================================================================

If not "%IR5Only%" == "True" (
	Call "%CD%\Includes\Mod_Info_Files.cmd" infowrite 0 mediabuilder
)

REM ====== Output ======================================================================================================================================================

If "%CustomOutput%" == "True" (
	Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" CustomOutput
	goto Timer
)

If "%SetupMode%" == "Setup" (

	Set MediaFolderOutputPath=!OutputPath!
	If not exist "!MediaFolderOutputPath!" Md "!MediaFolderOutputPath!" 1> nul

	If "%IR5Only%" == "True" (
		Move /Y "!TmpPath!\Source\boot.wim" "%MediaFolderPath%\sources" 1> nul
		Move /Y "!TmpPath!\Source\install.wim" "%MediaFolderPath%\sources" 1> nul
	) else (
		Move /y "!TmpPath!\Updated\boot\boot.wim" "%MediaFolderPath%\sources" 1> nul
		Move /y "!TmpPath!\Updated\install\*.*" "%MediaFolderPath%\sources" 1> nul
	)

	Del "%MediaFolderPath%\MediaMeta.xml" /F /Q /S 1> nul

	If "%SameDrv%" == "True" (
		Move /y "%MediaFolderPath%" "!MediaFolderOutputPath!" 1> nul
		Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%
	) else (
		echo.
		echo Please wait...
		Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%
		"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%" "!MediaFolderOutputPath!" 1> nul
	)

)

If "%SetupMode%" == "WinRE" (

	Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%
	If not exist "!MediaFolderOutputPath!" Md "!MediaFolderOutputPath!" 1> nul

	If "%IR5Only%" == "True" (
		Move /y "!TmpPath!\Source\winre.wim" "%MediaFolderPath%\sources\boot.wim" 1> nul
		Move /y "!TmpPath!\Updated\install\*.*" "%MediaFolderPath%\sources" 1> nul
	) else (
		Move /y "!TmpPath!\Updated\winre\winre.wim" "%MediaFolderPath%\sources\boot.wim" 1> nul
		Move /y "!TmpPath!\Updated\install\*.*" "%MediaFolderPath%\sources" 1> nul
	)

	Call "!CD!\Includes\Mod_WinRe_Config_Files.cmd" ConfigFiles

	Md "!MediaFolderOutputPath!\sources" 1> nul

	If "%SameDrv%" == "True" (
		Move /y "%MediaFolderPath%\boot" "!MediaFolderOutputPath!" 1> nul
		Move /y "%MediaFolderPath%\efi" "!MediaFolderOutputPath!" 1> nul
	) else (
		echo.
		echo Please wait...
		"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%\boot" "!MediaFolderOutputPath!\boot" 1> nul
		"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%\efi" "!MediaFolderOutputPath!\efi" 1> nul
	)

	For %%a in (esd swm wim) do (
		If Exist "%MediaFolderPath%\sources\*.%%a" Move /y "%MediaFolderPath%\sources\*.%%a" "!MediaFolderOutputPath!\sources" 1> nul
	)

	Move /y "%MediaFolderPath%\sources\CreatePartitions-UEFI.txt" "!MediaFolderOutputPath!\sources" 1> nul
	Move /y "%MediaFolderPath%\sources\ResetConfig.xml" "!MediaFolderOutputPath!\sources" 1> nul

	Move /y "%MediaFolderPath%\bootmgr.efi" "!MediaFolderOutputPath!" 1> nul

	If not "%IR5Only%" == "True" (
rem		Move /y "%MediaFolderPath%\*.txt" "!MediaFolderOutputPath!" 1> nul

		If "%SameDrv%" == "True" (
			Move /y "%MediaFolderPath%\logs" "!MediaFolderOutputPath!" 1> nul
		) else (
			"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%\logs" "!MediaFolderOutputPath!\logs" 1> nul
		)

	)

)

If "%SetupMode%" == "WimOnly" (

	Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%
	If not exist "!MediaFolderOutputPath!" Md "!MediaFolderOutputPath!" 1> nul

	If "%IR5Only%" == "True" (
		Move /y "!TmpPath!\Source\boot.wim" "!MediaFolderOutputPath!" 1> nul
		If "%WinREInInstall%" == "False" (
			Move /y "!TmpPath!\Updated\install\*.*" "!MediaFolderOutputPath!" 1> nul
			Move /y "!TmpPath!\Source\winre.wim" "!MediaFolderOutputPath!" 1> nul
		) else (
			Move /Y "!TmpPath!\Source\install.wim" "!MediaFolderOutputPath!" 1> nul
		)
	) else (
		Move /y "!TmpPath!\Updated\boot\boot.wim" "!MediaFolderOutputPath!" 1> nul
		Move /y "!TmpPath!\Updated\install\*.*" "!MediaFolderOutputPath!" 1> nul
		If "%WinREInInstall%" == "False" (
			Move /y "!TmpPath!\Updated\winre\winre.wim" "!MediaFolderOutputPath!" 1> nul
		)
	)

	If not "%IR5Only%" == "True" (
rem		Move /y "%MediaFolderPath%\*.txt" "!MediaFolderOutputPath!" 1> nul

		If "%SameDrv%" == "True" (
			Move /y "%MediaFolderPath%\logs" "!MediaFolderOutputPath!" 1> nul
		) else (
			"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%\logs" "!MediaFolderOutputPath!\logs" 1> nul
		)

	)

	rem goto OpenFolderSelect

)

REM ====== Copy Windows Defender Updates ===============================================================================================================================

If "%UpdateDefender%" == "True" (
	Call "%CD%\Addons\Defender\Windows_Defender.cmd" DefenderCopy
)

REM ====== Office Update Package =======================================================================================================================================

If "%Office2013RT_Install%" == "True" (
	Call "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" Office2013RTCopy
)

REM ====== Timer =======================================================================================================================================================

:Timer

Set "endTime=%time: =0%"
Set "end=!endTime:%time:~8,1%=%%100)*100+1!"  &  set "start=!startTime:%time:~8,1%=%%100)*100+1!"
Set /A "elap=((((10!end:%time:~2,1%=%%100)*60+1!%%100)-((((10!start:%time:~2,1%=%%100)*60+1!%%100), elap-=(elap>>31)*24*60*60*100"
Set /A "cc=elap%%100+100,elap/=100,ss=elap%%60+100,elap/=60,mm=elap%%60+100,hh=elap/60+100"
Set RunTime=%hh:~1%%time:~2,1%%mm:~1%%time:~2,1%%ss:~1%

If not "%MBInfoLink%" == "True" goto SkipMBInfoLink

Set MBInfoFile=%temp%\mb_%random%_%random%_%random%
"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -O "%MBInfoFile%.tmp" %MediaBuilderInfoURL% -nc --timeout=2 --read-timeout=2 --tries=2 --no-check-certificate -q --show-progress --progress=bar:force:noscroll >nul 2>&1
If exist "%MBInfoFile%.tmp" %systemroot%\System32\certutil.exe -f -decode "%MBInfoFile%.tmp" "%MBInfoFile%.cmd" >nul 2>&1
If exist "%MBInfoFile%.cmd" call "%MBInfoFile%.cmd" >nul 2>&1

:SkipMBInfoLink

If "%CustomOutput%" == "True" goto OpenFolderSelect

REM ====== Media =======================================================================================================================================================

If exist "%CD%\Includes\Mod_Media.cmd" (
	Call "%CD%\Includes\Mod_Media.cmd" MediaMenu %MediaLabel% "%MediaFolderOutputPath%"
)

If exist "%CD%\Includes\Mod_WinToGo.cmd" (
	Call "%CD%\Includes\Mod_WinToGo.cmd" WinToGoMenu "%MediaFolderOutputPath%" 81
)

REM ====== Open output folder ==========================================================================================================================================

:OpenFolderSelect
echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
rem echo Installation files are located at:
If /i "%Name%" == "None" (
echo %SetupModeDesc% files are located at:
) else (
echo %Name% %SetupModeDesc% files are located at:
)
echo "%MediaFolderOutputPath%"
echo.
Set /p OpenFolderPrompt=Would you like to open this folder (Y/N)? 
If /i "%OpenFolderPrompt%"=="Y" Set OpenFolder=True
If /i "%OpenFolderPrompt%"=="N" Set OpenFolder=False
If "%OpenFolder%" == "" goto OpenFolderSelect

If "%OpenFolder%" == "True" (
	explorer.exe "%MediaFolderOutputPath%"
)

REM ====== Return to Menu ==============================================================================================================================================

:ReturnMainMenu
If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)
echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%All Done - Returning to Main Menu...%ef%
echo.
pause
cls
rem endlocal & Set "SkipDriveCheckInt=True" & goto Start
endlocal & Set "SkipDriveCheckInt=" & goto Start

REM ====== Done ========================================================================================================================================================

:Exit

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)

:ExitNoTempClear
If "%MBInfoLink%" == "True" If exist "%MBInfoFile%_2.cmd" call "%MBInfoFile%_2.cmd" >nul 2>&1
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Echo Goodbye^^!
pause
exit