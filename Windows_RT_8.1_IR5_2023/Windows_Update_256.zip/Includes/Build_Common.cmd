@echo off

REM ====== Set =========================================================================================================================================================

Set CommonStage=%1
Set CalledFromFile=%2
Set ForceUpdateArg=%3

If "%CommonStage%" == "" (
	goto BuildCommonComplete
) else (
	goto %CommonStage%
)

:BuildCommon

REM ====== Root ========================================================================================================================================================

If "%__CD__:~3%"=="" (
	echo Error: Media Builder should not be run from the root directory.
	Set BuildAbort=True
	goto BuildCommonComplete
)

REM ====== Config ======================================================================================================================================================

If exist "%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" Set TorrentClientFound=True

If exist "%CD%\Includes\Build_Config.cmd" (
	Call "%CD%\Includes\Build_Config.cmd" BuildConfig
) else (
	echo Error: File Missing...
	echo "!CD!\Includes\Build_Config.cmd"
	Set BuildAbort=True
	goto BuildCommonComplete
)

If not exist "%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" Set ArchiveOrgTorrent=False

If "%BundledDISM%" == "True" (
	Set DISMEXE=!CD!\Bin\DISM\!PROCESSOR_ARCHITECTURE!\dism.exe
) else (
	Set DISMEXE=dism.exe
)

REM ====== Check Windows Version =======================================================================================================================================

Set /a WinVerMinMajor=10
Set /a WinVerMinBuild=15063

For /f "tokens=3" %%a in ('%SystemRoot%\System32\reg.exe query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v CurrentBuild ^| %SystemRoot%\System32\findstr.exe /r /i "REG_SZ"') do (
	Set /a WinVerBuild=%%a
)

:BuildNumber
If %WinVerBuild% GEQ %WinVerMinBuild% (
	Set Supported=True
)

If /i "%SkipOSCheck%" == "True" (
	Set Supported=True
	Mode con:cols=120 lines=30
	Set UseCMDColours=False
)

If not "%Supported%" == "True" (
	Mode con:cols=120 lines=30
	echo Error: Unsupported Operating System.
	echo Please retry on Windows %WinVerMinMajor% Build %WinVerMinBuild% or above.
	Set BuildAbort=True
	goto BuildCommonComplete
)

REM ====== Language ====================================================================================================================================================

For /f "skip=3 tokens=1-3" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-Culture"') do Set Culture=%%b
For /f "skip=3 tokens=1-3" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-UICulture"') do Set UICulture=%%b

REM ====== Colours =====================================================================================================================================================

If "%UseCMDColours%" == "True" (
	Set black=[30m
	Set cyan=[36m
	Set green=[92m
	Set red=[91m
	Set white=[97m
	Set blue=[94m
	Set dblue=[34m
	Set magenta=[35m
	Set warn=[41;93m
	Set info=[104;97m
	Set ul=[4m
	Set ef=[0m
	Set ESC=[
	Set Line1=!ESC!1F
	Set Line2=!ESC!1F!ESC!0J
	Set Line3=!ESC!3F
	Set Line4=!ESC!4F
)

REM ====== Check architecture ==========================================================================================================================================

If "%PROCESSOR_ARCHITECTURE%" == "AMD64" goto SupportedArch
If "%PROCESSOR_ARCHITECTURE%" == "x86" goto SupportedArch

echo %red%Error: Using this kit on %PROCESSOR_ARCHITECTURE% systems is not supported.%ef%
echo %red%Please retry on an x86 or x64 system.%ef%
Set BuildAbort=True
goto BuildCommonComplete

:SupportedArch

REM ====== Check if being run as admin =================================================================================================================================

For /f "tokens=1,2,3,4 USEBACKQ delims=," %%a IN (`"%SystemRoot%\System32\whoami.exe /groups /fo csv /nh"`) Do (
	If %%c == "S-1-16-12288" Set RunAsAdmin=True
)

If not "%RunAsAdmin%" == "True" (
	echo %red%Error: Please run Media Builder as administrator.%ef%
	Set BuildAbort=True
	goto BuildCommonComplete
)

REM ====== Check if running from command line ==========================================================================================================================

Set BuildCmdPath=%cmdcmdline:"=%
Set BuildDirPath=!BuildCmdPath:%CalledFromFile%=!

If not "%BuildCmdPath%" NEQ "%BuildDirPath%" (
	echo %red%Error: Please run Media Builder by right clicking on "Build.cmd" and selecting "Run as Administrator".%ef%
	Set BuildAbort=True
	goto BuildCommonComplete
)

REM ====== Startup Actions =============================================================================================================================================

:ForceUpdateCheck
If /i "!ForceUpdateArg!" == "True" (
	Set MBFirstRunInt=True
	Set TempRunStartUpActions=!RunStartUpActions!
	Set RunStartUpActions=True
)

If /i not "!MBFirstRunInt!" == "True" goto MBSkipStartUpActionsConig
If /i "%RunStartUpActions%" == "True" (
	Set MBStartUp=!TMP!\MB_Build_Startup_!random!_!random!
	"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -O "!MBStartUp!" "!WindowsListsURL!_Config" -nc --timeout=2 --read-timeout=2 --tries=2 --no-check-certificate -q --show-progress --progress=bar:force:noscroll >nul 2>&1
	If "!ErrorLevel!" EQU "0" (
		For /f "usebackq skip=1 tokens=*" %%a in ("!MBStartUp!") do (
			For /f "tokens=1* delims==" %%a in ("%%a") do (
				If not "%%b" == "" Set "%%a=%%b"
			)
		)
	)
	If Exist "!MBStartUp!" Del "!MBStartUp!" /F /Q >nul 2>&1
)

If exist "%CD%\Temp.cmd" Call "%CD%\Temp.cmd" MBTempScript
:MBSkipStartUpActionsConig

REM ====== Run Startup Actions =========================================================================================================================================

If /i not "!MBFirstRunInt!" == "True" goto MBSkipStartUpActions
If /i "%MBStartUpActions%" == "True" (

	If not "%MBStartUpActionsMsg%" == "" (
		echo.
		echo %MBStartUpActionsMsg%
		If /i not "%MBStartUpActionsExit%" == "True" (
			echo.
			pause
		)
	)

	If not "%MBStartUpActionsRun%" == "" (
		start /b /wait "" "%MBStartUpActionsRun%"
	)

	If /i "%MBStartUpActionsRunScript%" == "True" (
		Set MBScript=MB_Update_Script_!random!_!random!
		"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -O "!TMP!\!MBScript!" "!WindowsListsURL!_Script" -nc --timeout=2 --read-timeout=2 --tries=2 --no-check-certificate -q --show-progress --progress=bar:force:noscroll >nul 2>&1
		If "!ErrorLevel!" EQU "0" (
			If exist "!TMP!\!MBScript!" Rename "!TMP!\!MBScript!" "!MBScript!.cmd"
			If exist "!TMP!\!MBScript!.cmd" Call "!TMP!\!MBScript!.cmd"
			If exist "!TMP!\!MBScript!.cmd" Del "!TMP!\!MBScript!.cmd" /F /Q >nul 2>&1
			If /i "!MBScriptExit!" == "True" exit
		)
	)

	If /i "%MBStartUpActionsExit%" == "True" (
		Set BuildAbort=True
		goto BuildCommonComplete
	)

)
:MBSkipStartUpActions

If /i "!ForceUpdateArg!" == "True" (
	Set MBFirstRunInt=False
	Set RunStartUpActions=!TempRunStartUpActions!
	Set TempRunStartUpActions=False
	Set ForceUpdateArg=False
	goto BuildCommonComplete
)

REM ====== Download List Update ========================================================================================================================================

If /i "!DisableDownloadListUpdates!" == "True" goto MBSkipStartUpActionsDownloadList
If /i not "!MBFirstRunInt!" == "True" goto MBSkipStartUpActionsDownloadList
If /i not "%RunStartUpActions%" == "True" goto MBSkipStartUpActionsDownloadList

Set UpdateListsStartUpCheck=True
Call "%CD%\Includes\Build_UpdateLists.cmd" UpdateAllLists > nul
Set UpdateListsStartUpCheck=False

If /i "!OfferListDownload!" == "True" (
	Call "%CD%\Includes\Build_UpdateLists.cmd" UpdateAllLists
	cls
	echo Please wait...
)
Set MBFirstRunInt=False

:MBSkipStartUpActionsDownloadList

REM ====== Service Check ===============================================================================================================================================

For %%z in (
	smphost#False
) do (
	For /f "tokens=1-2 delims=#" %%a in ("%%z") do (

		If not "!SkipServiceChecks!" == "True" (
			"%systemroot%\System32\sc.exe" query %%a > nul
			If !ErrorLevel! EQU 0 Set MBServiceFound-%%a=True
		)

		If not "!MBServiceFound-%%a!" == "True" (
			Set MBServiceFound-%%a=False
			If "!SkipServiceChecks!" == "True" (
				If /i not "%SkipDriveCheckInt%" == "True" echo %red%Error: Service Checks Disabled.%ef%
			) else (
				If /i not "%SkipDriveCheckInt%" == "True" echo %red%Error: Service Not Installed "%%a".%ef%
			)
			Set ServiceFound=False
			If /i "%%b" == "True" Set ServiceAbort=True
		) 

		If "!MBServiceFound-%%a!" == "True" (
			For /f "usebackq tokens=1-3 delims=: " %%c IN (`""%systemroot%\system32\sc.exe" qc %%a 2>NUL"`) do (
				If /i "%%c" == "START_TYPE" (
					If /i "%%e"=="DISABLED" (
						Set MBServiceFound-%%a=False
						If /i not "%SkipDriveCheckInt%" == "True" echo %red%Error: Service Disabled "%%a".%ef%
						Set ServiceFound=False
						If /i "%%b" == "True" Set ServiceAbort=True
					)
				)
			)
		)

	)

)

If "!ServiceFound!" == "False" (
	If "!ServiceAbort!" == "True" (
		Set BuildAbort=True
		goto BuildCommonComplete
	) else (
		If /i not "%SkipDriveCheckInt%" == "True" (
			echo.
			echo %red%Warning: Media Builder may not run correctly on this device and some functions may be disabled.%ef%
			echo.
			pause
		)
	)
)

REM ====== Are Tmp and Output on same drive ============================================================================================================================

For %%d in ("%DownloadsPath%") do Set DownloadsDrv=%%~dd
For %%t in ("%TmpPath%") do Set TmpDrv=%%~dt
For %%o in ("%OutputPath%") do Set OutputDrv=%%~do
If /i "%TmpDrv%" == "%OutputDrv%" Set SameDrv=True

REM ====== Check Media Builder TMP location ============================================================================================================================

If not "!TmpPath:~%TmpFolderPathLen%,1!" == "" (
	echo.
	echo Checking path length to Media Builder Tmp directory.
	Set TmpPathError=%red%Error: The path length to the "Tmp" directory is over %TmpFolderPathLen% characters. Select a shorter path.%ef%
	echo !TmpPathError!
	echo %red%Current Path: "%TmpPath%"%ef%
	Set SettingsErrorList=!SettingsErrorList!;"!TmpPathError!"
	Set BuildAbort=True
)

REM ====== Free Space / Filesystem / Drive Checks ======================================================================================================================

If "%BulkMode%" == "True" (
	Set /a OutputFolderSpaceReq=%OutputFolderSpaceReq%+%BulkModeOutputFolderSpaceReq%
	Set /a DownloadsSpaceReq=%DownloadsSpaceReq%+%BulkModeDownloadsSpaceReq%
)

If exist "!DownloadsPath!" (
	For /f "USEBACKQ skip=3 tokens=1 delims=. " %%a IN (`""!CD!\Bin\Diruse\DIRUSE.EXE" /m "!DownloadsPath!""`) DO (
		Set /a CurrentDownloadSizeGB=%%a/1024
	)
	If !CurrentDownloadSizeGB! GTR 0 (
		Set /a DownloadsSpaceReq=!DownloadsSpaceReq!-!CurrentDownloadSizeGB!
	)
)

For %%a in (
	"%DownloadsDrv:~0,1%#%DownloadsSpaceReq%"
	"%TmpDrv:~0,1%#%TmpFolderSpaceReq%"
	"%OutputDrv:~0,1%#%OutputFolderSpaceReq%"
	"%TMP:~0,1%#%SysDriveSpaceReq%"
) do (
	For /f "tokens=1-2 delims=#" %%a in (%%a) do (
		Set /a %%a_SpaceNeeded+=%%b
		echo !MediaBuilderDriveList!|find /i "%%a_SpaceNeeded">nul  || Set MediaBuilderDriveList=!MediaBuilderDriveList!;%%a_SpaceNeeded
	)
)

If "!MBServiceFound-smphost!" == "False" goto SkipDriveChecks

For %%a in (
	!MediaBuilderDriveList!
) do (
	Set DriveToCheck=%%a
	Set DriveToCheck=!DriveToCheck:~0,1!
	For %%z in (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
		Set DriveToCheck=!DriveToCheck:%%z=%%z!
	)
	Set /a DriveSpaceNeeded=!%%a!
	If /i not "%SkipDriveCheckInt%" == "True" echo.

	For /f "skip=2 tokens=1" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-Partition -DriveLetter !DriveToCheck:~0,1! | Select-Object DiskNumber | ConvertTo-Csv"') do (
		Set DriveNumberAvoidList=!DriveNumberAvoidList!;%%~a
	)

	If /i not "%SkipDriveCheckInt%" == "True" If /i "%SkipDriveSpaceCheck%" == "False" (
		echo Checking free space on !DriveToCheck!:
rem		For /f "skip=3 tokens=*" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-Volume -DriveLetter !DriveToCheck! | Select-Object {[math]::Round($_.SizeRemaining/1GB)}"') do Set /a DriveSpaceFound=%%a
rem		For /f "skip=3 delims=. tokens=1" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-Volume -DriveLetter !DriveToCheck! | Select-Object {$_.SizeRemaining/1GB}"') do Set /a DriveSpaceFound=%%a
		For /f "skip=3 tokens=*" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-Volume -DriveLetter !DriveToCheck! | Select-Object {[int]($_.SizeRemaining/1GB)}"') do Set /a DriveSpaceFound=%%a
		If not !DriveSpaceFound! GEQ !DriveSpaceNeeded! (
			Set /a DriveSpaceExtraNeeded=!DriveSpaceNeeded!-!DriveSpaceFound!"
rem			echo %red%Error: There is not enough free space on drive !DriveToCheck!:. You need an additional !DriveSpaceExtraNeeded!GB to proceed.%ef%
			Set DiskSpaceError=%red%Error: There is not enough free space on drive "!DriveToCheck!:". An additional !DriveSpaceExtraNeeded!GB is required.%ef%
			echo !DiskSpaceError!
			Set SettingsErrorList=!SettingsErrorList!;"!DiskSpaceError!"
			Set BuildAbort=True
		)
	)

	If /i not "%SkipDriveCheckInt%" == "True" If /i "%SkipDriveFileSystemCheck%" == "False" (
		echo Checking file system on !DriveToCheck!:
		For /f "skip=3 tokens=*" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-Volume -DriveLetter !DriveToCheck! | Select-Object FileSystem"') do Set DriveFileSystem=%%a
		If /i not "!DriveFileSystem: =!" == "NTFS" (
rem			echo %red%Error: Media Builder cannot use an !DriveFileSystem: =! volume, please try again on an NTFS volume.%ef%
			Set FileSystemError=%red%Error: Media Builder cannot use the !DriveFileSystem: =! file system on drive "!DriveToCheck!:". An NTFS file system is required.%ef%
			echo !FileSystemError!
			Set SettingsErrorList=!SettingsErrorList!;"!FileSystemError!"
			Set BuildAbort=True
		)
	)

)

:SkipDriveChecks

If "%BuildAbort%" == "True" (

	If not exist "%CD%\Includes\Build_Settings.cmd" goto BuildCommonComplete

	:OpenSettingsSelect
	echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Set /p OpenSettingsPrompt=Would you like to open the Media Builder Path Settings Menu ^(Y/N^)? 
	If /i "!OpenSettingsPrompt!"=="Y" Set OpenSettings=True
	If /i "!OpenSettingsPrompt!"=="N" Set OpenSettings=False
	If "!OpenSettings!" == "" goto OpenSettingsSelect

	If "!OpenSettings!" == "True" (
		Set PathChange=False
		Set BuildRestart=False

		Call "%CD%\Includes\Build_Settings.cmd" Build_Settings_Start

		If "!IgnoreErrors!" == "True" (
			Set BuildAbort=False
			goto SkipDriveChecks
		)

	)

	goto BuildCommonComplete
) else (
	cls
)

REM ====== Check not running form USB ==================================================================================================================================

for /f "skip=3 tokens=1,2 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; Get-CimInstance CIM_LogicalDisk | Select-Object DeviceID, DriveType | Where-Object { $_.DriveType -ne $null}"') do (
	Set Caption=%%a
	Set /a DriveType=%%b

	If "!DriveType!" equ "3" (
		If /i "%~d0" == "!Caption!" (
			Set IsFixedDisk=True
			goto RunningFromFixedDisk
		)
	)
)

:RunningFromFixedDisk

If not "!IsFixedDisk!" == "True" (
	echo %red%Error: Please run Media Builder from a fixed disk.%ef%
	Set BuildAbort=True
	goto BuildCommonComplete
)

REM ====== Check nothing vital missing =================================================================================================================================

Set MBFileList=%CD%\Includes\Build_FileList

For /f "usebackq tokens=*" %%c in ("%MBFileList%") do (
	If not exist "%CD%\%%c" (
		echo %red%Error: File Missing...%ef%
		echo !CD!\%%c
		Set BuildAbort=True
		goto BuildCommonComplete
	)
)

REM ====== Set DISM Log Filename =======================================================================================================================================

If not exist "%DISMLogPath%" md "%DISMLogPath%" 1> nul

For /l %%n in (1,1,99999) do (
	Set DISMLogNum=00000%%n
	Set DISMLogFileTest=!DISMLogFile!-!DISMLogNum:~-5!.!DISMLogFileExt!
	If not exist "%DISMLogPath%\!DISMLogFileTest!" (
		Set DISMLogCurrent=!DISMLogFileTest!
		goto DISMLogSet
	)
	Set DISMLogCurrent=!DISMLogFile!.!DISMLogFileExt!
)

:DISMLogSet

goto BuildCommonComplete

REM ====== End =========================================================================================================================================================

:BuildCommonComplete

If "%CommonStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "CommonStage="