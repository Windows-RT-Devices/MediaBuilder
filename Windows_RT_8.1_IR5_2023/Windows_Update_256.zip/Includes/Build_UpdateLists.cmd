@echo off

REM ====== Set =========================================================================================================================================================

Set UpdateDownloadListsStage=%1

If "%UpdateDownloadListsStage%" == "" (
	goto UpdateDownloadListsComplete
) else (
	goto %UpdateDownloadListsStage%
)

REM ====== Update Lists ================================================================================================================================================

:UpdateAllLists
Set Products=
Set ProductsToUpdate=
Set OfferListDownload=
Set UpdateConfirm=
cls
echo %ul%________________________________________________________________________________________________________________________%ef%
If "!MBFirstRunInt!" == "True" (
echo.
) else (
echo.
echo %white%Update Download Lists%ef%
echo.
echo Updates to Windows Media Builder download lists are generally made available after the second Tuesday of each
echo month for any products still being supported, the lists may also be updated as needed if there are changes to 
echo the location of the files referenced in the lists.
echo.
)
echo %white%Checking for updated download lists.%ef%
echo Please wait.
echo.

Set Products="Windows#%CD%\Download_Lists\Last_Updated#!WindowsListsURL!"

If exist "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" (
	Set Products=!Products!;"Office#%CD%\Addons\Office\Download_Lists\Last_Updated#!OfficeListsURL!"
)

If exist "%CD%\Addons\Defender\Windows_Defender.cmd" (
	Set Products=!Products!;"Defender#%CD%\Addons\Defender\Download_Lists\Last_Updated#!DefenderListsURL!"
)

For %%a in (
	!Products!
) do (

	Set CurrentProduct=%%a

	For /f "tokens=1-3 delims=#" %%a in (%%a) do (
		Set ProductToUpdate=%%a
		Set LocalUpdateListPath=%%b
		Set LocalUpdateListDir=%%~dpb
		Set RemoteUpdateListURL=%%c

		If not exist "!LocalUpdateListPath!" (

			If not exist "!LocalUpdateListDir!" md "!LocalUpdateListDir!" 1> nul
			(
				echo 0#March 2022
			) > "!LocalUpdateListDir!\Last_Updated"			
			
			If not exist "!LocalUpdateListDir!\Last_Updated" (
				echo %red%Error: Unable to check for updated !ProductToUpdate! download lists.%ef%	
				pause
				goto UpdateDownloadListsComplete
			)
		)

		Set /p LocalUpdateListPath=< !LocalUpdateListPath!
		For /f "tokens=1-2 delims=#" %%a in ("!LocalUpdateListPath!") do (
			Set /a LocalUpdateListVersion=%%a
			Set LocalUpdateListRelease=%%b
		)

		Set UpdateTemp=!TmpPath!\ListUpdate\!ProductToUpdate!\%random%
		md "!UpdateTemp!" 1> nul

		"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" !RemoteUpdateListURL! -P "!UpdateTemp!" -nc --timeout=2 --read-timeout=2 --tries=2 --no-check-certificate -q --show-progress --progress=bar:force:noscroll 1> nul 2> nul
		If not !ErrorLevel! EQU 0 (
			echo 	%red%Error: Unable to check for updated !ProductToUpdate! download lists.%ef%
			echo 	Wget Error: !ErrorLevel!
		) else (

			Set /p RemoteUpdateListTemp=< "!UpdateTemp!\!ProductToUpdate!"
			For /f "tokens=1-4 delims=#" %%a in ("!RemoteUpdateListTemp!") do (
				Set /a RemoteUpdateListVersion=%%a
				Set RemoteUpdateListRelease=%%b
				Set RemoteUpdateListPackageURL=%%c
				Set RemoteUpdateListPackageFileName=%%~NXc
				Set RemoteUpdateListSHA1=%%d
			)

rem			Set LocalListsFound=Installed !ProductToUpdate! download list: %white%!LocalUpdateListRelease! - v!LocalUpdateListVersion:~0,1!.!LocalUpdateListVersion:~1,2!%ef%
			Set LocalListsFound=Installed !ProductToUpdate! download list: %white%!LocalUpdateListRelease!%ef%
		
			If !RemoteUpdateListVersion! GTR !LocalUpdateListVersion! (
rem				Set RemoteListsFound=%green%^(Update Found: !RemoteUpdateListRelease! - v!RemoteUpdateListVersion:~0,1!.!RemoteUpdateListVersion:~1,2!^)%ef%
				Set RemoteListsFound=%green%^(Update Found: !RemoteUpdateListRelease!^)%ef%
				Set OfferListDownload=True
				Set ProductsToUpdate=!ProductsToUpdate!;!CurrentProduct!
			) else (
				Set RemoteListsFound=%red%^(No Update Found^)%ef%
			)

			echo 	!LocalListsFound! !RemoteListsFound!

		)

	)

)

echo.

If not "!OfferListDownload!" == "True" (
	If /i not "!UpdateListsStartUpCheck!" == "True" pause
	goto UpdateDownloadListsComplete
)

If "!UpdateListsStartUpCheck!" == "True" (
	goto UpdateDownloadListsComplete
)

Set UpdateConfirmPrompt=
Set /p UpdateConfirmPrompt=Would you like to update the download lists (Y/N)? 
If /i "!UpdateConfirmPrompt!"=="Y" Set UpdateConfirm=True
If /i "!UpdateConfirmPrompt!"=="N" Set UpdateConfirm=False
If "%UpdateConfirm%" == "" goto UpdateAllLists
echo %ul%________________________________________________________________________________________________________________________%ef%
If "%UpdateConfirm%" == "False" goto UpdateDownloadListsComplete
echo.

For %%a in (
	!ProductsToUpdate!
) do (

	For /f "tokens=1-3 delims=#" %%a in (%%a) do (
		Set ProductToUpdate=%%a
		Set LocalUpdateListPath=%%b
		Set LocalUpdateListDir=%%~dpb
		Set RemoteUpdateListURL=%%c

		If not exist "!LocalUpdateListPath!" (

			If not exist "!LocalUpdateListDir!" md "!LocalUpdateListDir!" 1> nul
			(
				echo 0#March 2022
			) > "!LocalUpdateListDir!\Last_Updated"			
			
			If not exist "!LocalUpdateListDir!\Last_Updated" (
				echo %red%Error: Unable to check for updated !ProductToUpdate! download lists.%ef%	
				pause
				goto UpdateDownloadListsComplete
			)
		)

		Set /p LocalUpdateListPath=< !LocalUpdateListPath!
		For /f "tokens=1-2 delims=#" %%a in ("!LocalUpdateListPath!") do (
			Set /a LocalUpdateListVersion=%%a
			Set LocalUpdateListRelease=%%b
		)

		Set UpdateTemp=!TmpPath!\ListUpdate\!ProductToUpdate!\%random%
		md "!UpdateTemp!" 1> nul

rem		echo %white%Checking for updated !ProductToUpdate! download lists.%ef%
rem		echo Please wait...
rem		echo.
		"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" !RemoteUpdateListURL! -P "!UpdateTemp!" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll 1> nul 2> nul
		If not !ErrorLevel! EQU 0 (
			echo %red%Error: Unable to check for updated !ProductToUpdate! download lists.%ef%
			echo Wget Error: !ErrorLevel!
			pause
			goto UpdateDownloadListsComplete
		)

		Set /p RemoteUpdateListTemp=< "!UpdateTemp!\!ProductToUpdate!"
		For /f "tokens=1-4 delims=#" %%a in ("!RemoteUpdateListTemp!") do (
			Set /a RemoteUpdateListVersion=%%a
			Set RemoteUpdateListRelease=%%b
			Set RemoteUpdateListPackageURL=%%c
			Set RemoteUpdateListPackageFileName=%%~NXc
			Set RemoteUpdateListSHA1=%%d
		)

rem		echo %white%Currently installed download lists: !LocalUpdateListRelease!.%ef%
		
		If !RemoteUpdateListVersion! GTR !LocalUpdateListVersion! (
rem			echo %green%Updated download lists for !ProductToUpdate! found: !RemoteUpdateListRelease!.%ef%
			echo %white%Downloading !ProductToUpdate! Download Lists.%ef%
			echo Please wait..
			"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" !RemoteUpdateListPackageURL! -P "!UpdateTemp!" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll 1> nul 2> nul
			If !ErrorLevel! EQU 0 (
				Set UpdateLists=True
rem				echo.
			) else (
				echo.
				echo Error: Unable to download !ProductToUpdate! download lists.
				echo Wget Error: !ErrorLevel!
				pause
				goto UpdateDownloadListsComplete
			)

		) else (
			Set UpdateLists=False
rem			echo %white%No updated !ProductToUpdate! download lists found.%ef%
rem			echo.
		)

		If "!UpdateLists!" == "True" (
			
			If /i "%SHA1Check%" == "True" (

				For /f "delims=" %%_ in ('%SystemRoot%\System32\certutil.exe -hashfile "!UpdateTemp!\!RemoteUpdateListPackageFileName!" SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
					Set x=%%_
					Set RemoteUpdateListFoundSHA1=!x: =!
				)

				If /i not "!RemoteUpdateListSHA1!" == "!RemoteUpdateListFoundSHA1!" (
					echo %red%File Bad: !UpdateTemp!\!RemoteUpdateListPackageFileName!%ef%
					pause
					goto UpdateDownloadListsComplete	
				) else (
					echo %green%Downloaded Successfully%ef%
					echo.
				)

			) else (
				echo.
			)

			echo %white%Extracting !ProductToUpdate! Download Lists.%ef%
			echo Please wait...

			"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "!UpdateTemp!\!RemoteUpdateListPackageFileName!" -aoa -o"!LocalUpdateListDir!" 1> nul 2> nul
			If not !ErrorLevel! EQU 0 (
				echo.
				echo %red%Error: Unable to extract file.%ef%
				echo 7-Zip Error: !ErrorLevel!
				pause
				goto UpdateDownloadListsComplete
			) else (
				echo %green%Extracted Successfully%ef%
			)
			echo.
		)

	)

)

pause
goto UpdateDownloadListsComplete

REM ====== End =========================================================================================================================================================

:UpdateDownloadListsComplete

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)

If "%UpdateDownloadListsStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "UpdateDownloadListsStage="