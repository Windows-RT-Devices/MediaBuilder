@echo off

REM ====== Set =========================================================================================================================================================

Set MiscStage=%1

If "%MiscStage%" == "" (
	goto MiscComplete
) else (
	goto %MiscStage%
)

REM ====== Update Lists ================================================================================================================================================

:MiscMenu
cls

If exist "%CD%\Addons\JailbreakUSB\JailbreakUSB" (
	Set /p JBUSBText=<"%CD%\Addons\JailbreakUSB\JailbreakUSB"
) else (
	Set JBUSBText=Jailbreak USB
)

Set MiscTarget=

echo !MenuText!
echo.
echo %white%Miscellaneous:%ef%	 Q: Build QEMU Click-to-Run Package
If exist "%CD%\Addons\JailbreakUSB\JailbreakUSB.cmd" (
echo 		 J: Write !JBUSBText!
)
echo.

If /i not "!DisableDownloadListUpdates!" == "True" (
	echo 		 U: Update Media Builder ^(Download Lists Only^)
	echo.
)

If /i not "!DisableMediaBuilderUpdates!" == "True" (
	echo 		 B: Update Media Builder ^(Full Update^)
	echo.
)

echo			 E: %red%Exit Miscellaneous%ef%
echo. %white%
Set /p MiscTarget=Enter Selection: 
echo. %ef%

If /i not "!DisableDownloadListUpdates!" == "True" If exist "%CD%\Includes\Build_UpdateLists.cmd" If /i "%MiscTarget%"=="U" (
	Call "%CD%\Includes\Build_UpdateLists.cmd" UpdateAllLists
	goto MiscComplete
)

If /i not "!DisableMediaBuilderUpdates!" == "True" If /i "%MiscTarget%"=="B" (
	goto MiscComplete
)

If exist "%CD%\Addons\JailbreakUSB\JailbreakUSB.cmd" If /i "%MiscTarget%"=="J" (
	Call "%CD%\Addons\JailbreakUSB\JailbreakUSB.cmd" JailbreakMenu
	goto MiscComplete
)

If /i "%MiscTarget%"=="Q" (
	goto MiscComplete
)

If /i "%MiscTarget%"=="E" goto MiscComplete

goto MiscMenu

REM ====== End =========================================================================================================================================================

:MiscComplete

If "%MiscStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "MiscStage="