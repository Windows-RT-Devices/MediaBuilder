@echo off

REM ====== Make Install Media ==========================================================================================================================================

Set WinToGoMode=%1
Set WinToGoSource=%2
Set WinToGoOS=%3

If "%WinToGoMode%" == "WinToGoMenu" (
	goto WinToGoMenu
) else (
	goto WinToGoComplete
)

REM ====== Media =======================================================================================================================================================

:WinToGoMenu

If "!MBServiceFound-smphost!" == "False" goto WinToGoComplete
If "%SetupMode%" == "WinRE9600" goto WinToGoComplete
If "%WinToGo%" == "False" goto WinToGoComplete

:MakeWinToGoUSBMediaSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set MakeWinToGoUSBMediaPrompt=
Set /p MakeWinToGoUSBMediaPrompt=Would you like to create Windows to Go USB Media (Y/N)? 
If /i "%MakeWinToGoUSBMediaPrompt%"=="Y" goto WinToGoInfo
If /i "%MakeWinToGoUSBMediaPrompt%"=="N" goto WinToGoComplete
If "%MakeWinToGoUSBMedia%" == "" goto MakeWinToGoUSBMediaSelect

:WinToGoInfo


:MakeWinToGoUSBMediaSkipOOBESelect
If not exist "%CD%\Includes\Mod_WinToGo_SkipOOBE.cmd" (
	Set MakeWinToGoUSBMediaSkipOOBE=False
	goto MakeWinToGoUSBMediaAllowInternalDisksSelect
)
echo.
Set MakeWinToGoUSBMediaSkipOOBEPrompt=
Set /p MakeWinToGoUSBMediaSkipOOBEPrompt=Would you like to use an unattend.xml to skip the Windows Out Of Box Experience (Y/N)? 
If /i "%MakeWinToGoUSBMediaSkipOOBEPrompt%"=="Y" Set MakeWinToGoUSBMediaSkipOOBE=True
If /i "%MakeWinToGoUSBMediaSkipOOBEPrompt%"=="N" Set MakeWinToGoUSBMediaSkipOOBE=False
If "%MakeWinToGoUSBMediaSkipOOBE%" == "" goto MakeWinToGoUSBMediaSkipOOBESelect

:MakeWinToGoUSBMediaAllowInternalDisksSelect
echo.
Set MakeWinToGoUSBMediaAllowInternalDisksPrompt=
Set /p MakeWinToGoUSBMediaAllowInternalDisksPrompt=Would you like to disable automatic mounting of internal drives (Y/N)? 
If /i "%MakeWinToGoUSBMediaAllowInternalDisksPrompt%"=="Y" Set MakeWinToGoUSBMediaAllowInternalDisks=False
If /i "%MakeWinToGoUSBMediaAllowInternalDisksPrompt%"=="N" Set MakeWinToGoUSBMediaAllowInternalDisks=True
If "%MakeWinToGoUSBMediaAllowInternalDisks%" == "" goto MakeWinToGoUSBMediaAllowInternalDisksSelect

:MakeWinToGoUSBMediaPortableOSSelect
echo.
Set MakeWinToGoUSBMediaPortableOSPrompt=
Set /p MakeWinToGoUSBMediaPortableOSPrompt=Would you like to enable the "PortableOperatingSystem" registry entry (Y/N)? 
If /i "%MakeWinToGoUSBMediaPortableOSPrompt%"=="Y" Set MakeWinToGoUSBMediaPortableOS=True
If /i "%MakeWinToGoUSBMediaPortableOSPrompt%"=="N" Set MakeWinToGoUSBMediaPortableOS=False
If "%MakeWinToGoUSBMediaPortableOS%" == "" goto MakeWinToGoUSBMediaPortableOSSelect

:MakeWinToGoUSBMediaVHDModeSelect
echo.
Set MakeWinToGoUSBMediaVHDModePrompt=
Set /p MakeWinToGoUSBMediaVHDModePrompt=Would you like to apply Windows to a Virtual Hard Disk file instead of directly to the USB filesystem (Y/N)? 
If /i "%MakeWinToGoUSBMediaVHDModePrompt%"=="Y" Set WinToGoVHDMode=True
If /i "%MakeWinToGoUSBMediaVHDModePrompt%"=="N" Set WinToGoVHDMode=False
If "%WinToGoVHDMode%" == "" goto MakeWinToGoUSBMediaVHDModeSelect

:EndWinToGoOptions

goto WinToGoUSB

REM ====== Create Windows To Go Media ==================================================================================================================================

:WinToGoUSB

Set DriveSizeReq=16384

Set FAT32Check=False
Set /a FAT32Limit=32768

If "%WinToGoDriveFixedOnly%" == "True" (
	Set DriveTypes=$_.DriveType -eq 3
	Set DriveTypesText=Fixed Only
) else (
	Set DriveTypes=$_.DriveType -eq 3 -or $_.DriveType -eq 2
	Set DriveTypesText=Fixed ^& Removable
)

If exist "%CD%\Includes\Mod_USB.cmd" (
	Call "%CD%\Includes\Mod_USB.cmd" USBSelect
) else (
	echo.
	echo %red%Error: "%CD%\Includes\Mod_USB.cmd" not found.%ef%
	Set USBCancel=True
	Set USBSelected=False
)
If "!USBCancel!" == "True" goto WinToGoComplete
If "!USBSelected!" == "True" goto MakeWinToGoUSB
goto WinToGoComplete

:MakeWinToGoUSB

:FormatWinToGoUSBSelect
echo.
rem echo %red%Warning: All data on disk drive "%Destination%" will be lost^^!%ef%
echo %red%Warning: All data on !DriveName!, drive^(s^) "!PartitionsOnDrive!" will be lost^^!%ef%
Set FormatWinToGoUSBPrompt=
Set /p FormatWinToGoUSBPrompt=Proceed with Format (Y/N)? 
If /i "%FormatWinToGoUSBPrompt%"=="Y" goto MakeWinToGoUSB_Format
If /i "%FormatWinToGoUSBPrompt%"=="N" goto MakeWinToGoUSB_NoFormat
goto FormatWinToGoUSBSelect

:MakeWinToGoUSB_NoFormat
echo.
echo Aborting, "%Destination%" will not be formatted.
goto WinToGoComplete

:MakeWinToGoUSB_Format


REM ====== Set source of files ======
Set WinToGoDiskpartScript00="%TmpPath%\WTG\WinToGoDiskpartScript00.txt"
Set WinToGoDiskpartScript05="%TmpPath%\WTG\WinToGoDiskpartScript05.txt"
Set WinToGoDiskpartScript10="%TmpPath%\WTG\WinToGoDiskpartScript10.txt"
Set WinToGoDiskpartScript15="%TmpPath%\WTG\WinToGoDiskpartScript15.txt"
Set WinToGoDiskpartScript20="%TmpPath%\WTG\WinToGoDiskpartScript20.txt"
Set WinToGoDiskpartScript25="%TmpPath%\WTG\WinToGoDiskpartScript25.txt"
Set WinToGoSource=%WinToGoSource:"=%
If "%SetupMode%" == "WimOnly" (
	For %%a in (esd swm wim) do (
		If Exist "!WinToGoSource!\install.%%a" Set WinToGoWIMSource=!WinToGoSource!\install.%%a
	)
) else (
	For %%a in (esd swm wim) do (
		If Exist "!WinToGoSource!\sources\install.%%a" Set WinToGoWIMSource=!WinToGoSource!\sources\install.%%a
	)
)


REM ====== Check WinToGo folder clear ======
:WinToGoCleanup

For %%f in (
	%WinToGoDiskpartScript00%
	%WinToGoDiskpartScript05%
	%WinToGoDiskpartScript10%
	%WinToGoDiskpartScript15%
	%WinToGoDiskpartScript20%
	%WinToGoDiskpartScript25%
	"%TmpPath%\WTG\Inf\Unattend\Unattend.inf"
	"%TmpPath%\WTG\Inf\Unattend\Unattend.xml"
) do (
	If exist %%f del %%f /f /q 1> nul
	If exist %%f (
		echo %red%Error: Failed to to remove temporary files.%ef%
		goto WinToGoComplete
	)
)


If exist "%TmpPath%\WTG\%MediaLabel%.vhd" (
	del "%TmpPath%\WTG\%MediaLabel%.vhd" /f /q 1> nul
	If exist "%TmpPath%\WTG\%MediaLabel%.vhd" (
		(
			echo select vdisk file="%TmpPath%\WTG\%MediaLabel%.vhd"
			echo detach vdisk noerr
		) > %WinToGoDiskpartScript00%
		diskpart /s %WinToGoDiskpartScript00% 1> nul
	)
	timeout /t 3 /nobreak > nul
	If exist "%TmpPath%\WTG\%MediaLabel%.vhd" del "%TmpPath%\WTG\%MediaLabel%.vhd" /f /q 1> nul
	If exist "%TmpPath%\WTG\%MediaLabel%.vhd" (
		echo.
		echo %red%Error: Failed to detach virtual hard disk.%ef%
		goto WinToGoComplete
	)
)


For %%d in (
	"%TmpPath%\WTG\System\"
	"%TmpPath%\WTG\Windows\"
) do (
	If exist %%d rmdir %%d 1> nul
	If exist %%d (
		echo %red%Error: Failed to remove mount points.%ef%
		goto WinToGoComplete
	)
)


For %%d in (
	"%TmpPath%\WTG\ScratchDir\"
	"%TmpPath%\WTG\Inf\Unattend\"
	"%TmpPath%\WTG\Inf\"
	"%TmpPath%\WTG\"
) do (
	If exist %%d rmdir %%d 1> nul
	If exist %%d (
		echo %red%Error: Failed to remove temporary folders.%ef%
		goto WinToGoComplete
	)
)


If "%WinToGoFinish%" == "True" goto WinToGoComplete

REM ====== Create Folders ======
For %%d in (
	"%TmpPath%\WTG\System\"
	"%TmpPath%\WTG\Windows\"
	"%TmpPath%\WTG\ScratchDir\"
) do (
	If not exist %%d md %%d 1> nul
	If not exist %%d (
		echo %red%Error: Failed to to create temporary folders.%ef%
		goto WinToGoComplete
	)
)


REM ====== Set list of drive letters assigned to drive ======
Set PartitionsOnDriveList=!PartitionsOnDrive:, =;!

If /i "%WinToGoUseGPT%" == "True" (
	Set ParType=GPT
) else (
	Set ParType=MBR
)

For /f "skip=2 tokens=1-2 delims=," %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-CimInstance CIM_LogicalDisk | Select-Object DeviceID, DriveType | Where-Object DeviceID -eq %Destination% | ConvertTo-Csv"') do (
	Set /a WinToGoDriveType=%%~b
)

If %WinToGoDriveType% EQU 3 Set WinToGoUseGPTFixedDest=True

REM ====== Set partition 1 and VHD size ======
For /f "skip=3 tokens=*" %%a in ('powershell.exe -c "$ErrorActionPreference='Stop'; Get-PhysicalDisk -DeviceNumber !DriveNumber! | Select-Object {[math]::Round($_.Size/1MB)}"') do (
If /i "%WinToGoUseGPT%" == "True" (
	If /i "%WinToGoUseGPTFixedDest%" == "True" (
	Set /a Partition1Size=%%a-116
	) else (
	Set /a Partition1Size=%%a-101
	)
) else (
	Set /a Partition1Size=%%a-101
)
	Set /a VHD1Size=%%a-2048
)

REM ====== Diskpart Script - WinToGoDiskpartScript05 ======
(
	echo rescan
	echo select disk !DriveNumber!
For %%a in (!PartitionsOnDriveList!) do (
	echo select volume=%%a
	echo remove letter=%%a noerr
)
rem	echo automount scrub
	echo rescan
	echo select disk !DriveNumber!
	echo clean
) > %WinToGoDiskpartScript05%

REM ====== Diskpart Script - WinToGoDiskpartScript10 ======
(
	echo select disk !DriveNumber!
If /i "%WinToGoUseGPT%" == "True" (
	echo convert gpt noerr
) else (
	echo convert mbr noerr
)
	echo create partition primary size=!Partition1Size!
For %%a in (!PartitionsOnDriveList!) do (
	echo remove letter=%%a noerr
)
	echo format fs=ntfs label=%MediaLabel% quick
If not "%WinToGoVHDMode%" == "True" (
	echo assign mount="%TmpPath%\WTG\Windows"
)
	echo create partition primary
For %%a in (!PartitionsOnDriveList!) do (
	echo remove letter=%%a noerr
)
	echo format quick fs=fat32 label="System"
If /i "%WinToGoUseGPT%" == "True" (
	If /i "%WinToGoUseGPTFixedDest%" == "True" (
	echo select partition 3
	) else (
	echo select partition 2
	)
) else (
	echo active
)
	echo assign mount="%TmpPath%\WTG\System"
If "%WinToGoVHDMode%" == "True" (
	echo create vdisk file="%TmpPath%\WTG\%MediaLabel%.vhd" maximum=%VHD1Size% type=expandable
	echo select vdisk file="%TmpPath%\WTG\%MediaLabel%.vhd"
	echo attach vdisk
	echo create partition primary
	echo format quick fs=ntfs label="Windows"
	echo assign mount="%TmpPath%\WTG\Windows"
)
) > %WinToGoDiskpartScript10%


REM ====== USB Diskpart Script - WinToGoDiskpartScript15 ======
(
	echo rescan
	echo select disk !DriveNumber!

	echo select volume="%TmpPath%\WTG\Windows"
	echo remove mount="%TmpPath%\WTG\Windows" noerr
	echo select vdisk file="%TmpPath%\WTG\%MediaLabel%.vhd"
	echo detach vdisk noerr
	echo rescan
	echo select disk !DriveNumber!
If /i "%WinToGoUseGPT%" == "True" (
	If /i "%WinToGoUseGPTFixedDest%" == "True" (
	echo select partition 2
	) else (
	echo select partition 1
	)
) else (
	echo select partition 1
)
	echo assign mount="%TmpPath%\WTG\Windows"
) > %WinToGoDiskpartScript15%


REM ====== Diskpart Script - WinToGoDiskpartScript20 ======
(
	echo rescan

	echo select disk !DriveNumber!
If /i "%WinToGoUseGPT%" == "True" (
	If /i "%WinToGoUseGPTFixedDest%" == "True" (
	echo select partition 2
	) else (
	echo select partition 1
	)
) else (
	echo select partition 1
)
	echo assign letter %Destination%
) > %WinToGoDiskpartScript20%


REM ====== USB Diskpart Script - WinToGoDiskpartScript25 ======
(
	echo rescan
	echo select disk !DriveNumber!

	echo select volume="%TmpPath%\WTG\Windows"
	echo remove mount="%TmpPath%\WTG\Windows" noerr
	echo select volume="%TmpPath%\WTG\System"
	echo remove mount="%TmpPath%\WTG\System" noerr
If /i "%WinToGoUseGPT%" == "True" (
	If /i "%WinToGoUseGPTFixedDest%" == "True" (
	echo select partition 3
	) else (
	echo select partition 2
	)
	echo set id=c12a7328-f81f-11d2-ba4b-00a0c93ec93b
)
) > %WinToGoDiskpartScript25%

REM ====== Stop ShellHWDetection ======
"%systemroot%\system32\sc.exe" stop ShellHWDetection >nul 2>&1

REM ====== Clean destination using WinToGoDiskpartScript05 ======
echo.
echo %white%Formatting "%Destination%".%ef%
echo Please wait.
diskpart /s %WinToGoDiskpartScript05% 1> nul

If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to format "%Destination%"...%ef%
	echo %red%DiskPart Error: "!=ExitCode!"%ef%
	goto WinToGoComplete
) else (
	echo %green%Formatted "%Destination%".%ef%
)


REM ====== Partition and and format USB and VHD using WinToGoDiskpartScript10 ======
echo.
echo %white%Partitioning "%Destination%" (%ParType%).%ef%
echo Please wait.
timeout /t 3 /nobreak > nul
diskpart /s %WinToGoDiskpartScript10% 1> nul

If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to partition "%Destination%"...%ef%
	echo %red%DiskPart Error: "!=ExitCode!"%ef%
	goto WinToGoComplete
) else (
	echo %green%Partitioned "%Destination%".%ef%
)

REM ====== Stop ShellHWDetection ======
"%systemroot%\system32\sc.exe" start ShellHWDetection >nul 2>&1

REM ====== Apply install.wim to destination ======
echo.
echo %white%Applying image.%ef%
echo Please wait...
start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /apply-image /imagefile:"!WinToGoWIMSource!" /index:1 /applydir:"%TmpPath%\WTG\Windows"
echo.
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to apply image.%ef%
	echo %red%DISM Error: "!ErrorLevel!"%ef%
	goto WinToGoComplete
) else (
	echo %green%Image applied.%ef%
)

REM ====== Copy Update Files ======

For %%d in (
	"!WinToGoSource!\Windows_Defender_Update_Pack"
	"!WinToGoSource!\Office_2013_RT_Update_Pack"
) do (
	If exist %%d If not exist "%TmpPath%\WTG\Windows\Media_Builder" md "%TmpPath%\WTG\Windows\Media_Builder" 1> nul
	If exist %%d "%SystemRoot%\System32\xcopy.exe" /I /E %%d "%TmpPath%\WTG\Windows\Media_Builder\%%~nxd" 1> nul
)

REM ====== Make any changes to install ======
If "%MakeWinToGoUSBMediaSkipOOBE%" == "True" (
	If exist "%CD%\Includes\Mod_WinToGo_SkipOOBE.cmd" Call "%CD%\Includes\Mod_WinToGo_SkipOOBE.cmd" WinToGoSkipOOBE
)

If "%MakeWinToGoUSBMediaAllowInternalDisks%" == "False" (
	echo.
	echo %white%Disabling automatic mounting of internal drives.%ef%
	"%systemroot%\System32\reg.exe" load HKLM\MB_SYSTEM "%TmpPath%\WTG\Windows\Windows\System32\Config\SYSTEM" 1> nul
	"%systemroot%\System32\reg.exe" add "HKLM\MB_SYSTEM\ControlSet001\Services\partmgr\Parameters" /t REG_DWORD /v SanPolicy /d 00000004 /f 1> nul
	"%systemroot%\System32\reg.exe" unload HKLM\MB_SYSTEM 1> nul
)

If "%WinToGoOS%" == "9" (
	rename "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.cmd" "OOBE.old"
	For /f "usebackq tokens=* delims=" %%z in ("%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.old") do (
		If "%%z" == "del "%%systemdrive%%\Windows\Setup\Scripts\OOBE.cmd"" (
			echo REM ====== Boot from USB ===============================================================================================================================================
			echo @setlocal EnableDelayedExpansion
			echo for /F "usebackq tokens=1-2" %%%%a in ^(`"%%systemroot%%\System32\bcdedit.exe" /enum FIRMWARE`^) DO ^(
			echo 	Set ID=%%%%b
			echo 	if /i "^^^!ID:~0,1^^^!"=="{" Set ID1=%%%%b
			echo 	if /i "%%%%b" == "USB" Set USBID=^^^^^^!ID1^^^^^^!
			echo 	if /i "%%%%b" == "Universal" Set USBID=^^^^^^!ID1^^^^^^!
			echo ^)
			echo "%%systemroot%%\System32\bcdedit.exe" /set {fwbootmgr} default ^^^^^^!USBID^^^^^^!
			echo @setlocal DisableDelayedExpansion
			echo echo.
		) >> "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.cmd"
		echo %%z>> "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.cmd"
	)
	del "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.old" /q 1> nul
)

If "%WinToGoOS%" == "9" (
	rename "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\SetupComplete.cmd" "SetupComplete.old"
	For /f "usebackq tokens=* delims=" %%z in ("%TmpPath%\WTG\Windows\Windows\Setup\Scripts\SetupComplete.old") do (
		If "%%z" == "del "%%systemdrive%%\Windows\Setup\Scripts\SetupComplete.cmd"" (
			echo REM ====== Undo Boot from USB ==========================================================================================================================================
rem			echo @setlocal EnableDelayedExpansion
rem			echo for /F "usebackq tokens=1-2" %%%%a in ^(`"%%systemroot%%\System32\bcdedit.exe" /enum FIRMWARE`^) DO ^(
rem			echo 	Set ID=%%%%b
rem			echo 	if /i "^!ID:~0,1^!"=="{" Set ID1=%%%%b
rem			echo 	if /i "%%%%b" == "USB" Set USBID=^^^!ID1^^^!
rem			echo 	if /i "%%%%b" == "Universal" Set USBID=^^^!ID1^^^!
rem			echo ^)
rem			echo "%%systemroot%%\System32\bcdedit.exe" /set {fwbootmgr} default ^^^!USBID^^^!
rem			echo @setlocal DisableDelayedExpansion
			echo "%%systemroot%%\System32\bcdedit.exe" /set {fwbootmgr} default {bootmgr}
			echo echo.
		) >> "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\SetupComplete.cmd"
		echo %%z>> "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\SetupComplete.cmd"
	)
	del "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\SetupComplete.old" /q 1> nul
)

If "%MakeWinToGoUSBMediaPortableOS%" == "True" (
	echo.
	echo %white%Setting "PortableOperatingSystem" registry entry.%ef%
	If "%WinToGoOS%" == "81" (
		"%systemroot%\System32\reg.exe" load HKLM\MB_SYSTEM "%TmpPath%\WTG\Windows\Windows\System32\Config\SYSTEM" 1> nul
		"%systemroot%\System32\reg.exe" add "HKLM\MB_SYSTEM\ControlSet001\Control" /t REG_DWORD /v PortableOperatingSystem /d 00000001 /f 1> nul
		"%systemroot%\System32\reg.exe" unload HKLM\MB_SYSTEM 1> nul
	)
	If "%WinToGoOS%" == "10" (
		rename "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.cmd" "OOBE.old"
		For /f "usebackq tokens=* delims=" %%a in ("%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.old") do (
			If "%%a" == "del "%%systemdrive%%\Windows\Setup\Scripts\OOBE.cmd"" (
				echo REM ====== Set PortableOperatingSystem =================================================================================================================================
				echo "%%systemroot%%\System32\reg.exe" add "HKLM\SYSTEM\ControlSet001\Control" /t REG_DWORD /v PortableOperatingSystem /d 00000001 /f 1^> nul
				echo echo.
			) >> "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.cmd"
			echo %%a>> "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.cmd"
		)
		del "%TmpPath%\WTG\Windows\Windows\Setup\Scripts\OOBE.old" /q 1> nul
	)
)

If "%WinToGoVHDMode%" == "True" (
	echo.
	echo %white%Setting "VirtualDiskExpandOnMount" registry entry.%ef%
	"%systemroot%\System32\reg.exe" load HKLM\MB_SYSTEM "%TmpPath%\WTG\Windows\Windows\System32\Config\SYSTEM" 1> nul
	"%systemroot%\System32\reg.exe" add "HKLM\MB_SYSTEM\ControlSet001\services\FsDepends\Parameters" /t REG_DWORD /v VirtualDiskExpandOnMount /d 00000004 /f 1> nul
	"%systemroot%\System32\reg.exe" unload HKLM\MB_SYSTEM 1> nul
)


REM ====== Copy boot files to destination ======
echo.
echo %white%Copying Boot Files.%ef%
echo Please wait.
"%CD%\Bin\BCDBoot\%PROCESSOR_ARCHITECTURE%\bcdboot.exe" "%TmpPath%\WTG\Windows\Windows" /s "%TmpPath%\WTG\System" /f UEFI > nul
If "!ErrorLevel!" NEQ "0" (
	echo.
	echo %red%Error: Failed to copy boot files.%ef%
	echo %red%BCDBoot Error: "!ErrorLevel!"%ef%
	goto WinToGoComplete
) else (
	rem echo.
	echo %green%Boot files copied.%ef%
)

rem echo Getting Test Mode Status
Set CurrentTestMode=False
For /f "usebackq tokens=1-2" %%a in (`"%systemroot%\System32\bcdedit.exe /store "!WinToGoSource!\EFI\Microsoft\Boot\BCD" /enum {default}"`) DO (
	If /i "%%a" == "testsigning" If /i "%%b" == "Yes" Set CurrentTestMode=True
)

Set BootmgrTestMode=False
For /f "usebackq tokens=1-2" %%a in (`"%systemroot%\System32\bcdedit.exe /store "!WinToGoSource!\EFI\Microsoft\Boot\BCD" /enum {bootmgr}"`) DO (
	If /i "%%a" == "testsigning" If /i "%%b" == "Yes" Set BootmgrTestMode=True
)

If "!CurrentTestMode!" == "True" If "!BootmgrTestMode!" == "True" (
	echo.
	bcdedit /store "%TmpPath%\WTG\System\EFI\Microsoft\Boot\BCD" /set {bootmgr} testsigning on
	bcdedit /store "%TmpPath%\WTG\System\EFI\Microsoft\Boot\BCD" /set {default} testsigning on
	bcdedit /store "%TmpPath%\WTG\System\EFI\Microsoft\Boot\BCD" /set {default} NoIntegrityChecks Yes
)

REM ====== Detach VHD WinToGoDiskpartScript15 ======
If not "%WinToGoVHDMode%" == "True" goto SkipWinToGoDiskpartScript15
Set WinToGoVHDDiskpartError=0
If "%WinToGoVHDMode%" == "True" (
	echo.
	echo %white%Detaching Virtual Hard Disk.%ef%
	echo Please wait.
	diskpart /s !WinToGoDiskpartScript15! 1> nul
	Set WinToGoVHDDiskpartError=!ErrorLevel!
)
If "!WinToGoVHDDiskpartError!" NEQ "0" (
	echo.
	echo %red%Error: Failed to detach virtual hard disk.%ef%
	goto WinToGoComplete
) else (
	rem echo.
	echo %green%Detached virtual hard disk.%ef%
)
:SkipWinToGoDiskpartScript15


REM ====== Copy VHD to destination ======
If "%WinToGoVHDMode%" == "True" (
	echo.
	echo %white%Copying Virtual Hard Disk file.%ef%
	echo Please wait...%green%
rem	Move /y "%TmpPath%\WTG\%MediaLabel%.vhd" "%TmpPath%\WTG\Windows" 1> nul
	Copy /v /y /z "%TmpPath%\WTG\%MediaLabel%.vhd" "%TmpPath%\WTG\Windows"
	If not exist "%TmpPath%\WTG\Windows\%MediaLabel%.vhd" goto WinToGoComplete
)


REM ====== Assign drive letter using WinToGoDiskpartScript20 ======
echo.
echo %white%Assigning Drive Letter.%ef%
echo Please wait.
diskpart /s !WinToGoDiskpartScript20! 1> nul
If "!ErrorLevel!" NEQ "0" (
	echo.
	echo %red%Error: Failed to assign drive letter.%ef%
	goto WinToGoComplete
) else (
rem	echo.
	echo %green%Driver letter assigned.%ef%
)


REM ====== Set BCD for VHD ======
If "%WinToGoVHDMode%" == "True" (
	echo.
	echo %white%Setting Boot Configuration Data.%ef%
	echo Please wait.
	"%CD%\Bin\BCDBoot\%PROCESSOR_ARCHITECTURE%\bcdedit.exe" /store "%TmpPath%\WTG\System\EFI\Microsoft\Boot\BCD" /set {default} device vhd=[%Destination%]\%MediaLabel%.vhd > nul
	If "!ErrorLevel!" NEQ "0" goto WinToGoComplete
	"%CD%\Bin\BCDBoot\%PROCESSOR_ARCHITECTURE%\bcdedit.exe" /store "%TmpPath%\WTG\System\EFI\Microsoft\Boot\BCD" /set {default} osdevice vhd=[%Destination%]\%MediaLabel%.vhd > nul
	If "!ErrorLevel!" NEQ "0" goto WinToGoComplete
	echo %green%Boot configuration data set.%ef%
)


REM ====== Remove mount points using WinToGoDiskpartScript25 ======
echo.
echo %white%Removing Moint Points.%ef%
echo Please wait.
diskpart /s !WinToGoDiskpartScript25! 1> nul
If "!ErrorLevel!" NEQ "0" (
	echo.
	echo %red%Error: Failed to remove mount points.%ef%
	goto WinToGoComplete
) else (
rem	echo.
	echo %green%Removed mount points.%ef%
)


Set WinToGoFinish=True
goto WinToGoCleanup

Goto WinToGoComplete

REM ====== End =========================================================================================================================================================

:WinToGoComplete

If "%WinToGoMode%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)