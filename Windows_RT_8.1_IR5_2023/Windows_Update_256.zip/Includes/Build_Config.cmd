@echo off

REM ====== Set =========================================================================================================================================================

Set ConfigStage=%1

If "%ConfigStage%" == "" (
	goto BuildConfigComplete
) else (

	If not exist "!CD!\Config" md "!CD!\Config" 1> nul
	Set MBConfig=!CD!\Config\Build_Config.cfg

	If exist "!MBConfig!" (
		Attrib -r -s -h "!MBConfig!" 1> nul
	)

	goto %ConfigStage%
)

:BuildConfig

REM ====== Build_Config.cfg Default Values (Do not edit) ===============================================================================================================

REM The values below are defaults if no Build_Config.cfg is found.

Set DownloadsFolderName=Downloads
Set DownloadsSpaceReq=6
Set OutputFolderName=Windows_Media
Set OutputFolderSpaceReq=12
Set TmpFolderName=Tmp
Set TmpFolderSpaceReq=24
Set TmpFolderPathLen=46

Set SysDriveSpaceReq=1

Set DownloadsPath=%CD%\%DownloadsFolderName%
Set OutputPath=%CD%\%OutputFolderName%
Set TmpPath=%CD%\%TmpFolderName%
Set BundledDISM=False
Set SkipOSCheck=False
Set MediaLabel=Win_RT_81
Set USBInstallMediaFixedOnly=False
Set SHA1Check=True
Set OpenFolderISO=False
Set ExportBootWinREWIM=True
Set ExportInstallWIM=True
Set TryESDIfInstallWIMLargerThan4GB=True
Set SkipServiceChecks=False
Set SkipDriveSpaceCheck=False
Set SkipDriveFileSystemCheck=False
Set SkipOOBE=False
Set WinToGo=False
Set WinToGoUseGPT=True
Set WinToGoDriveFixedOnly=True
Set ResetBaseScript=True
Set ActivationBackupScript=True
Set WindowsUpdateScript=True
Set ShowUSBCopyProgress=True
Set FileSource=A
Set OnlyUseLatestCLR=False
Set DISMLogLevel=2
Set DISMLogPath=%CD%\DISM_Logs
Set DISMLogFile=Log-DISM
Set DISMLogFileExt=txt
Set CustomAddon=False
Set UseCMDColours=True
Set MBInfoLink=True
Set RunStartUpActions=True
Set UseTestVersion=False

Set DefaultWindowsProductKey=Y48BN-R3D3W-6PG4P-BYBYB-8FDMP
Set WindowsProductKey=!DefaultWindowsProductKey!

If "%TorrentClientFound%" == "True" Set ArchiveOrgTorrent=True

Set WindowsForceAltDownload=False
Set WindowsUpdateForceAltDownload=False
Set WindowsLangPackForceAltDownload=False
Set OfficeForceAltDownload=False
Set OfficeUpdateForceAltDownload=False
Set OfficeLangPackForceAltDownload=False
Set DefenderForceAltDownload=False

Set MediaBuilderInfoURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/mediabuilder
Set WindowsListsURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/Windows_RT_8.1_IR5_2023/Windows
Set OfficeListsURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/Office_2013_RT_HSP_2023/Office
Set DefenderListsURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/Windows_RT_8.1_IR5_2023/Defender

REM ====== Write Build_Config.cfg if not found using the default values or read values from Build_Config.cfg if it is found ============================================

If not exist "%MBConfig%" (

	setlocal DisableDelayedExpansion
	(
		echo ###### Created by %~nx0 ######
		echo DownloadsPath=!CD!\%DownloadsFolderName%
		echo OutputPath=!CD!\%OutputFolderName%
		echo TmpPath=!CD!\%TmpFolderName%
		echo BundledDISM=%BundledDISM%
		echo SkipOSCheck=%SkipOSCheck%
		echo MediaLabel=%MediaLabel%
		echo USBInstallMediaFixedOnly=%USBInstallMediaFixedOnly%
		echo SHA1Check=%SHA1Check%
		echo OpenFolderISO=%OpenFolderISO%
		echo WindowsProductKey=%WindowsProductKey%
		If "%TorrentClientFound%" == "True" echo ArchiveOrgTorrent=%ArchiveOrgTorrent%
		echo ExportBootWinREWIM=%ExportBootWinREWIM%
		echo ExportInstallWIM=%ExportInstallWIM%
		echo TryESDIfInstallWIMLargerThan4GB=%TryESDIfInstallWIMLargerThan4GB%
		echo SkipServiceChecks=%SkipServiceChecks%
		echo SkipDriveSpaceCheck=%SkipDriveSpaceCheck%
		echo SkipDriveFileSystemCheck=%SkipDriveFileSystemCheck%
		echo SkipOOBE=%SkipOOBE%
		echo WinToGo=%WinToGo%
		echo WinToGoUseGPT=%WinToGoUseGPT%
		echo WinToGoDriveFixedOnly=%WinToGoDriveFixedOnly%
		echo ResetBaseScript=%ResetBaseScript%
		echo ActivationBackupScript=%ActivationBackupScript%
		echo WindowsUpdateScript=%WindowsUpdateScript%
		echo ShowUSBCopyProgress=%ShowUSBCopyProgress%
		echo OnlyUseLatestCLR=%OnlyUseLatestCLR%
		echo DISMLogLevel=%DISMLogLevel%
		echo CustomAddon=%CustomAddon%
		echo UseCMDColours=%UseCMDColours%
		echo WindowsForceAltDownload=%WindowsForceAltDownload%
		echo WindowsUpdateForceAltDownload=%WindowsUpdateForceAltDownload%
		echo WindowsLangPackForceAltDownload=%WindowsLangPackForceAltDownload%
		echo OfficeForceAltDownload=%OfficeForceAltDownload%
		echo OfficeUpdateForceAltDownload=%OfficeUpdateForceAltDownload%
		echo OfficeLangPackForceAltDownload=%OfficeLangPackForceAltDownload%
		echo DefenderForceAltDownload=%DefenderForceAltDownload%
		echo MBInfoLink=%MBInfoLink%
		echo RunStartUpActions=%RunStartUpActions%
		echo UseTestVersion=%UseTestVersion%
	) > "%MBConfig%"
	setlocal EnableDelayedExpansion

) else (

	For /f "usebackq skip=1 tokens=*" %%a in ("%MBConfig%") do (
		For /f "tokens=1* delims==" %%a in ("%%a") do (
			If not "%%b" == "" Set "%%a=%%b"
		)
	)

)

goto BuildConfigComplete

REM ====== Save Build_Config.cfg with current values ===================================================================================================================

:BuildSaveCurrentConfig

(
	echo ###### Created by %~nx0 ######

	If "%DownloadsPath%" == "!CD!\%DownloadsFolderName%" (
		setlocal DisableDelayedExpansion
		echo DownloadsPath=!CD!\%DownloadsFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo DownloadsPath=!DownloadsPath!
	)

	If "%OutputPath%" == "!CD!\%OutputFolderName%" (
		setlocal DisableDelayedExpansion
		echo OutputPath=!CD!\%OutputFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo OutputPath=!OutputPath!
	)

	If "%TmpPath%" == "!CD!\%TmpFolderName%" (
		setlocal DisableDelayedExpansion
		echo TmpPath=!CD!\%TmpFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo TmpPath=!TmpPath!
	)

rem	echo DownloadsPath=!DownloadsPath!
rem	echo OutputPath=!OutputPath!
rem	echo TmpPath=!TmpPath!
	echo BundledDISM=!BundledDISM!
	echo SkipOSCheck=!SkipOSCheck!
	echo MediaLabel=!MediaLabel!
	echo USBInstallMediaFixedOnly=!USBInstallMediaFixedOnly!
	echo SHA1Check=!SHA1Check!
	echo OpenFolderISO=!OpenFolderISO!
	echo WindowsProductKey=!WindowsProductKey!
	If "%TorrentClientFound%" == "True" echo ArchiveOrgTorrent=!ArchiveOrgTorrent!
	echo ExportBootWinREWIM=!ExportBootWinREWIM!
	echo ExportInstallWIM=!ExportInstallWIM!
	echo TryESDIfInstallWIMLargerThan4GB=!TryESDIfInstallWIMLargerThan4GB!
	echo SkipServiceChecks=!SkipServiceChecks!
	echo SkipDriveSpaceCheck=!SkipDriveSpaceCheck!
	echo SkipDriveFileSystemCheck=!SkipDriveFileSystemCheck!
	echo SkipOOBE=!SkipOOBE!
	echo WinToGo=!WinToGo!
	echo WinToGoUseGPT=!WinToGoUseGPT!
	echo WinToGoDriveFixedOnly=!WinToGoDriveFixedOnly!
	echo ResetBaseScript=!ResetBaseScript!
	echo ActivationBackupScript=!ActivationBackupScript!
	echo WindowsUpdateScript=!WindowsUpdateScript!
	echo ShowUSBCopyProgress=!ShowUSBCopyProgress!
	echo OnlyUseLatestCLR=!OnlyUseLatestCLR!
	echo DISMLogLevel=!DISMLogLevel!
	echo CustomAddon=!CustomAddon!
	echo UseCMDColours=!UseCMDColours!
	echo WindowsForceAltDownload=!WindowsForceAltDownload!
	echo WindowsUpdateForceAltDownload=!WindowsUpdateForceAltDownload!
	echo WindowsLangPackForceAltDownload=!WindowsLangPackForceAltDownload!
	echo OfficeForceAltDownload=!OfficeForceAltDownload!
	echo OfficeUpdateForceAltDownload=!OfficeUpdateForceAltDownload!
	echo OfficeLangPackForceAltDownload=!OfficeLangPackForceAltDownload!
	echo DefenderForceAltDownload=!DefenderForceAltDownload!
	echo MBInfoLink=!MBInfoLink!
	echo RunStartUpActions=!RunStartUpActions!
	echo UseTestVersion=!UseTestVersion!
) > "%MBConfig%"

goto BuildConfigComplete

REM ====== Set default Build_Config.cfg values =========================================================================================================================

:BuildSetDefault

If exist "%MBConfig%" (
	Del "%MBConfig%" /F /Q 1> nul
)

goto BuildConfig

REM ====== End =========================================================================================================================================================

:BuildConfigComplete

If "%ConfigStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "ConfigStage="