@echo off

Set Defender_Source=!CD!\Addons\Defender
Set Defender_DownloadLists=!Defender_Source!\Download_Lists
Set Defender_UpdateTmp=!TmpPath!\Windows_Defender_Update_Pack
Set Defender_Destination=!MediaFolderOutputPath!

REM ====== Set =========================================================================================================================================================

Set DefenderStage=%1

If "%DefenderStage%" == "" (
	goto DefenderComplete
) else (
	goto %DefenderStage%
)

REM ====== Defender Options Menu========================================================================================================================================

:DefenderMenu

For %%a in (
	"%Defender_DownloadLists%\Windows_Defender.txt"
	"%Defender_DownloadLists%\Windows_Defender_Alt.txt"
	"%Defender_Source%\Default\mpam-fe.exe"
	"%Defender_Source%\Default\nis_full.exe"
) do (
	If not exist %%a (
		Set UpdateDefender=False
		goto DefenderComplete
	)
)

If "%SkipDefender%" == "True" (
	Set UpdateDefender=False
	goto DefenderComplete
)

If exist "%Defender_DownloadLists%\Last_Updated" (
	Set /p Defender_UpdatedLast=< "%Defender_DownloadLists%\Last_Updated"
	For /f "tokens=1-2 delims=#" %%a in ("!Defender_UpdatedLast!") do (
		Set Defender_UpdatedRelease=%%a
		Set Defender_UpdatedLast=%%b
	)
) else (
	Set Defender_UpdatedRelease=Unknown Release
	Set Defender_UpdatedLast=Unknown Date
)

If "%DefenderForceAltDownload%" == "True" (
	Set Defender_DownloadList="%Defender_DownloadLists%\Windows_Defender_Alt.txt"
) else (
	Set Defender_DownloadList="%Defender_DownloadLists%\Windows_Defender.txt"
)

:DefenderUpdateSelect
If "!ReadPreset!" == "True" goto DefenderComplete
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p DefenderUpdatePrompt=Would you like to create a Windows Defender update package on the installation media (Y/N)? 
If /i "%DefenderUpdatePrompt%"=="Y" Set UpdateDefender=True
If /i "%DefenderUpdatePrompt%"=="N" Set UpdateDefender=False
If "%UpdateDefender%" == "" goto DefenderUpdateSelect

goto DefenderComplete

REM ====== Defender Info ===============================================================================================================================================

:DefenderInfo

echo		%white%%ul%Defender something something.%ef%
echo.

goto DefenderComplete

REM ====== Defender Download ===========================================================================================================================================

:DefenderDownload

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Downloading Windows Defender Updates.%ef%
echo Please wait...
echo.

For %%a in (
	"%Defender_UpdateTmp%\Updates"
) do (
	If not exist %%a md %%a 1> nul
)

If "%UpdateDefender%" == "True" (
	"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" --content-disposition --no-check-certificate --user-agent "Windows RT 8.1" -i !Defender_DownloadList! -P "%Defender_UpdateTmp%\Updates" -nc -q --show-progress --progress=bar:force:noscroll
)

If not !ErrorLevel! EQU 0 (
	echo %red%Error: Unable to downloading Windows Defender updates.%ef%
	echo Wget Error: !ErrorLevel!
	echo.
	Set /p DefenderDate=< "!Defender_Source!\Default\Last_Updated"
	echo Using local files ^(!DefenderDate!^)
	For %%a in (
		"%Defender_Source%\Default\mpam-fe.exe"
		"%Defender_Source%\Default\nis_full.exe"
	) do (
		echo %%a "%Defender_UpdateTmp%\Updates"
		copy %%a "%Defender_UpdateTmp%\Updates" 1> nul
	)
) else (
	echo.
	echo %green%Downloaded Successfully%ef%
	Set DefenderDate=%Date%
)

For %%a in (
	mpam-fe.exe
	nis_full.exe
) do (
	Set DefenderFile=!Defender_UpdateTmp!\Updates\%%a
	For /f "tokens=*" %%a in ('powershell.exe -Command "(Get-Item '!DefenderFile!').versionInfo.FileVersion"') do (
		Set FileVersion=%%a
	)
	Set Ver_%%~na= !FileVersion!
rem	For /f "tokens=*" %%a in ('powershell.exe -Command "(Get-Item '!DefenderFile!').versionInfo.LastWriteTime"') do (
rem		Set LastWriteTime=%%a
rem	)
rem	Set LWT_%%~na= !LastWriteTime!
)

(
	echo @echo off
	echo @setlocal enableextensions
	echo @setlocal EnableDelayedExpansion
	echo @cd /d "%%~dp0"
	echo.
	echo @Title Windows Defender Update Pack
	echo.
	echo echo Please wait...
	echo.
	echo REM ====== Check architecture ==========================================================================================================================================
	echo.
	echo If not "%%PROCESSOR_ARCHITECTURE%%" == "ARM" ^(
	echo		echo Error: Using this update package on %%PROCESSOR_ARCHITECTURE%% systems is not supported.
	echo		echo Please retry on an ARM system.
	echo		goto Exit
	echo ^)
	echo.
	echo REM ====== Check Windows Version =======================================================================================================================================
	echo.
	echo For /f "usebackq skip=2 tokens=2-4 delims==. " %%%%a in ^(`wmic os get Version /format:list`^) do ^(
	echo 	Set /a WinVerMajor=%%%%a
	echo 	Set /a WinVerMinor=%%%%b
	echo 	Set /a WinVerBuild=%%%%c
	echo 	goto BuildNumber
	echo ^)
	echo :BuildNumber
	echo.
	echo For /f "tokens=5 delims==." %%%%a in ^('wmic datafile where "name='%%HomeDrive%%\\Windows\\System32\\ntoskrnl.exe'" get version /format:list'^) Do ^(
	echo		Set WinVerNtoskrnl=%%%%a
	echo ^)
	echo.
	echo If %%WinVerMajor%% EQU 6 ^(
	echo 	If %%WinVerBuild%% EQU 9600 ^(
	echo 		If %%WinVerNtoskrnl%% GEQ 17053 ^(
	echo 			Set Supported=True
	echo 		^)
	echo 	^)
	echo ^)
	echo.
	echo If not "%%Supported%%" == "True" ^(
	echo 	echo Error: This update package is for use on Windows RT 8.1 IR5 only.
	echo 	goto Exit
	echo ^)
	echo.
	echo REM ====== Check if being run as admin =================================================================================================================================
	echo.
	echo For /f "tokens=1,2,3,4 USEBACKQ delims=," %%%%a in ^(`"%%SystemRoot%%\System32\whoami.exe /groups /fo csv /nh"`^) Do ^(
	echo		If %%%%c == "S-1-16-12288" Set RunAsAdmin=True
	echo ^)
	echo.
	echo If not "%%RunAsAdmin%%" == "True" ^(
	echo		echo Error: Please run as administrator.
	echo		goto Exit
	echo ^)
	echo.
	echo REM ====== Check only one instance is running ==========================================================================================================================
	echo.
	echo 9^>^&2 2^>nul ^(Call :LockAndRestoreStdErr %%* 8^>^>"%%~f0"^) ^|^| ^(
	echo		echo Error: Only one instance allowed - "%%~f0" is already running ^>^&2
	echo ^)
	echo goto Exit
	echo.
	echo :LockAndRestoreStdErr
	echo Call :SingleInstance %%* 2^>^&9
	echo exit /b 0
	echo.
	echo :SingleInstance
	echo.
	echo REM ====== Menu ========================================================================================================================================================
	echo.
	echo :DefenderInstallSelect
	echo cls
	echo echo ____________________________
	echo echo.
	echo echo Windows Defender Update Pack
	echo echo ____________________________
	echo echo.
	echo echo This update package will update a Windows RT 8.1 IR5 installation with the
	echo echo latest Windows Defender definitions.
	echo echo.
	echo echo mpam-fe.exe:!Ver_mpam-fe!
	echo echo nis_full.exe:!Ver_nis_full!
	echo echo.
	echo echo Please do not close this window while installation is in progress.
	echo echo ________________________________________________________________________________
	echo echo.
	echo Set /p Defender_Prompt=Would you like to install Windows Defender Updates ^(Y/N^)? 
	echo If /i "%%Defender_Prompt%%"=="Y" goto DefenderUpdate
	echo If /i "%%Defender_Prompt%%"=="N" goto Exit
	echo goto DefenderInstallSelect
	echo.
	echo :DefenderUpdate
	echo.
	echo Set DefenderUpdates=%%CD%%\Updates
	echo.
	echo For /f "USEBACKQ delims=|" %%%%f in ^(`dir /b /od "%%DefenderUpdates%%\*.exe"`^) do ^(
	echo		echo.
	echo		echo Installing Update: %%%%f
	echo		echo Please Wait...
	echo		Start /b /wait /d "%%DefenderUpdates%%\" %%%%f
	echo		If "^!ErrorLevel^!" NEQ "0" ^(
	echo			echo Failed to install: %%%%~nxf
	echo			echo Error: ^^!ErrorLevel^^!
	echo			goto Exit
	echo		^) else ^(
	echo			echo Installed OK.
	echo		^)
	echo ^)
	echo.
	echo REM ====== Done ========================================================================================================================================================
	echo.
	echo :Exit
	echo.
	echo echo ________________________________________________________________________________
	echo echo.
	echo Echo Goodbye!
	echo pause
	echo exit
) > "%Defender_UpdateTmp%\Defender_Update.cmd"

goto DefenderComplete

REM ====== Copy Defender Download =====================================================================================================================================9

:DefenderCopy

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Copying Windows Defender Updates.%ef%
echo.

If "%SameDrv%" == "True" (
	Move /y "!Defender_UpdateTmp!" "!Defender_Destination!" 1> nul
) else (
	echo Please wait...
	echo.
	"%SystemRoot%\System32\xcopy.exe" /I /E "!Defender_UpdateTmp!" "!Defender_Destination!\Windows_Defender_Update_Pack" 1> nul
)
If not "!ErrorLevel!" EQU "0" (
	echo %red%Error Copying Windows Defender Updates: !ErrorLevel!%ef%
) else (
	echo %green%Copied Windows Defender Updates.%ef%
)

goto DefenderComplete

REM ====== End =========================================================================================================================================================

:DefenderComplete

If "%DefenderStage%" == "" (
	echo This file is an addon for the Windows RT 8.1 Media Builder, it is not a separate Windows Defender installation package.
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "DefenderStage="