@echo off

REM ====== Set =========================================================================================================================================================

Set AppxStage=%1

If "%AppxStage%" == "" (
	goto AppxComplete
) else (
	goto %AppxStage%
)

REM ====== Appx Options ================================================================================================================================================

:AppxMenu

Set AppxList=%TmpPath%\AppxListFile.txt

Set AppxDest=%TmpPath%\Mount\install
Set AppxSource=%CD%\Addons\Appx\Apps
Set AppxStoreSource=%CD%\Addons\Appx\Store
Set DependencySource=%CD%\Addons\Appx\Dependency
Set AppxLicenseSource=%CD%\Addons\Appx\License

Set AppxRegMod=False

For %%a in (
	"%CD%\Addons\Appx\Install_Appx_AllowAllTrustedApps.cmd"
	"%DependencySource%\Microsoft.Media.PlayReadyClient.2_2.11.2154.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"%AppxLicenseSource%\Microsoft.BingFinance_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.BingFinance_2015.709.2014.2069_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.BingFoodAndDrink_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.BingFoodAndDrink_2015.709.2015.1275_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.BingHealthAndFitness_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.BingHealthAndFitness_2015.709.2016.264_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.BingMaps_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.BingMaps_2014.830.1811.3840_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.BingNews_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.BingNews_2015.709.2017.3396_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.BingSports_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.BingSports_2015.709.2018.1971_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.BingTravel_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.BingTravel_2015.709.2019.1414_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.BingWeather_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.BingWeather_2015.1021.304.4042_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.HelpAndTips_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.HelpAndTips_2014.716.611.79_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.Office.OneNote_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.Office.OneNote_2015.706.229.5806_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.Reader_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.Reader_2021.106.508.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.SkypeApp_kzf8qxf38zg5c.xml"
	"%AppxSource%\Microsoft.SkypeApp_2015.811.2205.3788_neutral_~_kzf8qxf38zg5c.appxbundle"
	"%AppxLicenseSource%\Microsoft.WindowsAlarms_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.WindowsAlarms_2013.1204.852.3011_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.WindowsCalculator_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.WindowsCalculator_2013.1007.1950.2960_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.WindowsCommunicationsApps_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.WindowsCommunicationsApps_2018.710.1738.481_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.WindowsReadingList_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.WindowsReadingList_2016.520.50.2306_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.WindowsScan_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.WindowsScan_2014.523.326.3026_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.WindowsSoundRecorder_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.WindowsSoundRecorder_2013.1010.500.2928_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.XboxLIVEGames_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.XboxLIVEGames_2013.1011.10.5965_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.ZuneMusic_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.ZuneMusic_2015.310.1544.2913_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\Microsoft.ZuneVideo_8wekyb3d8bbwe.xml"
	"%AppxSource%\Microsoft.ZuneVideo_2015.1023.2128.1509_neutral_~_8wekyb3d8bbwe.appxbundle"
) do (
	If not exist %%a (
		Set UpdateAppx=False
		Set AppxFileMissing=True
		goto AppxComplete
	)
)

:AppxUpdateSelect
If "!ReadPreset!" == "True" goto AppxComplete
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p AppxUpdatePrompt=Would you like to update provisioned apps (Y/N)? 
If /i "%AppxUpdatePrompt%"=="Y" Set UpdateAppx=True
If /i "%AppxUpdatePrompt%"=="N" Set UpdateAppx=False
If "%UpdateAppx%" == "" goto AppxUpdateSelect

goto AppxComplete

REM ====== Install Appx ================================================================================================================================================

:AppxCopy

echo.
echo %white%Installing App Pack.%ef%

REM ====== Uninstall Old Apps ==========================================================================================================================================

For %%b in (
	"Microsoft.BingFinance_2014.926.253.3184_neutral_~_8wekyb3d8bbwe"
	"Microsoft.BingFoodAndDrink_2014.926.254.3803_neutral_~_8wekyb3d8bbwe"
	"Microsoft.BingHealthAndFitness_2014.926.255.3988_neutral_~_8wekyb3d8bbwe"
	"Microsoft.BingMaps_2014.830.1811.3840_neutral_~_8wekyb3d8bbwe"
	"Microsoft.BingNews_2014.926.2134.2947_neutral_~_8wekyb3d8bbwe"
	"Microsoft.BingSports_2014.926.258.4003_neutral_~_8wekyb3d8bbwe"
	"Microsoft.BingTravel_2014.926.259.4931_neutral_~_8wekyb3d8bbwe"
	"Microsoft.BingWeather_2014.928.34.2811_neutral_~_8wekyb3d8bbwe"
	"Microsoft.HelpAndTips_2014.716.611.79_neutral_~_8wekyb3d8bbwe"
	"Microsoft.Office.OneNote_2014.921.1853.4418_neutral_~_8wekyb3d8bbwe"
	"Microsoft.Reader_2014.312.322.1510_neutral_~_8wekyb3d8bbwe"
	"Microsoft.SkypeApp_2014.731.933.5139_neutral_~_kzf8qxf38zg5c"
	"Microsoft.WindowsAlarms_2013.1204.852.3011_neutral_~_8wekyb3d8bbwe"
	"Microsoft.WindowsCalculator_2013.1007.1950.2960_neutral_~_8wekyb3d8bbwe"
	"microsoft.windowscommunicationsapps_2014.830.2330.2719_neutral_~_8wekyb3d8bbwe"
	"Microsoft.WindowsReadingList_2014.626.1418.1617_neutral_~_8wekyb3d8bbwe"
	"Microsoft.WindowsScan_2013.1007.2015.3834_neutral_~_8wekyb3d8bbwe"
	"Microsoft.WindowsSoundRecorder_2013.1010.500.2928_neutral_~_8wekyb3d8bbwe"
	"Microsoft.XboxLIVEGames_2013.1011.10.5965_neutral_~_8wekyb3d8bbwe"
	"Microsoft.ZuneMusic_2014.929.2145.59_neutral_~_8wekyb3d8bbwe"
	"Microsoft.ZuneVideo_2014.1002.954.4888_neutral_~_8wekyb3d8bbwe"
) do (
	echo.
	echo %white%Removing Package: %%~nb%ef%
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%AppxDest%" /Remove-Provisionedappxpackage /PackageName:%%~b
	echo.
	If "!ErrorLevel!" NEQ "0" (
		echo %red%Error Removing Package: %%~nb%ef%
		echo %red%DISM Error: !ErrorLevel!%ef%
	) else (
		echo %green%Removed Package: %%~nb%ef%
	)
)

REM ====== Allow All Trusted Apps ======================================================================================================================================

If "!AppxRegMod!" == "True" Call "%CD%\Addons\Appx\Install_Appx_AllowAllTrustedApps.cmd" AllowAllTrustedApps

REM ====== Install Selected Apps =======================================================================================================================================

Set AppxGroup1=True

If Exist "%AppxList%" Del "%AppxList%" /F /Q 1> nul

For %%l in (
	"Microsoft.BingFinance_2015.709.2014.2069_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.BingFinance_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingFoodAndDrink_2015.709.2015.1275_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.BingFoodAndDrink_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingHealthAndFitness_2015.709.2016.264_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.BingHealthAndFitness_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingMaps_2014.830.1811.3840_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.BingMaps_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingNews_2015.709.2017.3396_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.BingNews_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingSports_2015.709.2018.1971_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.BingSports_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingTravel_2015.709.2019.1414_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.BingTravel_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingWeather_2015.1021.304.4042_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.BingWeather_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.HelpAndTips_2014.716.611.79_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.HelpAndTips_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Office.OneNote_2015.706.229.5806_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.Office.OneNote_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Reader_2021.106.508.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.Reader_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.SkypeApp_2015.811.2205.3788_neutral_~_kzf8qxf38zg5c.appxbundle"#"AppxSource"#"False"#"Microsoft.SkypeApp_kzf8qxf38zg5c.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsAlarms_2013.1204.852.3011_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.WindowsAlarms_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsCalculator_2013.1007.1950.2960_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.WindowsCalculator_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsCommunicationsApps_2018.710.1738.481_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.WindowsCommunicationsApps_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsReadingList_2016.520.50.2306_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.WindowsReadingList_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsScan_2014.523.326.3026_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.WindowsScan_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsSoundRecorder_2013.1010.500.2928_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.WindowsSoundRecorder_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.XboxLIVEGames_2013.1011.10.5965_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.XboxLIVEGames_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx"
	"Microsoft.ZuneMusic_2015.310.1544.2913_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.ZuneMusic_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx,Microsoft.Media.PlayReadyClient.2_2.11.2154.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.ZuneVideo_2015.1023.2128.1509_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"False"#"Microsoft.ZuneVideo_8wekyb3d8bbwe.xml"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx,Microsoft.WinJS.2.0_1.0.9600.17018_neutral_~_8wekyb3d8bbwe.appx,Microsoft.Media.PlayReadyClient.2_2.11.2154.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If /i "%AppxGroup1%" == "True" echo %%l>>"%AppxList%"
)

For /f "usebackq tokens=1-5 delims=#" %%a in ("%AppxList%") do (
	echo.
	echo %white%Installing Package: %%~na%ef%
	Set AppxDependenciesList=
	For %%a in (%%~e) do (
		Set AppxDependenciesList=!AppxDependenciesList!/DependencyPackagePath:"%DependencySource%\%%a" 
	)

	If /i %%c == "True" Set AppxLicenseCommand=/SkipLicense
	If /i %%c == "False" Set AppxLicenseCommand=/LicensePath:"%AppxLicenseSource%\%%~d"
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%AppxDest%" /Add-ProvisionedAppxPackage /PackagePath:"!%%~b!\%%~a" !AppxLicenseCommand! !AppxDependenciesList!
	echo.
	If "!ErrorLevel!" NEQ "0" (
		echo %red%Error Intsalling Package: %%~na%ef%
		echo %red%DISM Error: !ErrorLevel!%ef%
	) else (
		echo %green%Intsalled Package: %%~na%ef%
	)
)

goto AppxComplete

REM ====== End =========================================================================================================================================================

:AppxComplete

If "%AppxStage%" == "" (
	echo This file is an addon for the Windows RT 8.1 IR5 Media Builder, it is not a separate app installation package.
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "AppxStage="