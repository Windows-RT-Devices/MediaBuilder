@echo off

REM ====== Make Install Media ==========================================================================================================================================

Set MediaMode=%1
Set MediaLabel=Jailbreak
Set MediaSource=!CD!\Addons\JailbreakUSB\Tegra_Jailbreak_USB.rar

If "%MediaMode%" == "JailbreakMenu" (
	goto JailbreakMenu
) else (
	goto JailbreakComplete
)

REM ====== Media =======================================================================================================================================================

:JailbreakMenu
cls

echo %white%%ul%___________________%ef%
echo.
echo %white%!JBUSBText!%ef%
echo %white%%ul%___________________%ef%
echo.
echo Yahallo - Copyright (C) 2019 - 2020, Bingxing Wang
echo Yahallo - Additional Device Support - Jeybee
echo Yahallo - Undo Support - Leander
echo Golden Keys - never_released ^& TheWack0lian
echo GoldenKeysUSB - lgibson02
echo.
echo All-in-on package to enable Tegra based Windows RT tablets to run third party applications under Windows RT or to
echo boot alternative operating systems.
echo %ul%________________________________________________________________________________________________________________________%ef%

For %%a in (
	"%MediaSource%"
) do (
	If not exist %%a (
		echo %red%Error: File missing...%ef%
		echo %%a
		echo.
		pause
		goto JailbreakComplete
	)
)

:JailbreakSelect
rem echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set MakeWinUSBMediaPrompt=
Set /p MakeWinUSBMediaPrompt=Would you like to create !JBUSBText! Media (Y/N)? 
If /i "%MakeWinUSBMediaPrompt%"=="Y" goto USB
If /i "%MakeWinUSBMediaPrompt%"=="N" goto JailbreakComplete
If "%MakeWinUSBMedia%" == "" goto JailbreakMenu

Goto JailbreakComplete

REM ====== Make USB ====================================================================================================================================================

:USB

Set /a DriveSizeReq=64

Set FAT32Check=True
Set /a FAT32Limit=32768

If "%USBInstallMediaFixedOnly%" == "True" (
	Set DriveTypes=$_.DriveType -eq 3
	Set DriveTypesText=Fixed Only
) else (
	Set DriveTypes=$_.DriveType -eq 3 -or $_.DriveType -eq 2
	Set DriveTypesText=Fixed ^& Removable
)

If exist "%CD%\Includes\Mod_USB.cmd" (
	Call "%CD%\Includes\Mod_USB.cmd" USBSelect
) else (
	echo.
	echo %red%Error: "%CD%\Includes\Mod_USB.cmd" not found.%ef%
	Set USBCancel=True
	Set USBSelected=False
)
If "!USBCancel!" == "True" goto JailbreakComplete
If "!USBSelected!" == "True" goto MakeUSB
goto JailbreakComplete

:MakeUSB

:FormatUSBSelect
echo.
rem echo %red%Warning: All data on disk drive "%Destination%" will be lost^^!%ef%
echo %red%Warning: All data on !DriveName!, drive^(s^) "!PartitionsOnDrive!" will be lost^^!%ef%
Set FormatUSBPrompt=
Set /p FormatUSBPrompt=Proceed with Format (Y/N)? 
If /i "%FormatUSBPrompt%"=="Y" goto MakeUSB_Format
If /i "%FormatUSBPrompt%"=="N" goto MakeUSB_NoFormat
goto FormatUSBSelect

:MakeUSB_NoFormat
echo.
echo Aborting, "%Destination%" will not be formatted.
goto JailbreakComplete

:MakeUSB_Format

If not exist "%TmpPath%\" md "%TmpPath%\"

Set DiskpartScript="%TmpPath%\DiskpartScriptJB.txt"
(
	echo select volume=%Destination%
	echo clean
	echo convert mbr
If "!LargerThan32GB!"=="True" (
	echo create partition primary size=32768
	echo format fs=fat32 label=%MediaLabel% quick
	echo assign letter %Destination%
	echo active
) else (
	echo create partition primary
	echo format fs=fat32 label=%MediaLabel% quick
	echo assign letter %Destination%
	echo active
)
) > %DiskpartScript%

echo.
echo %white%Formatting "%Destination%".%ef%
echo Please wait.
diskpart /s %DiskpartScript% > nul

If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to format "%Destination%"...%ef%
	echo %red%DiskPart Error: "!ErrorLevel!"%ef%
	goto JailbreakComplete
) else (
	echo %green%Formatted "%Destination%".%ef%
)

echo.
echo %white%Setting boot code on "%Destination%".%ef%
echo Please wait..
bootsect.exe /nt60 %Destination% /force /mbr > nul
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Failed to set the boot code on "%Destination%".%ef%
	echo %red%Bootsect Error: !ErrorLevel!%ef%
	goto JailbreakComplete
) else (
	echo %green%Boot code on "%Destination%" set.%ef%
)

echo.
echo %white%Extracting Jailbreak USB files to "%Destination%".%ef%
echo Please wait...
"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%MediaSource%" -aoa -o"%Destination%" -pPatterdale 1> nul 2> nul
	If not !ErrorLevel! EQU 0 (
	echo %red%Error: Unable to extract file.%ef%
	echo 7-Zip Error: !ErrorLevel!
	echo.
	pause
	goto JailbreakComplete
) else (
	echo %green%Extracted Successfully%ef%
	echo.
	pause
	goto JailbreakComplete
)

del /F /Q %DiskpartScript% 1> nul
If exist %DiskpartScript% (
	echo.
	echo %red%Error: Failed to delete temporary DiskPart script...%ef%
	goto JailbreakComplete
)

Goto JailbreakComplete

REM ====== End =========================================================================================================================================================

:JailbreakComplete

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)

If "%MediaMode%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)