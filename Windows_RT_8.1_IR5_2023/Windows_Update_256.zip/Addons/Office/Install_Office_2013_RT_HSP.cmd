@echo off

Set Office2013RT_Source=!CD!\Addons\Office
Set Office2013RT_Destination=!MediaFolderOutputPath!

Set Office2013RT_DownloadLists=!Office2013RT_Source!\Download_Lists
Set Office2013RT_Downloads=!DownloadsPath!\Office

Set Office2013RT_Installer=Office_2013_RT_HSP_Installer.txt

Set Office2013RT_UpdateTmp=!TmpPath!\Office_2013_RT_Update_Pack
Set Office2013RT_UpdateListTmp=!TmpPath!\OfficeUpdateLists

REM ====== Set =========================================================================================================================================================

Set OfficeStage=%1

If "%OfficeStage%" == "" (
	goto Office2013RTComplete
) else (
	goto %OfficeStage%
)

REM ====== Office Options Menu==========================================================================================================================================

:Office2013RTMenu

Set Office2013RT_LP_Tag=%Windows_Tag%

If /i "%Windows_Tag%" == "en-gb" (
	Set Office2013RT_LP_Tag=en-US
)

If /i "%Windows_Tag%" == "zh-hk" (
	Set Office2013RT_LP_Tag=zh-CN
)

If exist "%Office2013RT_DownloadLists%\Last_Updated" (
	Set /p Office2013RT_UpdatedLast=< "%Office2013RT_DownloadLists%\Last_Updated"
	For /f "tokens=1-2 delims=#" %%a in ("!Office2013RT_UpdatedLast!") do (
		Set Office2013RT_UpdatedRelease=%%a
		Set Office2013RT_UpdatedLast=%%b
	)
) else (
	Set Office2013RT_UpdatedRelease=Unknown Release
	Set Office2013RT_UpdatedLast=Unknown Date
)


If /i "!OfficeUpdateForceAltDownload!" == "True" Set OfficeUpdateListExt=_Alt

Set Office2013RT_UpdateListSP1=%Office2013RT_LP_Tag%\Office_2013_RT_HSP_SP1!OfficeUpdateListExt!.txt

Set Office2013RT_UpdateListPostSP1Common=Office_2013_RT_HSP_Post_SP1!OfficeUpdateListExt!.txt
Set Office2013RT_UpdateListPostSP1=%Office2013RT_LP_Tag%\Office_2013_RT_HSP_Post_SP1!OfficeUpdateListExt!.txt


For %%a in (
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1%"
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1Common%"
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1%"
) do (
	If not exist %%a (
		Set Office2013RT_Install=False
		Goto Office2013RTComplete
	)
)

If "%SkipOffice%" == "True" (
	Set Office2013RT_Install=False
	Goto Office2013RTComplete
)

:Office2013RT_InstallSelect
If "!ReadPreset!" == "True" (
	If "%Office2013RT_Install%" == "True" (
		Set Office2013RT_Prompt=Y
	) else (
		Set Office2013RT_Prompt=N
	)
	Goto SkipOfficePrompt
)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.

Set /p Office2013RT_Prompt=Would you like to create an Office 2013 RT Home ^& Student Plus update package on the installation media (Y/N)? 
:SkipOfficePrompt
If /i "%Office2013RT_Prompt%"=="Y" (
	Set Office2013RT_Install=True
	Set Office2013RT_Update=True
	Set Office2013RT_PostSP1=True
	Set Office2013RT_UpdateDescription= - Including updates to %Office2013RT_UpdatedLast%
	Set Office2013RT_InstallTime=30
	Goto Office2013RTComplete
)
If /i "%Office2013RT_Prompt%"=="N" (
	Set Office2013RT_Install=False
	Goto Office2013RTComplete
)

If "%Office2013RT_Install%" == "" goto Office2013RT_InstallSelect

If exist "%CD%\Temp.cmd" Call "%CD%\Temp.cmd" Office2013RT_Installer_List

Goto Office2013RTComplete

REM ====== Office 2013 RT Info =========================================================================================================================================

:Office2013RTInfo

echo		%white%%ul%Office 2013 RT Home ^& Student Plus%ef%%white% - Installation will be completed after the Out of Box Experience has
echo		finished and the desktop is shown for the first time. Installation will take up to %Office2013RT_InstallTime% minutes with the
echo		options selected, interacting with the desktop before installation is complete is not recommended.%ef%
echo.

goto Office2013RTComplete

REM ====== Download Office 2013 RT =====================================================================================================================================

:Office2013RTDownload

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Downloading Office 2013 RT Home ^& Student Plus Updates.%ef%
echo Please wait...
If not exist "%Office2013RT_Downloads%" echo.
If "!OfficeUpdate_RetryCount!" == "1" echo.

For %%d in (
	"%Office2013RT_Downloads%"
	"%Office2013RT_UpdateTmp%"
	"%Office2013RT_UpdateListTmp%"
) do (
	If not exist %%d md %%d 1> nul
)

If "%Office2013RT_Update%" == "True" (

	For /F "usebackq tokens=*" %%A in (
		"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1%"
	) do (
		echo %%A>> "%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt"
	)
	Set Office2013RT_UpdateList="%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt"

	If "%Office2013RT_PostSP1%" == "True" (

		For /F "usebackq tokens=*" %%A in (
			"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1Common%"
			"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1%"
		) do (
			echo %%A>> "%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_Post_SP1.txt"
		)
	Set Office2013RT_UpdateList="%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt";"%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_Post_SP1.txt"
	)

	For %%a in (
		!Office2013RT_UpdateList!
	) do (
		"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -i %%a -P "%Office2013RT_Downloads%\%%~na" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
		Set WgetErrorLevel=!ErrorLevel!
	)
)

If not "!WgetErrorLevel!" == "" If "!WgetErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to download Office updates.%ef%
	echo %red%Wget Error: !WgetErrorLevel!%ef%
	Set Office2013RT_Abort=True
	Goto Office2013RTError
)

Goto Office2013RTComplete

REM ====== Office 2013 RT Verify =======================================================================================================================================

:Office2013RTVerify

If /i "%SHA1Check%" == "True" If "%Office2013RT_Update%" == "True" (

	echo.
	echo %white%Verifying Updates.%ef%
	echo Please wait...
	echo.

	for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a

	For %%i in (
		%Office2013RT_UpdateList%
	) do (

		Set OfficeUpdateListFileName=%%~ni
		Set OfficeUpdatePath=!Office2013RT_Downloads!\!OfficeUpdateListFileName!
		Set OfficeUpdatePathBroken=!OfficeUpdatePath!_Corrupt\!RenameTime:~0,14!

		For /F "usebackq tokens=*" %%b in (%%i) do (

			Set Office2013RT_UpdateURL=%%b
			For %%c in ("!Office2013RT_UpdateURL!") do (
				Set Office2013RT_UpdateFileName=%%~NXc
			)

			Set Office2013RT_UpdateFileNameList=!Office2013RT_UpdateFileNameList!;!Office2013RT_UpdateFileName!

		)

		For %%a in (!Office2013RT_UpdateFileNameList!) do (

			Attrib -a -r -s -h "%%a" 1> nul

			Set OfficeUpdate_FileName=%%~NXa
			For /f "tokens=1-3 delims=_." %%a in ("!OfficeUpdate_FileName!") do (
				Set OfficeUpdate_SHA1=%%b
			)

	 		For /f "delims=" %%d in ('%SystemRoot%\System32\certutil.exe -hashfile "!OfficeUpdatePath!\%%a" SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
				Set z=%%d
				Set OfficeUpdate_FileFoundSHA1=!z: =!
			)

			If /I not !OfficeUpdate_SHA1! equ !OfficeUpdate_FileFoundSHA1! (
				echo %red%File Bad: %%~nxa%ef%

				attrib -s -h -r /s /d "%%a" 1> nul

				If Not Exist "!OfficeUpdatePathBroken!\" md "!OfficeUpdatePathBroken!\" 1> nul
				Move /y "!OfficeUpdatePath!\%%a" "!OfficeUpdatePathBroken!\" 1> nul
				If exist "%%a" (
					echo.
					echo %red%Error: Unable to move corrupt update...%ef%
					echo %red%"%%a"%ef%
					Set Office2013RT_Abort=True
					goto Office2013RTComplete
				) else (
					echo Moved To: "!OfficeUpdatePathBroken!\"
				)

				Set OfficeUpdate_Retry=True
			) else (
				echo %green%File OK: %%~nxa%ef%
			)

		)

	Set Office2013RT_UpdateFileNameList=

	)

	If "!OfficeUpdate_Retry!" == "True" (
		echo.

		If "!OfficeUpdate_RetryCount!" == "1" (
			echo %red%Error: Failed to replace corrupt Office files.%ef%
			Set Office2013RT_Abort=True
			goto Office2013RTComplete
		) else (
			echo %white%Corrupt Office Files Found ^& Moved.%ef%
			echo.
			echo Attempting to replace corrupt files...

			If exist "%TmpPath%\Office\" (
				attrib -s -h -r /s /d "%TmpPath%\Office\*.*" > NUL 2>&1
				del "%TmpPath%\Office\*.*" /F /Q /S > NUL 2>&1
				rmdir /Q /S "%TmpPath%\Office" > NUL 2>&1
			)

			If exist "%TmpPath%\Office\" (
				echo %red%Error: Failed to delete Office temporary files.%ef%
				Set Office2013RT_Abort=True
				goto Office2013RTComplete
			) else (
				Set OfficeUpdate_RetryCount=1
			)

		)

	) else (
		echo.
		echo %white%Verified Office Files.%ef%
	)

)

Goto Office2013RTComplete

REM ====== Extract Office 2013 RT Updates ==============================================================================================================================

:Office2013RTUpdates

If "!OfficeUpdate_Retry!" == "True" goto Office2013RTComplete
If "!DownloadPreset!" == "True" goto Office2013RTComplete

echo.
echo %white%Preparing Updates.%ef%
echo Please wait...
echo.

For %%a in (
	"%Office2013RT_UpdateTmp%\Updates"
) do (
	If not exist %%a md %%a 1> nul
)

For %%a in (
	%Office2013RT_UpdateList%
) do (
	
	For /F "usebackq tokens=*" %%b in (%%a) do (

		Set Office2013RT_UpdateURL=%%b

		For %%c in ("!Office2013RT_UpdateURL!") do (
			Set Office2013RT_UpdateFileName=%%~NXc
		)

		Set Office2013RT_UpdateFileNameList=!Office2013RT_UpdateFileNameList!;!Office2013RT_UpdateFileName!

	)

	For %%d in (!Office2013RT_UpdateFileNameList!) do (

		For /f "tokens=1,2,3 delims=_." %%x in ("%%d") do (
			Set Office2013RT_UpdateFileNameStart=%%x
			Set Office2013RT_UpdateFileNameEnd=%%y
			Set Office2013RT_UpdateFileNameExt=%%z
		)
		
		"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%Office2013RT_Downloads%\%%~na\%%d" -o"%Office2013RT_UpdateTmp%\Updates" "!Office2013RT_UpdateFileNameStart!.msp" >nul 2>&1

		If "!ErrorLevel!" NEQ "0" (
			echo Failed to extract: %%d
			Set Office2013RT_Abort=True
			goto Office2013RTComplete
		) else (
			echo Extracted: %%d
			Rename "%Office2013RT_UpdateTmp%\Updates\!Office2013RT_UpdateFileNameStart!.msp" "!Office2013RT_UpdateFileNameStart!_!Office2013RT_UpdateFileNameEnd!.msp" 1> nul
		)

	)

	Set Office2013RT_UpdateFileNameList=
)

(
	echo @echo off
	echo @setlocal enableextensions
	echo @setlocal EnableDelayedExpansion
	echo @cd /d "%%~dp0"
	echo.
	echo @Title Office 2013 RT HSP Update Pack
	echo.
	echo echo Please wait...
	echo.
	echo REM ====== Check architecture ==========================================================================================================================================
	echo.
	echo If not "%%PROCESSOR_ARCHITECTURE%%" == "ARM" ^(
	echo		echo Error: Using this update package on %%PROCESSOR_ARCHITECTURE%% systems is not supported.
	echo		echo Please retry on an ARM system.
	echo		goto Exit
	echo ^)
	echo.
	echo REM ====== Check Windows Version =======================================================================================================================================
	echo.
	echo For /f "usebackq skip=2 tokens=2-4 delims==. " %%%%a in ^(`wmic os get Version /format:list`^) do ^(
	echo 	Set /a WinVerMajor=%%%%a
	echo 	Set /a WinVerMinor=%%%%b
	echo 	Set /a WinVerBuild=%%%%c
	echo 	goto BuildNumber
	echo ^)
	echo :BuildNumber
	echo.
	echo For /f "tokens=5 delims==." %%%%a in ^('wmic datafile where "name='%%HomeDrive%%\\Windows\\System32\\ntoskrnl.exe'" get version /format:list'^) Do ^(
	echo		Set WinVerNtoskrnl=%%%%a
	echo ^)
	echo.
	echo If %%WinVerMajor%% EQU 6 ^(
	echo 	If %%WinVerBuild%% EQU 9600 ^(
	echo 		If %%WinVerNtoskrnl%% GEQ 17053 ^(
	echo 			Set Supported=True
	echo 		^)
	echo 	^)
	echo ^)
	echo.
	echo If not "%%Supported%%" == "True" ^(
	echo 	echo Error: This update package is for use on Windows RT 8.1 IR5 only.
	echo 	goto Exit
	echo ^)
	echo.
	echo REM ====== Check if being run as admin =================================================================================================================================
	echo.
	echo For /f "tokens=1,2,3,4 USEBACKQ delims=," %%%%a in ^(`"%%SystemRoot%%\System32\whoami.exe /groups /fo csv /nh"`^) Do ^(
	echo		If %%%%c == "S-1-16-12288" Set RunAsAdmin=True
	echo ^)
	echo.
	echo If not "%%RunAsAdmin%%" == "True" ^(
	echo		echo Error: Please run as administrator.
	echo		goto Exit
	echo ^)
	echo.
	echo REM ====== Check only one instance is running ==========================================================================================================================
	echo.
	echo 9^>^&2 2^>nul ^(Call :LockAndRestoreStdErr %%* 8^>^>"%%~f0"^) ^|^| ^(
	echo		echo Error: Only one instance allowed - "%%~f0" is already running ^>^&2
	echo ^)
	echo goto Exit
	echo.
	echo :LockAndRestoreStdErr
	echo Call :SingleInstance %%* 2^>^&9
	echo exit /b 0
	echo.
	echo :SingleInstance
	echo.
	echo REM ====== Menu ========================================================================================================================================================
	echo.
	echo :Office2013RTInstallSelect
	echo cls
	echo echo ______________________________________________
	echo echo.
	echo echo Office 2013 RT Home ^^^& Student Plus Update Pack
	echo echo ______________________________________________
	echo echo.
	echo echo This update package will update a Windows RT 8.1 IR5 installation with all
	echo echo %Windows_Language% Office updates to %Office2013RT_UpdatedLast%.
	echo echo.
	echo echo Please do not close this window or attempt to use Office while installation
	echo echo is in progress. Installation of these updates may take up to %Office2013RT_InstallTime% minutes.
	echo echo ________________________________________________________________________________
	echo echo.
	echo Set /p Office2013RT_Prompt=Would you like to install Office 2013 RT Home ^^^& Student Plus Updates ^(Y/N^)? 
	echo If /i "%%Office2013RT_Prompt%%"=="Y" goto Office2013RTUpdate
	echo If /i "%%Office2013RT_Prompt%%"=="N" goto Exit
	echo goto Office2013RTInstallSelect
	echo.
	echo :Office2013RTUpdate
	echo.
	echo Set Office2013RT_Patches=%%CD%%\Updates
	echo.
	echo For %%%%a in ^("%%Office2013RT_Patches%%\*.msp"^) do ^(
	echo 	Set /a Office2013RT_Total+=1
	echo ^)
	echo.
	echo For /f "USEBACKQ delims=|" %%%%f in ^(`dir /b /od "%%Office2013RT_Patches%%\*.msp"`^) do ^(
	echo		Set /a Office2013RT_Count+=1
	echo		echo.
	echo		echo Installing Update: ^^!Office2013RT_Count^^! of ^^!Office2013RT_Total^^!
	echo		echo %%%%f
	echo		echo Please Wait...
	echo		timeout 15 /nobreak ^> nul
	echo		rem Start /b /wait /d "%%Office2013RT_Patches%%\" %%%%f /quiet /norestart
	echo		"%%Office2013RT_Patches%%\%%%%f" /quiet /norestart
	echo.
	echo		If "^!ErrorLevel^!" EQU "1618" ^(
	echo			echo Failed to install: %%%%~nxf
	echo			echo Error: ^^!ErrorLevel^^!
	echo			echo Retrying...
	echo			timeout 60 /nobreak ^> nul
	echo			"%%Office2013RT_Patches%%\%%%%f" /quiet /norestart
	echo		^)
	echo.
	echo		If "^!ErrorLevel^!" NEQ "0" ^(
	echo			echo Failed to install: %%%%~nxf
	echo			echo Error: ^^!ErrorLevel^^!
	echo			goto Exit
	echo		^) else ^(
	echo			echo Installed OK.
	echo		^)
	echo ^)
	echo.
	echo For %%%%a in ^(
rem	echo		%%systemdrive%%\MSOCache
	echo		%%systemdrive%%\Windows\Installer\$PatchCache$
	echo ^) do ^(
	echo		If exist "%%%%a\" ^(
	echo			attrib -s -h -r /s /d "%%%%a\*.*" ^> nul
	echo			del "%%%%a\*.*" /F /Q /S ^> nul
	echo			rmdir /Q /S "%%%%a\" ^> nul
	echo		^)
	echo ^)
	echo echo ________________________________________________________________________________
	echo If ^^!Office2013RT_Count^^! EQU ^^!Office2013RT_Total^^! ^(
	echo 	echo Installation Complete.
	echo ^) else ^(
	echo 	echo Installation Failed.
	echo ^)
	echo.
	echo REM ====== Done ========================================================================================================================================================
	echo.
	echo :Exit
	echo.
	echo echo ________________________________________________________________________________
	echo echo.
	echo Echo Goodbye!
	echo pause
	echo exit
) > "%Office2013RT_UpdateTmp%\Office_Update.cmd"

If not "%Office2013RT_Abort%" == "True" (
	echo.
	echo %white%Updates Prepared.%ef%
)

Goto Office2013RTComplete

REM ====== Copy Office 2013 RT =========================================================================================================================================

:Office2013RTCopy

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Copying Office 2013 RT Home ^& Student Plus Updates.%ef%
echo.

If "%SameDrv%" == "True" (
	Move /y "!Office2013RT_UpdateTmp!" "!Office2013RT_Destination!" 1> nul
) else (
	echo Please wait...
	echo.
	"%SystemRoot%\System32\xcopy.exe" /I /E "!Office2013RT_UpdateTmp!" "!Office2013RT_Destination!\Office_2013_RT_Update_Pack" 1> nul
)
If not "!ErrorLevel!" EQU "0" (
	echo %red%Error Copying Office Updates: !ErrorLevel!%ef%
) else (
	echo %green%Copied Office Updates.%ef%
)

Goto Office2013RTComplete

REM ====== Error =======================================================================================================================================================

:Office2013RTError

Set Office2013RT_Install=False
Set Office2013RT_Update=False
Set Office2013RT_FileMissing=True

goto Office2013RTComplete

REM ====== End =========================================================================================================================================================

:Office2013RTComplete

If "%OfficeStage%" == "" (
	echo This file is an addon for the Windows RT 8.1 Media Builder, it is not a separate Office installation package.
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "OfficeStage="