@echo off

REM ====== Set =========================================================================================================================================================

Set SettingsStage=%1

If "%SettingsStage%" == "" (
	goto Build_Settings_Complete
) else (
	goto %SettingsStage%
)

REM ====== Configuration ===============================================================================================================================================

:Build_Settings_Start
cls
For %%a in (
	BundledDISM
	SHA1Check
	ArchiveOrgTorrent
	ExportBootWinREWIM
	ExportInstallWIM
	WinToGo
	CustomAddon
	BulkMode
	TryESDIfInstallWIMLargerThan4GB
	SkipDriveSpaceCheck
	KMS38
	RunStartUpActions
	HWIDTicket
) do (
	If "!%%a!" == "True" (
		Set MenuModeText=%green%Enabled%ef%
	) else (
		Set MenuModeText=%red%Disabled%ef%
	)

	Set %%aMenuModeText=!MenuModeText!
rem	echo Set %%aMenuModeText=!%%aMenuModeText!
)

If "!AltWindowsActivation!" == "True" (
	Set AltWindowsActivationMenuModeText=OEM:NONSLP
	Set WindowsProduct=Windows 10 Enterprise Product Key ^(!AltWindowsActivationMenuModeText!^)  
) else (
	Set AltWindowsActivationMenuModeText=GVLK
	Set WindowsProduct=Windows 10 Enterprise Product Key ^(!AltWindowsActivationMenuModeText!^)	     
)

If "!AltOfficeActivation!" == "True" (
rem %white%^^^(Requires Valid Office 2013 Home ^^^& Business Key^^^)%ef%
	Set AltOfficeActivationMenuModeText=Retail
	Set OfficeProduct=Office 2013 Home ^& Business Product Key ^(!AltOfficeActivationMenuModeText!^)
) else (
	Set AltOfficeActivationMenuModeText=GVLK
	Set OfficeProduct=Office 2013 Standard Product Key ^(!AltOfficeActivationMenuModeText!^)	     
)

If "!DISMLogLevel!" == "1" Set DISMLogText=(Errors only)
If "!DISMLogLevel!" == "2" Set DISMLogText=(Errors and warnings)
If "!DISMLogLevel!" == "3" Set DISMLogText=(Errors, warnings, and informational)
If "!DISMLogLevel!" == "4" Set DISMLogText=(All information and debug output)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.

If "%BuildAbort%" == "True" (

	Set FirstErrorMessageLine=True

	For %%a in (
		!SettingsErrorList!
	) do (
		If "!FirstErrorMessageLine!" == "True" (
			echo %white%Info:%ef%		  %%~a
		) else (
			echo			  %%~a
		)
		Set FirstErrorMessageLine=False
	)
	echo.
	echo			  Correct any issues listed using the Settings Menu below and restart Media Builder.
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
)

If "!WindowsProductKey!" == "" (
echo %white%Settings:%ef%	  1: Select "%DownloadsFolderName%" Parent Directory ^(Office Media, Language Packs ^& Updates^)
) else (
echo %white%Settings:%ef%	  1: Select "%DownloadsFolderName%" Parent Directory ^(Source Windows Media, Windows ^& Office Updates^)
)
rem echo 		     %green%Current Path: %DownloadsPath%%ef%
If "!DownloadsPath:~80,1!" == "" (
	echo 		     %green%Current Path: !DownloadsPath:~0,80!%ef%
) else (
	echo 		     %green%Current Path: !DownloadsPath:~0,77!...%ef%
)

echo.
If "!WindowsProductKey!" == "" (
echo 		  2: Select "%TmpFolderName%" Parent Directory ^(Temporary Files^)
) else (
echo 		  2: Select "%TmpFolderName%" Parent Directory ^(Temporary Files ^& WIM Mount Points^)
)
rem echo 		     %green%Current Path: %TmpPath%%ef%
If "!TmpPath:~80,1!" == "" (
	echo 		     %green%Current Path: !TmpPath:~0,80!%ef%
) else (
	echo 		     %green%Current Path: !TmpPath:~0,77!...%ef%
)

echo.
If "!WindowsProductKey!" == "" (
echo 		  3: Select "%OutputFolderName%" Parent Directory ^(Output Office Media^)
) else (
echo 		  3: Select "%OutputFolderName%" Parent Directory ^(Output Windows Media^)
)
rem echo 		     %green%Current Path: %OutputPath%%ef%
If "!OutputPath:~80,1!" == "" (
	echo 		     %green%Current Path: !OutputPath:~0,80!%ef%
) else (
	echo 		     %green%Current Path: !OutputPath:~0,77!...%ef%
)

echo.

If not "%BuildAbort%" == "True" (

If exist "%CD%\Bin\DISM\%PROCESSOR_ARCHITECTURE%\dism.exe" (
echo 		  4: Bundled DISM				      ^| %BundledDISMMenuModeText%
)
echo 		  5: Download Verification ^(SHA-1^)		      ^| %SHA1CheckMenuModeText%
If not "!DefaultWindowsProductKey!" == "" (
echo 		  6: ISO/USB/VHD Media Label			      ^| %green%%MediaLabel%%ef%
)
If exist "%CD%\Download_Lists\Windows_10.txt" (
	echo 		  7: !WindowsProduct! ^| %green%%WindowsProductKey%%ef%
)
If exist "%CD%\Download_Lists\Windows.txt" (
	echo 		  7: Windows RT 8.1 Product Key			      ^| %green%%WindowsProductKey%%ef%
)
If not "!DefaultOfficeProductKey!" == "" (
	echo 		  8: !OfficeProduct! ^| %green%%OfficeProductKey%%ef%
)
If not exist "%CD%\Download_Lists\Windows.txt" (
	If "!KMS:~63,1!" == "" (
		echo 		  9: KMS Address				      ^| %green%!KMS!%ef%
	) else (
		echo 		  9: KMS Address				      ^| %green%!KMS:~0,58!...%ef%
		If "!KMS:~116,1!" == "" (
			echo							      ^| %green%...!KMS:~58,58!%ef%
		) else (
			echo							      ^| %green%...!KMS:~58,55!...%ef%
		)
	)
)
If exist "%CD%\Bin\aria2\%PROCESSOR_ARCHITECTURE%\aria2c.exe" (
	echo 		  0: Use Torrent Download If Available		      ^| %ArchiveOrgTorrentMenuModeText%
)

rem echo 		 11: Boot.wim ^& Winre.wim Compression		      ^| %ExportBootWinREWIMMenuModeText%
rem echo 		 12: Install.wim Compression			      ^| %ExportInstallWIMMenuModeText%

If exist "%CD%\Download_Lists\Windows.txt" (
echo.
echo 		  A: Auto Convert Install.wim To ESD If Output ^> 4GB  ^| %TryESDIfInstallWIMLargerThan4GBMenuModeText%
)

echo.
If not "!AltWindowsProductKey!" == "" (
echo 		  W: Windows Product Key Type			      ^| %green%%AltWindowsActivationMenuModeText%%ef%
If "!AltWindowsActivation!" == "False" (
echo 		  K: Activate Windows Offline ^(KMS38^)		      ^| %KMS38MenuModeText%
)

If "!AltWindowsActivation!" == "True" (
echo 		  H: Activate Windows Online ^(HWID Ticket^)	      ^| %HWIDTicketMenuModeText%
)

)
If not "!AltOfficeProductKey!" == "" (
echo 		  O: Office Product Key Type			      ^| %green%%AltOfficeActivationMenuModeText%%ef%
)

If exist "%CD%\Includes\Mod_WinToGo.cmd" (
echo 		  G: Offer Windows To Go USB Output		      ^| !WinToGoMenuModeText!
)
If not "!WindowsProductKey!" == "" If exist "%CD%\Addons\Custom\Custom.cmd" (
echo 		  C: Enable Custom Addon ^(\Addons\Custom\Custom.cmd^)  ^| !CustomAddonMenuModeText!
)
If exist "%CD%\Bin\DISM\%PROCESSOR_ARCHITECTURE%\dism.exe" (
echo 		  L: DISM Log Level				      ^| %green%!DISMLogLevel! !DISMLogText!%ef%
)

)

If exist "%CD%\Includes\Build_Mode.cmd" (
echo 		  B: Bulk Mode					      ^| !BulkModeMenuModeText!
)

If not "%BuildAbort%" == "True" (
echo.
)

rem If "%BuildAbort%" == "True" (
rem echo 		  S: Bypass Drive Space Checks ^%red%(Not Recommended^)%ef%      ^| !SkipDriveSpaceCheckMenuModeText!
rem echo.
rem )

rem	echo 		  D: Set Default Values
If not "%BuildAbort%" == "True" (
	echo 		  U: Automatic Update Check ^(On Startup Only^)	      ^| !RunStartUpActionsMenuModeText!
	echo.
)

If "%BuildAbort%" == "True" (
	echo 		  R: %red%Restart Media Builder%ef%
echo 		  E: %red%Exit Media Builder%ef%				      ^| D: Set Default Values
) else (
echo 		  E: %red%Exit Settings%ef%				      ^| D: Set Default Values
)

echo. %white%
Set ConfigOption=
Set /p ConfigOption=Enter Selection: 
echo. %ef%

If "%ConfigOption%"=="1" goto ConfigDownloads
If "%ConfigOption%"=="2" goto ConfigTemp
If "%ConfigOption%"=="3" goto ConfigOutput

If not "%BuildAbort%" == "True" (

If exist "%CD%\Bin\DISM\%PROCESSOR_ARCHITECTURE%\dism.exe" If "%ConfigOption%"=="4" goto ConfigDISM
If "%ConfigOption%"=="5" goto ConfigSHA1
If not "!DefaultWindowsProductKey!" == "" If "%ConfigOption%"=="6" goto ConfigMediaLabel
If not "!DefaultWindowsProductKey!" == "" If "%ConfigOption%"=="7" goto ConfigWinKey
If not "!DefaultOfficeProductKey!" == ""  If "%ConfigOption%"=="8" goto ConfigOfficeKey
If not exist "%CD%\Download_Lists\Windows.txt" If "%ConfigOption%"=="9" goto ConfigKMS
If exist "%CD%\Bin\aria2\%PROCESSOR_ARCHITECTURE%\aria2c.exe" If "%ConfigOption%"=="0" goto ConfigArchiveOrgTorrent

rem If "%ConfigOption%"=="11" goto ConfigBootWinREWIM
rem If "%ConfigOption%"=="12" goto ConfigInstallWIM

If exist "%CD%\Download_Lists\Windows.txt" If /i "%ConfigOption%"=="A" goto ConfigTryESDIfInstallWIMLargerThan4GB

If not "%AltWindowsProductKey%" == "" If /i "%ConfigOption%"=="W" goto ConfigAltWindowsActivation
If "!AltWindowsActivation!" == "False"  If /i "%ConfigOption%"=="K" goto ConfigKMS38

If "!AltWindowsActivation!" == "True" If /i "%ConfigOption%"=="H" goto ConfigHWIDTicket

If not "!AltOfficeProductKey!" == "" If /i "%ConfigOption%"=="O" goto ConfigAltOfficeActivation

If exist "%CD%\Bin\DISM\%PROCESSOR_ARCHITECTURE%\dism.exe" If /i "%ConfigOption%"=="L" goto ConfigDISMLog

If exist "%CD%\Includes\Mod_WinToGo.cmd" If /i "%ConfigOption%"=="G" goto ConfigWinToGo
If not "!WindowsProductKey!" == "" If exist "%CD%\Addons\Custom\Custom.cmd" If /i "%ConfigOption%"=="C" goto ConfigCustomAddon

)

If exist "%CD%\Includes\Build_Mode.cmd" If /i "%ConfigOption%"=="B" goto ConfigBulkMode

rem If "%BuildAbort%" == "True" If /i "%ConfigOption%"=="S" goto ConfigSkipDriveSpaceCheck

If "%BuildAbort%" == "True" If "%ConfigOption%"=="IE" (
	Set IgnoreErrors=True
	goto Build_Settings_Complete
)

If /i "%ConfigOption%"=="U" goto ConfigRunStartUpActions

If "%ConfigOption%"=="CC" goto ConfigUseCMDColours
If "%ConfigOption%"=="TV" goto ConfigUseTestVersion
If "%ConfigOption%"=="IL" goto ConfigMBInfoLink

If /i "%ConfigOption%"=="D" goto ConfigDefault

If /i "%ConfigOption%"=="E" (
	If "%BuildAbort%" == "True" Set BuildRestart=False
	goto Build_Settings_Complete
)

If "%BuildAbort%" == "True" If /i "%ConfigOption%"=="R" (
	Set BuildRestart=True
	goto Build_Settings_Complete
)

goto Build_Settings_Start



:ConfigDownloads
Set FolderVariableName=DownloadsPath
Set CurrentFolder=!%FolderVariableName%!
Set FolderName=%DownloadsFolderName%
Set FolderPathLengthLimit=150
Goto ChangeFolder

:ConfigOutput
Set FolderVariableName=OutputPath
Set CurrentFolder=!%FolderVariableName%!
Set FolderName=%OutputFolderName%
Set FolderPathLengthLimit=150
Goto ChangeFolder

:ConfigTemp
Set FolderVariableName=TmpPath
Set CurrentFolder=!%FolderVariableName%!
Set FolderName=%TmpFolderName%
Set FolderPathLengthLimit=46
Goto ChangeFolder

:ChangeFolder
echo Please wait...
echo.
Set SelectedDrive=
Set SelectedFolder=
Set IsFixedDisk=

Set Command="(new-object -COM 'Shell.Application').BrowseForFolder(0,'Please select a Parent Directory for %FolderName%. For example, selecting C: would create C:\%FolderName%.',0x01,0x11).self.path"

For /f "usebackq delims=" %%i in (`powershell %Command%`) do (
	Set SelectedDrive=%%~di
	Set SelectedFolder=%%i
	
	If "!SelectedFolder:~3,1!" == "" (
		Set SelectedFolder=%%i%FolderName%
	) else (
		Set SelectedFolder=%%i\%FolderName%
	)

)

If "!SelectedFolder!" == "%CurrentFolder%" (
	echo %white%No change has been made, the new path selected for the %FolderName% folder is the same as the existing selection.%ef%
	pause
	goto Build_Settings_Start
)

If "!SelectedFolder!" == "" (
	echo %white%User cancelled, no change to the %FolderName% folder path has been made.%ef%
	pause
	goto Build_Settings_Start
)

If not "!SelectedFolder:~%FolderPathLengthLimit%,1!" == "" (
	echo %red%Error: No change has been made, the new path selected for the %FolderName% folder is too long.%ef%
	pause
	goto Build_Settings_Start
)

If not "!SelectedFolder!" == "" (

	for /f "skip=3 tokens=1,2 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; Get-CimInstance CIM_LogicalDisk | Select-Object DeviceID, DriveType"') do (
		Set Caption=%%a
		Set /a DriveType=%%b

		If "!DriveType!" equ "3" (
			If "%SelectedDrive%" == "!Caption!" (
				Set IsFixedDisk=True
			)
		)
	)

	If "!IsFixedDisk!" == "True" (

		MD "!SelectedFolder!" > NUL 2>&1
		If "!ErrorLevel!" EQU "0" (
			Set !FolderVariableName!=!SelectedFolder!
			Call "%CD%\Includes\Build_Config.cmd" BuildSaveCurrentConfig
			echo %green%%FolderName% folder path has been changed to "!SelectedFolder!"%ef%
			Set PathChange=True
		) else (
			echo %red%Error: No change has been made, the new path selected for the %FolderName% folder already exists or cannot be written to.%ef%
		)

	) else (
		echo %red%Error: No change has been made, the new path selected for the %FolderName% folder is not on a fixed disk.%ef%
	)

)

pause
goto Build_Settings_Start

:ConfigUseCMDColours
Set Toggle=UseCMDColours
Set ExitSettings=True
goto ToggleSwitch

:ConfigRunStartUpActions
Set Toggle=RunStartUpActions
goto ToggleSwitch

:ConfigUseTestVersion
Set Toggle=UseTestVersion
goto ToggleSwitch

:ConfigMBInfoLink
Set Toggle=MBInfoLink
goto ToggleSwitch

:ConfigDISM
Set Toggle=BundledDISM
goto ToggleSwitch

:ConfigSHA1
Set Toggle=SHA1Check
goto ToggleSwitch

:ConfigArchiveOrgTorrent
Set Toggle=ArchiveOrgTorrent
goto ToggleSwitch

:ConfigBootWinREWIM
Set Toggle=ExportBootWinREWIM
goto ToggleSwitch

:ConfigInstallWIM
Set Toggle=ExportInstallWIM
goto ToggleSwitch

:ConfigTryESDIfInstallWIMLargerThan4GB
Set Toggle=TryESDIfInstallWIMLargerThan4GB
goto ToggleSwitch

:ConfigSkipDriveSpaceCheck
Set Toggle=SkipDriveSpaceCheck
Set PathChange=True
goto ToggleSwitch

:ConfigAltWindowsActivation
Set Toggle=AltWindowsActivation
If "!AltWindowsActivation!" == "True" (
	Set WindowsProductKey=%DefaultWindowsProductKey%
	Set KMS38=True
	Set HWIDTicket=False
) else (
	Set WindowsProductKey=%AltWindowsProductKey%
	Set KMS38=False
	Set HWIDTicket=True
)
goto ToggleSwitch

:ConfigKMS38
Set Toggle=KMS38
goto ToggleSwitch

:ConfigHWIDTicket
Set Toggle=HWIDTicket
goto ToggleSwitch

:ConfigAltOfficeActivation
Set Toggle=AltOfficeActivation
If "!AltOfficeActivation!" == "True" (
	Set OfficeProductKey=%DefaultOfficeProductKey%
) else (
	Set OfficeProductKey=%AltOfficeProductKey%
	echo %red%Warning: Switching the Office Product Key Type to Retail requires a valid Office 2013 Home ^& Business Key to
	echo be set using Option 8, the default key provided will not activate.%ef%
	pause
)
goto ToggleSwitch

:ConfigWinToGo
Set Toggle=WinToGo
goto ToggleSwitch

:ConfigCustomAddon
Set Toggle=CustomAddon
goto ToggleSwitch

:ConfigBulkMode
Set Toggle=BulkMode
Set PathChange=True
goto ToggleSwitch

:ToggleSwitch
If "!%Toggle%!" == "True" (
	Set %Toggle%=False
) else (
	Set %Toggle%=True
)

Call "%CD%\Includes\Build_Config.cmd" BuildSaveCurrentConfig
If "%ExitSettings%" == "True" goto Build_Settings_Complete
goto Build_Settings_Start



:ConfigMediaLabel
Set "NewMediaLabel="
Set /p NewMediaLabel="Please enter a new ISO/USB/VHD Media Label: "
echo.

If not "!NewMediaLabel:~10,1!" == "" (
	If "!NewMediaLabel!" == "" (
		echo %red%Error: No change has been made, new label name was blank.%ef%
	) else (
		echo %red%Error: No change has been made, new label name was too long.%ef%
	)
	pause
	goto Build_Settings_Start
) else (
	echo(!NewMediaLabel!|"%SystemRoot%\System32\findstr.exe" /i /r "^[a-z0-9-_]*$" > nul || (
		echo %red%Error: No change has been made, new label name contains invalid characters.%ef%
		pause
		goto Build_Settings_Start
	)

	Set MediaLabel=!NewMediaLabel!
	Call "%CD%\Includes\Build_Config.cmd" BuildSaveCurrentConfig
	echo %green%ISO/USB Media Label has been changed to "!MediaLabel!"%ef%
)

pause
goto Build_Settings_Start



:ConfigWinKey
Set Product=Windows
goto ProductKey

:ConfigOfficeKey
Set Product=Office
goto ProductKey

:ProductKey
Set New%Product%ProductKey=
Set /p New%Product%ProductKey="Please enter a new %Product% product key: "
echo.

Set New%Product%ProductKey=!New%Product%ProductKey: =!

If "!New%Product%ProductKey:~29,1!" == "" (
	If not "!New%Product%ProductKey:~28,1!" == "" (
		echo(!New%Product%ProductKey!|"%SystemRoot%\System32\findstr.exe" /i /r "^[2346789BCDFGHJKMNPQRTVWXY-]*$" > nul || (
			echo %red%Error: No change has been made, new %Product% product key contains invalid characters.%ef%
			pause
			goto Build_Settings_Start
		)
		Set %Product%ProductKey=!New%Product%ProductKey!
		Call "%CD%\Includes\Build_Config.cmd" BuildSaveCurrentConfig
		echo %green%%Product% product key has been changed to "!%Product%ProductKey!"%ef%
	) else (
		echo %red%Error: No change has been made, new %Product% product key was too short.%ef%
	)
) else (
	If "!New%Product%ProductKey!" == "" (
		echo %red%Error: No change has been made, new %Product% product key was blank.%ef%
	) else (
		echo %red%Error: No change has been made, new %Product% product key was too long.%ef%
	)
)

pause
goto Build_Settings_Start



:ConfigKMS
Set "NewKMSAddress="
Set /p NewKMSAddress="Please enter a new KMS address: "
echo.

Set NewKMSAddress="!NewKMSAddress!"

If !NewKMSAddress! == "" (
	echo %red%Error: No change has been made, new KMS address was blank.%ef%
	pause
	goto Build_Settings_Start
) else (
	If not %NewKMSAddress% == %NewKMSAddress: =% (
		echo %red%Error: No change has been made, new KMS address contains invalid characters.%ef%
		pause
		goto Build_Settings_Start
	)
rem	echo(!NewKMSAddress!|"%SystemRoot%\System32\findstr.exe" /i /r "^[a-z0-9-_/.~:]*$" > nul || (
rem	echo(!NewKMSAddress!|"%SystemRoot%\System32\findstr.exe" /i /r "^["^""a-z0-9_.-~!*'();:@&=+$,/?#[]]*$" > nul || (
rem		echo %red%Error: No change has been made, new KMS address contains invalid characters.%ef%
rem		pause
rem		goto Build_Settings_Start
rem	)
	Set KMS=!NewKMSAddress:"=!
	Call "%CD%\Includes\Build_Config.cmd" BuildSaveCurrentConfig
	echo %green%KMS address has been changed to "!KMS!"%ef%
)

pause
goto Build_Settings_Start

:ConfigDISMLog
Set /a DISMLogLevel+=1
If !DISMLogLevel! GTR 4 Set /a DISMLogLevel=1
Call "%CD%\Includes\Build_Config.cmd" BuildSaveCurrentConfig	

goto Build_Settings_Start

:ConfigDefault
Set PathChange=True
Call "%CD%\Includes\Build_Config.cmd" BuildSetDefault
If "!ErrorLevel!" EQU "0" (
	echo %green%Default settings restored.%ef%
) else (
	echo %red%Error: Unable to restore default settings.%ef%
)

pause
goto Build_Settings_Start

REM ====== End =========================================================================================================================================================

:Build_Settings_Complete

If "%SettingsStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "SettingsStage="