@echo off

REM ====== Write Info Files ============================================================================================================================================

Set InfoStage=%1
Set Index=%2
Set InfoMode=%3

If "%InfoMode%" == "" (
	goto InfoComplete
) else (
	goto %InfoMode%
)

REM ====== Mod Kit Info Output =========================================================================================================================================

:mediabuilder

If "%InfoStage%" == "infopreview" (
	Set Tab=	
	If "%Build%" == "False" (
		Set OfficeText=Download Office 2013 RT Home ^^^& Student Plus Files Only
	) else (
		Set OfficeText=Build Office 2013 RT Home ^^^& Student Plus Installation Package
	)
	goto Preview
) else (
	Set Tab=
	Set OfficeText=Office 2013 RT Home ^^^& Student Plus
)

(
	:Preview
	If "%InfoStage%" == "infowrite" (
		echo === Builder ==========================================================================================================================================
		echo.
		If "%InfoStage%" == "infowrite" If "%Office2013RT_Install%" == "True" (
			echo %MBName% %MBVer% - %MBDate%
			echo Download List: %Office2013RT_UpdatedLast%
		) else (
			echo %MBName% %MBVer%
		)
		echo.
	)
	If not "%Office2013RT_FileMissing%" == "True" If exist "%CD%\Includes\Install_Office_2013_RT_HSP.cmd" (
		If "%InfoStage%" == "infowrite" (
		echo === Office ===========================================================================================================================================
		echo.
		)
		If "%Office2013RT_Install%" == "False" (
			echo %Tab%%OfficeText% %Office2013RT_UpdateDescription%
		) else (
			If "!DownloadAll!" == "True" (
				If "%InfoStage%" == "infopreview" (
					echo %Tab%%OfficeText% ^(All^)%Office2013RT_UpdateDescription%
				) else (
					echo %Tab%%OfficeText% ^(%Office2013RT_LP_Language%^)%Office2013RT_UpdateDescription%
				)
			) else (
			echo %Tab%%OfficeText% ^(%Office2013RT_LP_Language%^)%Office2013RT_UpdateDescription%
			)
		)
		If "%Build%" == "True" (
			If "%ActLink%" == "True" (
				echo %Tab%Office Activation Script Type: %OfficeActTypText%
			) else (
				If "%InfoStage%" == "infopreview" echo %Tab%Office Activation Script: %ActLink%
			)
			If "%InfoStage%" == "infopreview" (
				echo %Tab%Create ZIP file: %MakeOfficeArc%
			)
		)

	)
	If "%InfoStage%" == "infopreview" (
		echo.
		goto InfoComplete
	)
) > "%TmpPath%\info.txt"


goto InfoComplete

REM ====== End =========================================================================================================================================================

:InfoComplete

If "%InfoStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "InfoStage="
Set "Index="
Set "InfoMode="