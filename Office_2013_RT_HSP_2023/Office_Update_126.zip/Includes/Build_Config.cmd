@echo off

REM ====== Set =========================================================================================================================================================

Set ConfigStage=%1

If "%ConfigStage%" == "" (
	goto BuildConfigComplete
) else (

	If not exist "!CD!\Config" md "!CD!\Config" 1> nul
	Set MBConfig=!CD!\Config\Build_Config.cfg

	If exist "!MBConfig!" (
		Attrib -r -s -h "!MBConfig!" 1> nul
	)

	goto %ConfigStage%
)

:BuildConfig

REM ====== Write Build_Config.cfg if not found using the default values or read values from Build_Config.cfg if it is found ============================================

REM The values below are defaults if no Build_Config.cfg is found.

Set BulkMode=False
Set BulkModeOutputFolderSpaceReq=80
Set BulkModeDownloadsSpaceReq=10

Set DownloadsFolderName=Downloads
Set DownloadsSpaceReq=2
Set OutputFolderName=Office_Media
Set OutputFolderSpaceReq=4
Set TmpFolderName=Tmp
Set TmpFolderSpaceReq=4
Set TmpFolderPathLen=100

Set SysDriveSpaceReq=4

Set DownloadsPath=%CD%\%DownloadsFolderName%
Set OutputPath=%CD%\%OutputFolderName%
Set TmpPath=%CD%\%TmpFolderName%
Set SkipOSCheck=False
Set SHA1Check=True
Set KMS=kms9.MSGuides.com
Set SkipServiceChecks=False
Set SkipDriveSpaceCheck=False
Set SkipDriveFileSystemCheck=True
Set FileSource=A
Set UseCMDColours=True
Set MBInfoLink=True
Set RunStartUpActions=True
Set UseTestVersion=False
Set UseTSforge=True

Set DefaultOfficeProductKey=KBKQT-2NMXY-JJWGP-M62JB-92CD4
Set OfficeProductKey=!DefaultOfficeProductKey!

Set AltOfficeActivation=False
Set AltOfficeProductKey=MNGCG-Q62BY-2V7R9-F64XX-KP8C3

If "%TorrentClientFound%" == "True" Set ArchiveOrgTorrent=True

Set OfficeForceAltDownload=False
Set OfficeUpdateForceAltDownload=False
Set OfficeLangPackForceAltDownload=False

Set MediaBuilderInfoURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/mediabuilder
Set OfficeListsURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/Office_2013_RT_HSP_2023/Office

REM ====== Read / Write Build_Config.cfg ===============================================================================================================================

If not exist "%MBConfig%" (

	setlocal DisableDelayedExpansion
	(
		echo ###### Created by %~nx0 ######
		echo DownloadsPath=!CD!\%DownloadsFolderName%
		echo OutputPath=!CD!\%OutputFolderName%
		echo TmpPath=!CD!\%TmpFolderName%
		echo SkipOSCheck=%SkipOSCheck%
		echo SHA1Check=%SHA1Check%
		echo KMS=%KMS%
		echo SkipServiceChecks=%SkipServiceChecks%
		echo SkipDriveSpaceCheck=%SkipDriveSpaceCheck%
		echo SkipDriveFileSystemCheck=%SkipDriveFileSystemCheck%
		echo OfficeProductKey=%OfficeProductKey%
		echo AltOfficeActivation=%AltOfficeActivation%
		If "%TorrentClientFound%" == "True" echo ArchiveOrgTorrent=%ArchiveOrgTorrent%
		echo UseCMDColours=%UseCMDColours%
		echo BulkMode=%BulkMode%
		echo OfficeForceAltDownload=%OfficeForceAltDownload%
		echo OfficeUpdateForceAltDownload=%OfficeUpdateForceAltDownload%
		echo OfficeLangPackForceAltDownload=%OfficeLangPackForceAltDownload%
		echo MBInfoLink=%MBInfoLink%
		echo RunStartUpActions=%RunStartUpActions%
		echo UseTestVersion=%UseTestVersion%
		echo UseTSforge=%UseTSforge%
	) > "%MBConfig%"
	setlocal EnableDelayedExpansion

) else (

	For /f "usebackq skip=1 tokens=*" %%a in ("%MBConfig%") do (
		For /f "tokens=1* delims==" %%a in ("%%a") do (
			If not "%%b" == "" Set "%%a=%%b"
		)
	)

)

goto BuildConfigComplete

REM ====== Save Build_Config.cfg with current values ===================================================================================================================

:BuildSaveCurrentConfig

(
	echo ###### Created by %~nx0 ######

	If "%DownloadsPath%" == "!CD!\%DownloadsFolderName%" (
		setlocal DisableDelayedExpansion
		echo DownloadsPath=!CD!\%DownloadsFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo DownloadsPath=!DownloadsPath!
	)

	If "%OutputPath%" == "!CD!\%OutputFolderName%" (
		setlocal DisableDelayedExpansion
		echo OutputPath=!CD!\%OutputFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo OutputPath=!OutputPath!
	)

	If "%TmpPath%" == "!CD!\%TmpFolderName%" (
		setlocal DisableDelayedExpansion
		echo TmpPath=!CD!\%TmpFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo TmpPath=!TmpPath!
	)

rem	echo DownloadsPath=!DownloadsPath!
rem	echo OutputPath=!OutputPath!
rem	echo TmpPath=!TmpPath!
	echo SkipOSCheck=!SkipOSCheck!
	echo SHA1Check=!SHA1Check!
	echo KMS=!KMS!
	echo SkipServiceChecks=!SkipServiceChecks!
	echo SkipDriveSpaceCheck=!SkipDriveSpaceCheck!
	echo SkipDriveFileSystemCheck=!SkipDriveFileSystemCheck!
	echo OfficeProductKey=!OfficeProductKey!
	echo AltOfficeActivation=!AltOfficeActivation!
	If "%TorrentClientFound%" == "True" echo ArchiveOrgTorrent=!ArchiveOrgTorrent!
	echo UseCMDColours=!UseCMDColours!
	echo BulkMode=!BulkMode!
	echo OfficeForceAltDownload=!OfficeForceAltDownload!
	echo OfficeUpdateForceAltDownload=!OfficeUpdateForceAltDownload!
	echo OfficeLangPackForceAltDownload=!OfficeLangPackForceAltDownload!
	echo MBInfoLink=!MBInfoLink!
	echo RunStartUpActions=!RunStartUpActions!
	echo UseTestVersion=!UseTestVersion!
	echo UseTSforge=!UseTSforge!
) > "%MBConfig%"

goto BuildConfigComplete

REM ====== Set default Build_Config.cfg values =========================================================================================================================

:BuildSetDefault

If exist "%MBConfig%" (
	Del "%MBConfig%" /F /Q 1> nul
)

goto BuildConfig

REM ====== End =========================================================================================================================================================

:BuildConfigComplete

If "%ConfigStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "ConfigStage="