@echo off

Set Office2013RT_DownloadLists=%CD%\Download_Lists
Set Office2013RT_Downloads=!DownloadsPath!

Set Office2013RT_Installer=Office_2013_RT_HSP_Installer.txt
Set Office2013RT_LanguagePacks=Office_2013_RT_HSP_Language_Packs.txt

If "%AltOfficeActivation%" == "True" (
Set Office2013RT_XrMLZip=AltXrML.zip
Set Office2013RT_XrMLZipSHA1=8888a6ab7d5bf8e8b51ed0ee0442cafd5d3bf9d3
) else (
Set Office2013RT_XrMLZip=XrML.zip
Set Office2013RT_XrMLZipSHA1=8e43f5d362928bcef44d20611a908ce80496b833
)

Set Office2013RT_Tmp=!TmpPath!\
Set Office2013RT_UpdateTmp=!TmpPath!\Updates
Set Office2013RT_UpdateListTmp=!TmpPath!\UpdateList

REM ====== Set =========================================================================================================================================================

Set OfficeStage=%1

If "%OfficeStage%" == "" (
	goto Office2013RTComplete
) else (
	goto %OfficeStage%
)

REM ====== Office Options Menu==========================================================================================================================================

:Office2013RTMenu

If "%AltOfficeActivation%" == "True" (
	Set OfficeActTypText=Retail
) else (
	Set OfficeActTypText=GVLK
)

For %%a in (
	"%CD%\License\%Office2013RT_XrMLZip%"
	"%Office2013RT_DownloadLists%\%Office2013RT_Installer%"
	"%Office2013RT_DownloadLists%\%Office2013RT_LanguagePacks%"
) do (
	If not exist %%a (
		goto Office2013RTError
	)
)

Rem cls

:Office2013RT_InstallSelect

Set Office2013RT_Prompt=Y
Goto SkipOfficePrompt

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.

Set /p Office2013RT_Prompt=Would you like to create an Office 2013 RT Home ^& Student Plus installation package (Y/N)? 
:SkipOfficePrompt
If /i "%Office2013RT_Prompt%"=="Y" Set Office2013RT_Install=True
If /i "%Office2013RT_Prompt%"=="N" (
	Set Office2013RT_Install=False
	Goto Office2013RTComplete
)
If "%Office2013RT_Install%" == "" goto Office2013RT_InstallSelect

rem Set /p OfficeDownloadList=< "%Office2013RT_DownloadLists%\%Office2013RT_Installer%"

rem For /f "tokens=1,2,3,4 delims=#" %%a in ("%OfficeDownloadList%") do (
rem 		Set Office2013RT_Installer_URL=%%a
rem 		Set Office2013RT_Installer_FileName=%%~NXa
rem 		Set Office2013RT_Installer_SHA1=%%c
rem 		Set Office2013RT_Installer_Torrent=%%b
rem 		Set Office2013RT_Installer_TorrentFileName=%%~NXb
rem 		Set Office2013RT_Installer_TorrentDir=!Office2013RT_Installer_TorrentFileName:_archive.torrent=!
rem 		Set Office2013RT_Installer_Source=%%d
rem )

Set FindLanguage=ms-MY
Set OfficeDownloadList="%Office2013RT_DownloadLists%\%Office2013RT_Installer%"

For /F "usebackq tokens=* skip=1" %%a in (%OfficeDownloadList%) do (
	For /f "tokens=1-19 delims=," %%a in ("%%a") do (
		If /i "%%a" == "%FindLanguage%" (
			Set Office2013RT_Installer_Tag=%%a
			Set Office2013RT_Installer_Language=%%b
			Set Office2013RT_Installer_Country=%%c
			Set Office2013RT_Installer_LCID=%%d
			Set Office2013RT_Installer_UNUSED1=%%e
			Set Office2013RT_Installer_UNUSED2=%%f

			If /i "!OfficeForceAltDownload!" == "True" (

				Set Office2013RT_Installer_HTTPSourceName=%%n
				Set Office2013RT_Installer_URL=%%o
				Set Office2013RT_Installer_FileName=%%~NXo

				Set Office2013RT_Installer_TorrentSourceName=%%p
				Set Office2013RT_Installer_TorrentURL=%%q
				Set Office2013RT_Installer_TorrentFileName=%%~NXq
				Set Office2013RT_Installer_TorrentDir=!Office2013RT_Installer_TorrentFileName:_archive.torrent=!
				Set Office2013RT_Installer_TorrentM=%%r
				Set Office2013RT_Installer_TorrentIndex=%%s

			) else (

				Set Office2013RT_Installer_HTTPSourceName=%%g
				Set Office2013RT_Installer_URL=%%h
				Set Office2013RT_Installer_FileName=%%~NXh

				Set Office2013RT_Installer_TorrentSourceName=%%i
				Set Office2013RT_Installer_TorrentURL=%%j
				Set Office2013RT_Installer_TorrentFileName=%%~NXj
				Set Office2013RT_Installer_TorrentDir=!Office2013RT_Installer_TorrentFileName:_archive.torrent=!
				Set Office2013RT_Installer_TorrentM=%%k
				Set Office2013RT_Installer_TorrentIndex=%%l

			)

			Set Office2013RT_Installer_SHA1=%%m

		)
	)
)

If /i "%ArchiveOrgTorrent%" == "True" (
	Set Office2013RT_Installer_Source=!Office2013RT_Installer_TorrentSourceName!
) else (
	Set Office2013RT_Installer_Source=!Office2013RT_Installer_HTTPSourceName!
)

If exist "%CD%\Temp.cmd" Call "%CD%\Temp.cmd" Office2013RT_Installer_List

:Office2013RT_LanguageSelect
If "!ReadPreset!" == "True" goto Office2013RT_UseDefaultLanguage
cls
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p Office2013RT_LanguageSelectPrompt=The default Office language is English, would you like to select another language (Y/N)? 
If /i "%Office2013RT_LanguageSelectPrompt%"=="Y" Goto Office2013RT_LanguageMenuSelect
If /i "%Office2013RT_LanguageSelectPrompt%"=="N" (
	Set Office2013RT_SelectedLanguage=en-US
	Goto Office2013RT_UseDefaultLanguage
)
If "%Office2013RT_Language%" == "" goto Office2013RT_LanguageSelect

:Office2013RT_LanguageMenuSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Select Office Language:%ef%
echo.
echo		 1: Arabic ^(Saudi Arabia^)		15: Hebrew ^(Israel^)		29: Portuguese ^(Portugal^)
echo		 2: Bulgarian ^(Bulgaria^)		16: Hindi ^(India^)		30: Romanian ^(Romania^)
echo		 3: Chinese ^(Peoples Republic of China^)	17: Hungarian ^(Hungary^)		31: Russian ^(Russia^)
echo		 4: Chinese ^(Taiwan^)			18: Indonesian ^(Indonesia^)	32: Serbian ^(Serbia^)
echo		 5: Croatian ^(Croatia^)			19: Italian ^(Italy^)		33: Slovak ^(Slovakia^)
echo		 6: Czech ^(Czech Republic^)		20: Japanese ^(Japan^)		34: Slovenian ^(Slovenia^)
echo		 7: Danish ^(Denmark^)			21: Kazakh ^(Kazakhstan^)		35: Spanish ^(Spain^)
echo		 8: Dutch ^(Netherlands^)			22: Korean ^(Korea^)		36: Swedish ^(Sweden^)
echo		 9: English ^(United States^)		23: Latvian ^(Latvia^)		37: Thai ^(Thailand^)
echo		10: Estonian ^(Estonia^)			24: Lithuanian ^(Lithuania^)	38: Turkish ^(Turkey^)
echo		11: Finnish ^(Finland^)			25: Malay ^(Malaysia^)		39: Ukrainian ^(Ukraine^)
echo		12: French ^(France^)			26: Norwegian ^(Norway^)		40: Vietnamese ^(Vietnam^)
echo		13: German ^(Germany^)			27: Polish ^(Poland^)
echo		14: Greek ^(Greece^)			28: Portuguese ^(Brazil^)		0: %red%Cancel%ef%
echo.
Set /p Office2013RT_LanguageMenuSelectPrompt=%white%Select Language: 
echo. %ef%

If "%Office2013RT_LanguageMenuSelectPrompt%"=="1" Set Office2013RT_SelectedLanguage=ar-SA
If "%Office2013RT_LanguageMenuSelectPrompt%"=="2" Set Office2013RT_SelectedLanguage=bg-BG
If "%Office2013RT_LanguageMenuSelectPrompt%"=="3" Set Office2013RT_SelectedLanguage=zh-CN
If "%Office2013RT_LanguageMenuSelectPrompt%"=="4" Set Office2013RT_SelectedLanguage=zh-TW
If "%Office2013RT_LanguageMenuSelectPrompt%"=="5" Set Office2013RT_SelectedLanguage=hr-HR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="6" Set Office2013RT_SelectedLanguage=cs-CZ
If "%Office2013RT_LanguageMenuSelectPrompt%"=="7" Set Office2013RT_SelectedLanguage=da-DK
If "%Office2013RT_LanguageMenuSelectPrompt%"=="8" Set Office2013RT_SelectedLanguage=nl-NL
If "%Office2013RT_LanguageMenuSelectPrompt%"=="9" Set Office2013RT_SelectedLanguage=en-US
If "%Office2013RT_LanguageMenuSelectPrompt%"=="10" Set Office2013RT_SelectedLanguage=et-EE
If "%Office2013RT_LanguageMenuSelectPrompt%"=="11" Set Office2013RT_SelectedLanguage=fi-FI
If "%Office2013RT_LanguageMenuSelectPrompt%"=="12" Set Office2013RT_SelectedLanguage=fr-FR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="13" Set Office2013RT_SelectedLanguage=de-DE
If "%Office2013RT_LanguageMenuSelectPrompt%"=="14" Set Office2013RT_SelectedLanguage=el-GR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="15" Set Office2013RT_SelectedLanguage=he-IL
If "%Office2013RT_LanguageMenuSelectPrompt%"=="16" Set Office2013RT_SelectedLanguage=hi-IN
If "%Office2013RT_LanguageMenuSelectPrompt%"=="17" Set Office2013RT_SelectedLanguage=hu-HU
If "%Office2013RT_LanguageMenuSelectPrompt%"=="18" Set Office2013RT_SelectedLanguage=id-ID
If "%Office2013RT_LanguageMenuSelectPrompt%"=="19" Set Office2013RT_SelectedLanguage=it-IT
If "%Office2013RT_LanguageMenuSelectPrompt%"=="20" Set Office2013RT_SelectedLanguage=ja-JP
If "%Office2013RT_LanguageMenuSelectPrompt%"=="21" Set Office2013RT_SelectedLanguage=kk-KZ
If "%Office2013RT_LanguageMenuSelectPrompt%"=="22" Set Office2013RT_SelectedLanguage=ko-KR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="23" Set Office2013RT_SelectedLanguage=lv-LV
If "%Office2013RT_LanguageMenuSelectPrompt%"=="24" Set Office2013RT_SelectedLanguage=lt-LT
If "%Office2013RT_LanguageMenuSelectPrompt%"=="25" Set Office2013RT_SelectedLanguage=ms-MY
If "%Office2013RT_LanguageMenuSelectPrompt%"=="26" Set Office2013RT_SelectedLanguage=nb-NO
If "%Office2013RT_LanguageMenuSelectPrompt%"=="27" Set Office2013RT_SelectedLanguage=pl-PL
If "%Office2013RT_LanguageMenuSelectPrompt%"=="28" Set Office2013RT_SelectedLanguage=pt-BR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="29" Set Office2013RT_SelectedLanguage=pt-PT
If "%Office2013RT_LanguageMenuSelectPrompt%"=="30" Set Office2013RT_SelectedLanguage=ro-RO
If "%Office2013RT_LanguageMenuSelectPrompt%"=="31" Set Office2013RT_SelectedLanguage=ru-RU
If "%Office2013RT_LanguageMenuSelectPrompt%"=="32" Set Office2013RT_SelectedLanguage=sr-latn-CS
If "%Office2013RT_LanguageMenuSelectPrompt%"=="33" Set Office2013RT_SelectedLanguage=sk-SK
If "%Office2013RT_LanguageMenuSelectPrompt%"=="34" Set Office2013RT_SelectedLanguage=sl-SI
If "%Office2013RT_LanguageMenuSelectPrompt%"=="35" Set Office2013RT_SelectedLanguage=es-ES
If "%Office2013RT_LanguageMenuSelectPrompt%"=="36" Set Office2013RT_SelectedLanguage=sv-SE
If "%Office2013RT_LanguageMenuSelectPrompt%"=="37" Set Office2013RT_SelectedLanguage=th-TH
If "%Office2013RT_LanguageMenuSelectPrompt%"=="38" Set Office2013RT_SelectedLanguage=tr-TR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="39" Set Office2013RT_SelectedLanguage=uk-UA
If "%Office2013RT_LanguageMenuSelectPrompt%"=="40" Set Office2013RT_SelectedLanguage=vi-VN

If "%Office2013RT_LanguageMenuSelectPrompt%"=="0" goto SelectOfficeCancel

If "%Office2013RT_SelectedLanguage%" == "" goto Office2013RT_LanguageMenuSelect

:Office2013RT_UseDefaultLanguage

rem For /F "usebackq tokens=*" %%a in ("%Office2013RT_DownloadLists%\%Office2013RT_LanguagePacks%") do (
rem 	For /f "tokens=1,2,3,4,5,6 delims=#" %%a in ("%%a") do (
rem 		If "%%d" == "%Office2013RT_SelectedLanguage%" (
rem 			Set Office2013RT_LP_Language=%%a
rem 			Set Office2013RT_LP_Country=%%b
rem 			Set Office2013RT_LP_LCID=%%c
rem 			Set Office2013RT_LP_Tag=%%d
rem 			Set Office2013RT_LP_URL=%%e
rem 			Set Office2013RT_LP_FileName=%%~NXe
rem 			For /f "tokens=1-3 delims=_." %%a in ("!Office2013RT_LP_FileName!") do (
rem 				Set Office2013RT_LP_SHA1=%%b
rem 			)
rem 		)
rem 	)
rem )

Set OfficeLPDownloadList="%Office2013RT_DownloadLists%\%Office2013RT_LanguagePacks%"

For /F "usebackq tokens=* skip=1" %%a in (%OfficeLPDownloadList%) do (
	For /f "tokens=1-19 delims=," %%a in ("%%a") do (
		If /i "%%a" == "%Office2013RT_SelectedLanguage%" (
			Set Office2013RT_LP_Tag=%%a
			Set Office2013RT_LP_Language=%%b
			Set Office2013RT_LP_Country=%%c
			Set Office2013RT_LP_LCID=%%d
			Set Office2013RT_LP_UNUSED1=%%e
			Set Office2013RT_LP_AllowLP=%%f

			If /i "!OfficeLangPackForceAltDownload!" == "True" (

				Set Office2013RT_LP_HTTPSourceName=%%n
				Set Office2013RT_LP_URL=%%o
				Set Office2013RT_LP_FileName=%%~NXo
				For /f "tokens=1-3 delims=_." %%a in ("!Office2013RT_LP_FileName!") do (
					Set Office2013RT_LP_SHA1=%%b
				)

				Set Office2013RT_LP_TorrentSourceName=%%p
				Set Office2013RT_LP_TorrentURL=%%q
				Set Office2013RT_LP_TorrentFileName=%%~NXq
				Set Office2013RT_LP_TorrentDir=!Office2013RT_LP_TorrentFileName:_archive.torrent=!
				Set Office2013RT_LP_TorrentM=%%r
				Set Office2013RT_LP_TorrentIndex=%%s

			) else (

				Set Office2013RT_LP_HTTPSourceName=%%g
				Set Office2013RT_LP_URL=%%h
				Set Office2013RT_LP_FileName=%%~NXh
				For /f "tokens=1-3 delims=_." %%a in ("!Office2013RT_LP_FileName!") do (
					Set Office2013RT_LP_SHA1=%%b
				)

				Set Office2013RT_LP_TorrentSourceName=%%i
				Set Office2013RT_LP_TorrentURL=%%j
				Set Office2013RT_LP_TorrentFileName=%%~NXj
				Set Office2013RT_LP_TorrentDir=!Office2013RT_LP_TorrentFileName:_archive.torrent=!
				Set Office2013RT_LP_TorrentM=%%k
				Set Office2013RT_LP_TorrentIndex=%%l

			)

			Set Custom=%%m

		)
	)
)

If /i "%ArchiveOrgTorrent%" == "True" (
	Set Office2013RT_LP_Source=!Office2013RT_LP_TorrentSourceName!
) else (
	Set Office2013RT_LP_Source=!Office2013RT_LP_HTTPSourceName!
)

If exist "%CD%\Temp.cmd" Call "%CD%\Temp.cmd" Office2013RT_LP_List

:Office2013RT_UpdateModeSelect

If exist "%Office2013RT_DownloadLists%\Last_Updated" (
	Set /p Office2013RT_UpdatedLast=< "%Office2013RT_DownloadLists%\Last_Updated"
	For /f "tokens=1-2 delims=#" %%a in ("!Office2013RT_UpdatedLast!") do (
		Set Office2013RT_UpdatedRelease=%%a
		Set Office2013RT_UpdatedLast=%%b
	)
) else (
	Set Office2013RT_UpdatedRelease=Unknown Release
	Set Office2013RT_UpdatedLast=Unknown Date
)


If /i "!OfficeUpdateForceAltDownload!" == "True" Set OfficeUpdateListExt=_Alt


Set Office2013RT_UpdateListSP1Common=Office_2013_RT_HSP_SP1!OfficeUpdateListExt!.txt
Set Office2013RT_UpdateListSP1=%Office2013RT_LP_Tag%\Office_2013_RT_HSP_SP1!OfficeUpdateListExt!.txt

Set Office2013RT_UpdateListPostSP1Common=Office_2013_RT_HSP_Post_SP1!OfficeUpdateListExt!.txt
Set Office2013RT_UpdateListPostSP1=%Office2013RT_LP_Tag%\Office_2013_RT_HSP_Post_SP1!OfficeUpdateListExt!.txt


For %%a in (
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1Common%"
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1%"
) do (
	If not exist %%a Set Office2013RT_NoSP1List=True
)

For %%a in (
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1Common%"
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1%"
) do (
	If not exist %%a Set Office2013RT_NoPostSP1List=True
)

If "!FirstRun!" == "False" If "!ReadPreset!" == "True" goto Office2013RT_UpdateModeSelectSkip

If not "%Office2013RT_NoSP1List%" == "True" (
	cls
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %white%Select Office Update Options:%ef%
	echo.
	echo		1: %blue%No Updates%ef%
	echo.
	echo		2: %blue%Service Pack 1%ef%
	echo.
	If not "%Office2013RT_NoPostSP1List%" == "True" (
	echo		3: %blue%Service Pack 1 ^& Post Service Pack 1 Updates to %Office2013RT_UpdatedLast%%ef%
	echo.
	)
	echo		0: %red%Cancel%ef%
	echo.
	Set /p Office2013RT_UpdateModeSelect=%white%Enter Selection: %ef%
) else (
	goto SelectOfficeNoUpdate
)

:Office2013RT_UpdateModeSelectSkip

If "!Office2013RT_UpdateModeSelect!"=="1" goto SelectOfficeNoUpdate
If not "%Office2013RT_NoSP1List%" == "True" If "!Office2013RT_UpdateModeSelect!"=="2" goto SelectOfficeSP1
If not "%Office2013RT_NoPostSP1List%" == "True" If "!Office2013RT_UpdateModeSelect!"=="3" goto SelectOfficePostSP1
If "!Office2013RT_UpdateModeSelect!"=="0" goto SelectOfficeCancel

goto Office2013RT_UpdateModeSelect

:SelectOfficeNoUpdate
Set Office2013RT_InstallTime=5
Set OfficeUpdateLevelText=_
goto ActLinkSelect

:SelectOfficeSP1
Set Office2013RT_Update=True
Set Office2013RT_UpdateDescription= - Including Service Pack 1
Set Office2013RT_InstallTime=10
Set OfficeUpdateLevelText=_SP1_
goto ActLinkSelect

:SelectOfficePostSP1
Set Office2013RT_Update=True
Set Office2013RT_PostSP1=True
Set Office2013RT_UpdateDescription= - Including updates to %Office2013RT_UpdatedLast%
Set Office2013RT_InstallTime=30
Set OfficeUpdateLevelText=_%Office2013RT_UpdatedLast: =_%_
goto ActLinkSelect

:SelectOfficeCancel
Set Office2013RT_Cancel=True
Set Office2013RT_Install=False
Set Office2013RT_Update=False
Set Office2013RT_PostSP1=False
goto Office2013RTComplete

:ActLinkSelect
If "!FirstRun!" == "False" If "!ReadPreset!" == "True" goto MakeOfficeArcSelect

If "%Build%"=="False" (
	Set ActLink=False
	goto MakeOfficeArcSelect
)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set ActLinkPrompt=
Set /p ActLinkPrompt=Would you like to include an activation script (%OfficeActTypText%) (Y/N)? 
If /i "%ActLinkPrompt%"=="Y" Set ActLink=True
If /i "%ActLinkPrompt%"=="N" Set ActLink=False
If "%ActLink%" == "" goto ActLinkSelect

:MakeOfficeArcSelect
If "!FirstRun!" == "False" If "!ReadPreset!" == "True" goto ConfirmSelect

If "%Build%"=="False" (
	Set MakeOfficeArc=False
	goto ConfirmSelect
)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set MakeOfficeArcPrompt=
Set /p MakeOfficeArcPrompt=Would you like to create a ZIP of the installation package(s) (Y/N)? 
If /i "%MakeOfficeArcPrompt%"=="Y" Set MakeOfficeArc=True
If /i "%MakeOfficeArcPrompt%"=="N" Set MakeOfficeArc=False
If "%MakeOfficeArc%" == "" goto MakeOfficeArcSelect

REM ====== Confirm =====================================================================================================================================================

:ConfirmSelect
If "!FirstRun!" == "False" goto Office2013RTComplete
cls
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %red%Please confirm the following selection is correct:%ef%
echo.

Call "%CD%\Includes\Mod_Info_Files.cmd" infopreview 0 mediabuilder

echo %red%Please do not close this window until all operations are complete.%ef%
echo.

Set /p ConfirmPrompt=Would you like to continue%ConfirmPromptText%? (Y/N)? 
If /i "%ConfirmPrompt%"=="Y" goto Office2013RTComplete
If /i "%ConfirmPrompt%"=="N" (
	Set Office2013RT_Cancel=True
	goto Office2013RTComplete
)

goto ConfirmSelect


Goto Office2013RTComplete

REM ====== Download Office 2013 RT =====================================================================================================================================

:Office2013RTDownload

REM ====== Timer =======================================================================================================================================================

Set "startTime=%time: =0%"

echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Downloading Office 2013 RT Home ^& Student Plus Installation Files ^(!Office2013RT_LP_Language!^).%ef%
If "!DownloadAll!" == "True" (
	echo %green%!DownloadAllCounter!%ef%
)
echo Please wait...
echo.

For %%d in (
	"%Office2013RT_Downloads%"
	"%Office2013RT_Tmp%"
	"%Office2013RT_UpdateTmp%"
	"%Office2013RT_UpdateListTmp%"
) do (
	If not exist %%d md %%d 1> nul
)

REM ====== Check if Office already downloaded ==========================================================================================================================

If exist "%Office2013RT_Downloads%\!Office2013RT_Installer_FileName!" (
	echo %white%Installer found, skipping download.%ef%
	goto SkipOfficeInstallerDownload
)

REM ====== Download Office =============================================================================================================================================

If /i "%Office2013RT_Installer_TorrentIndex%" == "False" goto OfficeWget

If /i "%ArchiveOrgTorrent%" == "True" (
	netsh advfirewall firewall add rule name="Windows Media Builder - tget" dir=in action=allow program="%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" enable=yes 1> nul
	"%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" /1 /t "%Office2013RT_Installer_TorrentURL%" /o "%TmpPath%" /n
	Set TorrentClientStatus=!ErrorLevel!
	netsh advfirewall firewall delete rule name="Windows Media Builder - tget" program="%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" 1> nul
)

If /i "%ArchiveOrgTorrent%" == "True" (
	If !TorrentClientStatus! EQU 0 (
		Move /y "%TmpPath%\%Office2013RT_Installer_TorrentDir%\%Office2013RT_Installer_FileName%" "%Office2013RT_Downloads%\" 1> nul
		echo.
		goto SkipOfficeInstallerDownload
	) else (
		echo.
		echo %red%Error: Unable to download Office installer.%ef%
		echo %red%Error: !TorrentClientStatus!%ef%
		pause
		Set Office2013RT_Abort=True
		Goto Office2013RTError
	)
)

:OfficeWget

"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" "!Office2013RT_Installer_URL!" -P "%Office2013RT_Downloads%" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to download Office installer.%ef%
	echo %red%Wget Error: !ErrorLevel!%ef%
	Set Office2013RT_Abort=True
	pause
	Goto Office2013RTError
)

:SkipOfficeInstallerDownload

If not exist "%Office2013RT_Downloads%\!Office2013RT_LP_FileName!" (
	"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" "!Office2013RT_LP_URL!" -P "%Office2013RT_Downloads%" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
) else (
	echo %white%!Office2013RT_LP_Language! language pack found, skipping download.%ef%
)

If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to download Office language pack.%ef%
	echo %red%Wget Error: !ErrorLevel!%ef%
	Set Office2013RT_Abort=True
	pause
	Goto Office2013RTError
)

If "%Office2013RT_Update%" == "True" (

	For /F "usebackq tokens=*" %%A in (
		"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1Common%"
		"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1%"
	) do (
		echo %%A>> "%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt"
	)
	Set Office2013RT_UpdateList="%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt"

	If "%Office2013RT_PostSP1%" == "True" (

		For /F "usebackq tokens=*" %%A in (
			"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1Common%"
			"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1%"
		) do (
			echo %%A>> "%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_Post_SP1.txt"
		)
	Set Office2013RT_UpdateList="%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt";"%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_Post_SP1.txt"
	)

	For %%a in (
		!Office2013RT_UpdateList!
	) do (
		"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -i %%a -P "%Office2013RT_Downloads%\%%~na" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
		Set WgetErrorLevel=!ErrorLevel!
	)
)

If not "!WgetErrorLevel!" == "" If "!WgetErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to download Office updates.%ef%
	echo %red%Wget Error: !WgetErrorLevel!%ef%
	Set Office2013RT_Abort=True
	pause
	Goto Office2013RTError
)

If /i "%SHA1Check%" == "False" (
		If "%Office2013RT_SelectedLanguage%" == "vi-VN" If "!DownloadAll!" == "True" (
			echo.
			echo %green%Download All Complete.%ef%
		)
		If "!DownloadSingle!" == "True" (
			echo.
			echo %green%Download Single Language Complete ^(!Office2013RT_LP_Language!^).%ef%
		)
)

Goto Office2013RTComplete

REM ====== Office 2013 RT Verify =======================================================================================================================================

:Office2013RTVerify
If /i "%SHA1Check%" == "True" (

	echo.
	echo %white%Verifying Installation Files.%ef%
	echo Please wait...
	echo.

	If "%UsePS%" == "True" (
		For /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a
	) else (
		For /f %%a In ('WMIC OS GET LocalDateTime ^| %SystemRoot%\System32\find.exe "."') Do Set RenameTime=%%a
	)

	Set VerifyList=
	If "!DownloadAll!" == "True" (
		If "%Office2013RT_SelectedLanguage%" == "ar-SA" Set VerifyList=%Office2013RT_Installer_SHA1%#"%Office2013RT_Downloads%\%Office2013RT_Installer_FileName%"
		Set VerifyList=!VerifyList!;%Office2013RT_LP_SHA1%#"%Office2013RT_Downloads%\%Office2013RT_LP_FileName%"
		If "%Office2013RT_SelectedLanguage%" == "ar-SA" If "!ActLink!" == "True" Set VerifyList=!VerifyList!;%Office2013RT_XrMLZipSHA1%#"%CD%\License\%Office2013RT_XrMLZip%"
	) else (
		Set VerifyList=%Office2013RT_Installer_SHA1%#"%Office2013RT_Downloads%\%Office2013RT_Installer_FileName%"
		Set VerifyList=!VerifyList!;%Office2013RT_LP_SHA1%#"%Office2013RT_Downloads%\%Office2013RT_LP_FileName%"
		If "!ActLink!" == "True" Set VerifyList=!VerifyList!;%Office2013RT_XrMLZipSHA1%#"%CD%\License\%Office2013RT_XrMLZip%"
	)

	For %%a in (
		!VerifyList!
	) do (
		For /f "tokens=1,2 delims=#" %%b in ("%%a") do (

			Set Office2013RT_FileSHA1=%%b
			Set Office2013RT_File=%%c
			Set Office2013RT_BrokenPath=%%~dpc%%~nc_Corrupt\!RenameTime:~0,14!

	 		For /f "delims=" %%d in ('%SystemRoot%\System32\certutil.exe -hashfile !Office2013RT_File! SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
				Set z=%%d
				Set Office2013RT_FileFoundSHA1=!z: =!
			)

			If not !Office2013RT_FileSHA1! equ !Office2013RT_FileFoundSHA1! (
				echo %red%File Bad: %%~nxc%ef%

				attrib -s -h -r /s /d "%%a" 1> nul

				If Not Exist "!Office2013RT_BrokenPath!\" md "!Office2013RT_BrokenPath!\" 1> nul
				Move /y !Office2013RT_File! "!Office2013RT_BrokenPath!\" 1> nul
				If exist !Office2013RT_File! (
					echo.
					echo %red%Error: Unable to move corrupt file...%ef%
					echo %red%!Office2013RT_File!%ef%
					Set Office2013RT_Abort=True
					goto Office2013RTComplete
				) else (
					echo Moved To: "!Office2013RT_BrokenPath!\"
				)
				
				If !Office2013RT_File! == "%CD%\License\%Office2013RT_XrMLZip%" (
					echo.
					echo %red%Error: "%Office2013RT_XrMLZip%" cannot be replaced automatically, reinstall Media Builder.%ef%
					Set Office2013RT_Abort=True
					goto Office2013RTComplete
				)

				Set OfficeUpdate_Retry=True

			) else (
				echo %green%File OK: %%~nxc%ef%
			)
		)
	)

	If not "!OfficeUpdate_Retry!" == "True" If not "%Office2013RT_Update%" == "True" (
		echo.
		echo %white%Verified Office Files.%ef%
		If not "%Office2013RT_Update%" == "True" If "!DownloadSingle!" == "True" (
			echo.
			echo %green%Download Single Language Complete ^(!Office2013RT_LP_Language!^).%ef%
		)
	)


	If not "%Office2013RT_Update%" == "True" If "!OfficeUpdate_Retry!" == "True" (
		echo.

		If "!OfficeUpdate_RetryCount!" == "1" (
			echo %red%Error: Failed to replace corrupt Office files.%ef%
			Set Office2013RT_Abort=True
			goto Office2013RTComplete
		) else (
			echo %white%Corrupt Office Files Found ^& Moved.%ef%
			echo.
			echo Attempting to replace corrupt files...

			If exist "%Office2013RT_Tmp%\" (
				attrib -s -h -r /s /d "%Office2013RT_Tmp%\*.*" > NUL 2>&1
				del "%Office2013RT_Tmp%\*.*" /F /Q /S > NUL 2>&1
				rmdir /Q /S "%Office2013RT_Tmp%" > NUL 2>&1
			)

			If exist "%Office2013RT_Tmp%\" (
				echo %red%Error: Failed to delete Office temporary files.%ef%
				Set Office2013RT_Abort=True
				goto Office2013RTComplete
			) else (
				Set OfficeUpdate_RetryCount=1
			)

		)
	)


)

REM ====== Check Office Updates SHA1 ===================================================================================================================================

If /i "%SHA1Check%" == "True" If "%Office2013RT_Update%" == "True" (

	echo.
	echo %white%Verifying Updates.%ef%
	echo Please wait...
	echo.

	If "%UsePS%" == "True" (
		For /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a
	) else (
		For /f %%a In ('WMIC OS GET LocalDateTime ^| %SystemRoot%\System32\find.exe "."') Do Set RenameTime=%%a
	)

	For %%i in (
		%Office2013RT_UpdateList%
	) do (

		Set OfficeUpdateListFileName=%%~ni
		Set OfficeUpdatePath=!Office2013RT_Downloads!\!OfficeUpdateListFileName!
		Set OfficeUpdatePathBroken=!OfficeUpdatePath!_Corrupt\!RenameTime:~0,14!

		For /F "usebackq tokens=*" %%b in (%%i) do (

			Set Office2013RT_UpdateURL=%%b
			For %%c in ("!Office2013RT_UpdateURL!") do (
				Set Office2013RT_UpdateFileName=%%~NXc
			)

			Set Office2013RT_UpdateFileNameList=!Office2013RT_UpdateFileNameList!;!Office2013RT_UpdateFileName!

		)

		For %%a in (!Office2013RT_UpdateFileNameList!) do (

			Attrib -a -r -s -h "%%a" 1> nul

			Set OfficeUpdate_FileName=%%~NXa
			For /f "tokens=1-3 delims=_." %%a in ("!OfficeUpdate_FileName!") do (
				Set OfficeUpdate_SHA1=%%b
			)

	 		For /f "delims=" %%d in ('%SystemRoot%\System32\certutil.exe -hashfile "!OfficeUpdatePath!\%%a" SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
				Set z=%%d
				Set OfficeUpdate_FileFoundSHA1=!z: =!
			)

			If /I not !OfficeUpdate_SHA1! equ !OfficeUpdate_FileFoundSHA1! (
				echo %red%File Bad: %%~nxa%ef%

				attrib -s -h -r /s /d "%%a" 1> nul

				If Not Exist "!OfficeUpdatePathBroken!\" md "!OfficeUpdatePathBroken!\" 1> nul
				Move /y "!OfficeUpdatePath!\%%a" "!OfficeUpdatePathBroken!\" 1> nul
				If exist "%%a" (
					echo.
					echo %red%Error: Unable to move corrupt update...%ef%
					echo %red%"%%a"%ef%
					Set Office2013RT_Abort=True
					goto Office2013RTComplete
				) else (
					echo Moved To: "!OfficeUpdatePathBroken!\"
				)

				Set OfficeUpdate_Retry=True
			) else (
				echo %green%File OK: %%~nxa%ef%
			)

		)

	Set Office2013RT_UpdateFileNameList=

	)

	If "!OfficeUpdate_Retry!" == "True" (
		echo.

		If "!OfficeUpdate_RetryCount!" == "1" (
			echo %red%Error: Failed to replace corrupt Office files.%ef%
			Set Office2013RT_Abort=True
			goto Office2013RTComplete
		) else (
			echo %white%Corrupt Office Files Found ^& Moved.%ef%
			echo.
			echo Attempting to replace corrupt files...

			If exist "%Office2013RT_Tmp%\" (
				attrib -s -h -r /s /d "%Office2013RT_Tmp%\*.*" > NUL 2>&1
				del "%Office2013RT_Tmp%\*.*" /F /Q /S > NUL 2>&1
				rmdir /Q /S "%Office2013RT_Tmp%" > NUL 2>&1
			)

			If exist "%Office2013RT_Tmp%\" (
				echo %red%Error: Failed to delete Office temporary files.%ef%
				Set Office2013RT_Abort=True
				goto Office2013RTComplete
			) else (
				Set OfficeUpdate_RetryCount=1
			)

		)

	) else (
		echo.
		echo %white%Verified Office Files.%ef%
		If "%Office2013RT_SelectedLanguage%" == "vi-VN" If "!DownloadAll!" == "True" (
			echo.
			echo %green%Download All Complete.%ef%
		)
		If "!DownloadSingle!" == "True" (
			echo.
			echo %green%Download Single Language Complete ^(!Office2013RT_LP_Language!^).%ef%
		)
	)

)

Goto Office2013RTComplete

REM ====== Extract Office 2013 RT Updates ==============================================================================================================================

:Office2013RTUpdates

If "!OfficeUpdate_Retry!" == "True" goto Office2013RTComplete
If "!Build!" == "False" goto Office2013RTComplete

Set Office2013RT_UpdatePrefix=100

rem echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Preparing Updates.%ef%
echo Please wait...
echo.

For %%a in (
	%Office2013RT_UpdateList%
) do (
	
	For /F "usebackq tokens=*" %%b in (%%a) do (

		Set Office2013RT_UpdateURL=%%b

		For %%c in ("!Office2013RT_UpdateURL!") do (
			Set Office2013RT_UpdateFileName=%%~NXc
		)

		Set Office2013RT_UpdateFileNameList=!Office2013RT_UpdateFileNameList!;!Office2013RT_UpdateFileName!

	)

	For %%d in (!Office2013RT_UpdateFileNameList!) do (

		For /f "tokens=1,2,3 delims=_." %%x in ("%%d") do (
			Set Office2013RT_UpdateFileNameStart=%%x
			Set Office2013RT_UpdateFileNameEnd=%%y
			Set Office2013RT_UpdateFileNameExt=%%z
		)
		
		"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%Office2013RT_Downloads%\%%~na\%%d" -o"%Office2013RT_UpdateTmp%" "!Office2013RT_UpdateFileNameStart!.msp" >nul 2>&1

		If "!ErrorLevel!" NEQ "0" (
			echo Failed to extract: %%d
			Set Office2013RT_Abort=True
			goto Office2013RTComplete
		) else (
			echo Extracted: %%d
			Rename "%Office2013RT_UpdateTmp%\!Office2013RT_UpdateFileNameStart!.msp" "!Office2013RT_UpdateFileNameStart!_!Office2013RT_UpdateFileNameEnd!.msp" 1> nul
		)

	)

	Set Office2013RT_UpdateFileNameList=
)

If not "%Office2013RT_Abort%" == "True" (
	echo.
	echo %white%Updates Prepared.%ef%
)

For /f "USEBACKQ delims=|" %%e in (`dir /b /od "%Office2013RT_UpdateTmp%\*.msp"`) do (
	Rename "%Office2013RT_UpdateTmp%\%%e" "!Office2013RT_UpdatePrefix!_%%e"
	Set /a Office2013RT_UpdatePrefix+=1
)

Goto Office2013RTComplete

REM ====== Copy Office 2013 RT =========================================================================================================================================

:Office2013RTCopy

echo.
echo %white%Preparing Office 2013 RT Home ^& Student Plus Installer.%ef%
echo Please wait...
echo.

If "%UsePS%" == "True" (
	For /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set DTS=%%a
) else (
	For /f %%a In ('WMIC OS GET LocalDateTime ^| %SystemRoot%\System32\find.exe "."') Do Set DTS=%%a
)

Set Date1=%DTS:~6,2%-%DTS:~4,2%-%DTS:~0,4%
Set Time1=%DTS:~8,2%-%DTS:~10,2%-%DTS:~12,2%

Set MediaFolderName=Office_2013_RT_HSP%OfficeUpdateLevelText%%Office2013RT_LP_Tag%_%Date1%_%Time1%
Set MediaFolderPath=%TmpPath%\%MediaFolderName%
If not exist "%MediaFolderPath%" Md "%MediaFolderPath%" 1> nul

Set Office2013RT_Destination=%MediaFolderPath%

For %%a in (a b c d e f g h i j k l m n o p q r s t u v w x y z) do (
	Set Office2013RT_LP_Tag=!Office2013RT_LP_Tag:%%a=%%a!
)

REM === Extract CAB from EXE ===========================================================================================================================================

For %%o in (
	"%Office2013RT_Downloads%\%Office2013RT_Installer_FileName%#OfficeInstaller"
	"%Office2013RT_Downloads%\%Office2013RT_LP_FileName%#OfficeLanguagePack"
) do (
	For /f "tokens=1-2 delims=#" %%a in (%%o) do (
		"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" e -t# "%%a" -o"%Office2013RT_Tmp%" "2.cab" >nul 2>&1
		If not !ErrorLevel! EQU 0 (
			echo %red%Error: Unable to extract file.%ef%
			echo Error: !ErrorLevel!
			Set Office2013RT_Abort=True
			Goto Office2013RTError
		) else (
			echo Extracted: %%~nxa
		)
		Set %%b=%%~no.cab
		Rename "%Office2013RT_Tmp%\2.cab" %%~no.cab 1> nul
		If "!ErrorLevel!" NEQ "0" (
			echo %red%Error: Unable to rename !Office2013RT_Tmp!\2.cab%ef%
			echo %red%Error: !ErrorLevel!%ef%
			Set Office2013RT_Abort=True
			Goto Office2013RTError
		)
	)
)

REM === Extract files from CAB and rename when needed ==================================================================================================================

For /f "usebackq tokens=*" %%o in (
	"%Office2013RT_DownloadLists%\Office_2013_RT_HSP_Installer_Extract.txt"
	"%Office2013RT_DownloadLists%\Office_2013_RT_HSP_Language_Packs_Extract.txt"
	"%Office2013RT_DownloadLists%\%Office2013RT_LP_Tag%\Office_2013_RT_HSP_Language_Packs_Extract.txt"
) do (

	For /f "tokens=1-4 delims=#" %%a in ("%%o") do (

		If not exist "%%b" (
			Set OfficeDir=%%b
			md "%%b" 1> nul

			If "!ErrorLevel!" NEQ "0" (
				echo %red%Error: Unable to create directory %%b%ef%
				echo %red%Error: !ErrorLevel!%ef%
				Set Office2013RT_Abort=True
				Goto Office2013RTError
			) else (
				echo.
				Set "CreatedDir=!OfficeDir:%MediaFolderPath%=!"
				echo %green%Creating directory: !CreatedDir!%ef%
			)
		)

		"%SystemRoot%\System32\expand.exe" "%Office2013RT_Tmp%\%%a" -F:%%c "%%b" 1> nul
		If "!ErrorLevel!" NEQ "0" (
			echo %red%Error: Unable to extract %%c%ef%
			echo %red%Error: !ErrorLevel!%ef%
			Set Office2013RT_Abort=True
			Goto Office2013RTError
		) else (
			echo Extracted: %%c
		)

		If not "%%d" == "" (
			rename "%%b\%%c" "%%d" 1> nul
			If "!ErrorLevel!" NEQ "0" (
				echo %red%Error: Unable to rename %%c%ef%
				echo %red%Error: !ErrorLevel!%ef%
				Set Office2013RT_Abort=True
				Goto Office2013RTError
			) else (
				echo Renamed %%c to %%d
			)
		)

	)

)

If "%ActLink%" == "False" goto SkipXrML

echo.

"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%CD%\License\%Office2013RT_XrMLZip%" -o"%Office2013RT_Destination%\activation" "*.xrm-ms" > nul
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to extract XrML files.%ef%
	Set Office2013RT_Abort=True
	Goto Office2013RTError
) else (
	echo %green%Copied XrML Files: %Office2013RT_XrMLZip%%ef%
)

:SkipXrML

If "%Office2013RT_Update%" == "True" (
	Move /Y "%Office2013RT_UpdateTmp%\*.msp" "%Office2013RT_Destination%\updates" 1> nul
	If "!ErrorLevel!" NEQ "0" (
		echo %red%Error Copying Updates: !ErrorLevel!%ef%
		Set Office2013RT_Abort=True
		Goto Office2013RTError
	) else (
		echo %green%Copied Office Updates.%ef%
	)
)

Call "%CD%\Includes\Mod_Info_Files.cmd" infowrite 0 mediabuilder

If exist "%TmpPath%\info.txt" (

	If Exist "%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt" (
		(
			echo.
			echo === Included Service Pack 1 Updates ==================================================================================================================
			echo.
		) >> "%TmpPath%\info.txt"

		For /F "usebackq tokens=*" %%A in (
			"%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt"
		) do (
			echo %%A>> "%TmpPath%\info.txt"
		)
	)

	If Exist "%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_Post_SP1.txt" (
		(
			echo.
			echo === Included Post Service Pack 1 Updates =============================================================================================================
			echo.
		) >> "%TmpPath%\info.txt"
		For /F "usebackq tokens=*" %%A in (
			"%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_Post_SP1.txt"
		) do (
			echo %%A>> "%TmpPath%\info.txt"
		)
	)

)


If exist "%TmpPath%\info.txt" move /y "%TmpPath%\info.txt" "%Office2013RT_Destination%\" 1> nul


(
	echo ^<Configuration Product="HomeStudentPls"^>
	echo ^<Display Level="full" CompletionNotice="yes" SuppressModal="no" AcceptEula="yes" /^>
	echo ^</Configuration^>
) > "%Office2013RT_Destination%\homestudentpls.ww\config.xml"

If "%ActLink%" == "False" goto SkipActLink

(
	echo @echo off
	echo @setlocal enableextensions
	echo For /f "tokens=1,2,3,4 USEBACKQ delims=," %%%%a IN ^(`"%SystemRoot%\System32\whoami.exe /groups /fo csv /nh"`^) Do ^(
	echo 	If %%%%c == "S-1-16-12288" Set RunAsAdmin=True
	echo ^)
	echo If not "%%RunAsAdmin%%" == "True" ^(
	echo 	echo Error: Please run as administrator.
	echo 	echo.
	echo 	goto Exit
	echo ^)
	echo Set /a WinVerMinBuild=9600
	echo If not exist "%%SystemRoot%%\System32\wbem\WMIC.exe" Set UsePS=True
	echo If "%%UsePS%%" == "True" ^( 
	echo 	For /f "skip=3 tokens=1-3 delims=." %%%%a in ^('powershell -c "$ErrorActionPreference='Stop'; Get-CimInstance win32_operatingsystem | Select-Object Version"'^) do ^(
	echo 		Set /a WinVerMajor=%%%%a
	echo 		Set /a WinVerMinor=%%%%b
	echo 		Set /a WinVerBuild=%%%%c
	echo 		goto BuildNumber
	echo 	^) 
	echo ^) else ^(
	echo 	For /f "usebackq skip=2 tokens=2-4 delims==. " %%%%a in ^(`wmic os get Version /format:list`^) do ^(
	echo 		Set /a WinVerMajor=%%%%a
	echo 		Set /a WinVerMinor=%%%%b
	echo 		Set /a WinVerBuild=%%%%c
	echo 		goto BuildNumber
	echo 	^)
	echo ^)
	echo :BuildNumber
	echo If %%WinVerMinBuild%% == %%WinVerBuild%% ^(
	echo 	echo Error: Not for Windows RT 8.1.
	echo 	echo.
	echo 	goto Exit
	echo ^)
	echo If "%%PROCESSOR_ARCHITECTURE%%" == "ARM" goto Continue
	echo If "%%PROCESSOR_ARCHITECTURE%%" == "ARM64" goto Continue
	echo echo Error: %PROCESSOR_ARCHITECTURE% systems are not supported.
	echo echo Please retry on an ARM or ARM64 system.
	echo echo.
	echo Goto Exit
	echo :Continue
	echo echo Do not close while license modification is in progress^^!
	echo echo.
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Office15.HOMESTUDENTPLS" /t REG_DWORD /v "NoModify" /d 00000001 /f
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Office15.HOMESTUDENTPLS" /t REG_DWORD /v "SystemComponent" /d 00000000 /f
	echo echo.
	echo echo Removing Office 2013 RT Home ^^^& Student Plus Product Key
	echo slmgr /upk //b ebef9f05-5273-404a-9253-c5e252f50555
	echo echo.
	echo echo Installing License Files...
	echo echo.
	echo pushd "%%~dp0"
	echo for %%%%a in ^(*.xrm-ms^) do ^(
	echo 	echo %%%%~nxa
	echo 	slmgr //b /ilc %%%%~nxa
	echo 	^)
	echo popd
	echo echo.
If "%AltOfficeActivation%" == "True" (
	echo echo Entering Office 2013 Home ^^^& Business Retail Product Key
) else (
	echo echo Entering Office 2013 Standard Volume License Product Key
	echo slmgr /skms //b !KMS!
)
	echo slmgr /ipk //b %OfficeProductKey%
	echo slmgr /ato //b
	echo echo.
	echo echo Office will attempt to activate automatically if an internet connection is available, if the activation server
	echo echo is not online this may not happen instantly.
	echo echo.
	echo For %%%%a in ^(
rem	echo		%%systemdrive%%\MSOCache
	echo		%%systemdrive%%\Windows\Installer\$PatchCache$
	echo ^) do ^(
	echo		If exist "%%%%a\" ^(
	echo			attrib -s -h -r /s /d "%%%%a\*.*" ^> nul
	echo			del "%%%%a\*.*" /F /Q /S ^> nul
	echo			rmdir /Q /S "%%%%a\" ^> nul
	echo		^)
	echo ^)
	echo :Exit
	echo pause
	echo exit
) > "%Office2013RT_Destination%\activation\Activate.cmd"

(
	echo @echo off
	echo Call "%%CD%%\activation\Activate.cmd"
) > "%Office2013RT_Destination%\activate.cmd"

:SkipActLink

If not exist "!OutputPath!" Md "!OutputPath!" 1> nul

If "%MakeOfficeArc%" == "True" (
	echo.
	echo %white%Creating ZIP file.%ef%
	echo Please wait....

	"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" a "%TmpPath%\!MediaFolderName!.zip" "%MediaFolderPath%\*"
	If "!ErrorLevel!" NEQ "0" (
		echo %red%Error: Failed to create ZIP file.%ef%
		echo %red%7-Zip Error !ErrorLevel!.%ef%
	) else (
		Move /y "%TmpPath%\!MediaFolderName!.zip" "!OutputPath!" 1> nul
	)
)

If "%MakeOfficeArc%" == "False" (

If "%SameDrv%" == "True" (
	Move /y "%MediaFolderPath%" "!OutputPath!" 1> nul
) else (
	echo.
	echo Please wait...
	"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%" "!OutputPath!\%MediaFolderName%" 1> nul
)

)


REM ====== Timer =======================================================================================================================================================

:Timer
If "%DownloadAll%" == "True" goto SkipMBInfoLink
Set "endTime=%time: =0%"
Set "end=!endTime:%time:~8,1%=%%100)*100+1!"  &  set "start=!startTime:%time:~8,1%=%%100)*100+1!"
Set /A "elap=((((10!end:%time:~2,1%=%%100)*60+1!%%100)-((((10!start:%time:~2,1%=%%100)*60+1!%%100), elap-=(elap>>31)*24*60*60*100"
Set /A "cc=elap%%100+100,elap/=100,ss=elap%%60+100,elap/=60,mm=elap%%60+100,hh=elap/60+100"
Set RunTime=%hh:~1%%time:~2,1%%mm:~1%%time:~2,1%%ss:~1%

If not "%MBInfoLink%" == "True" goto SkipMBInfoLink

Set MBInfoFile=%temp%\mb_%random%_%random%_%random%
"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -O "%MBInfoFile%.tmp" %MediaBuilderInfoURL% -nc --timeout=2 --read-timeout=2 --tries=2 --no-check-certificate -q --show-progress --progress=bar:force:noscroll >nul 2>&1
If exist "%MBInfoFile%.tmp" %systemroot%\System32\certutil.exe -f -decode "%MBInfoFile%.tmp" "%MBInfoFile%.cmd" >nul 2>&1
If exist "%MBInfoFile%.cmd" call "%MBInfoFile%.cmd" >nul 2>&1

:SkipMBInfoLink

REM ====== Run Setup ===================================================================================================================================================

If "%MakeOfficeArc%" == "False" (
	If not exist "!OutputPath!\!MediaFolderName!\setup.exe" goto Office2013RTComplete
) else (
	If not exist "%MediaFolderPath%\setup.exe" goto Office2013RTComplete
)
If %WinVerBuild% GEQ %WinVerMinBuild% If "%PROCESSOR_ARCHITECTURE%" == "ARM" goto Win9600Check
If %WinVerBuild% GEQ %WinVerMinBuild% If "%PROCESSOR_ARCHITECTURE%" == "ARM64" goto Win9600Check
goto Office2013RTComplete

:Win9600Check
If "%DownloadAll%" == "True" goto Office2013RTComplete
If %WinVerBuild% EQU 15035 goto RunSetupSelect
If "!9600Install!" == "True" goto RunSetupSelect

goto Office2013RTComplete

:RunSetupSelect
If exist "%ProgramFiles%\Microsoft Office\Office15\EXCEL.exe" goto Office2013RTComplete
echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p RunSetupPrompt=Would you like to launch Office setup (Y/N)? 
If /i "%RunSetupPrompt%"=="Y" (
	echo.
	echo %white%Launching Office 2013 RT Home ^& Student Plus Builder Setup.%ef%
	echo Pleae wait...
	echo.
	echo %red%Please do not close this window.%ef%

If "%MakeOfficeArc%" == "False" (
	If exist "!OutputPath!\!MediaFolderName!\setup.exe" start /b /wait "" "!OutputPath!\!MediaFolderName!\setup.exe" > NUL 2>&1
) else (
	If exist "%MediaFolderPath%\setup.exe" start /b /wait "" "%MediaFolderPath%\setup.exe" > NUL 2>&1
)
	If "!ErrorLevel!" EQU "0" (
		echo.
rem		If %WinVerBuild% EQU 9600 (
		"%systemroot%\System32\reg.exe" add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Office15.HOMESTUDENTPLS" /t REG_DWORD /v "NoModify" /d 00000001 /f
		"%systemroot%\System32\reg.exe" add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Office15.HOMESTUDENTPLS" /t REG_DWORD /v "SystemComponent" /d 00000000 /f
rem		)
	If "%MakeOfficeArc%" == "False" (
		If "!ActLink!" == "True" If %WinVerBuild% EQU 15035 If exist "!OutputPath!\!MediaFolderName!\activation\activate.cmd" start /b /wait "" "!OutputPath!\!MediaFolderName!\activation\activate.cmd"
	) else (
		If "!ActLink!" == "True" If %WinVerBuild% EQU 15035 If exist "%MediaFolderPath%\activation\activate.cmd" start /b /wait "" "%MediaFolderPath%\activation\activate.cmd"
	)
	)
	goto Office2013RTComplete
)

If /i "%RunSetupPrompt%"=="N" goto Office2013RTComplete
If "%RunSetup%" == "" goto RunSetupSelect

Goto Office2013RTComplete

REM ====== Error =======================================================================================================================================================

:Office2013RTError

Set Office2013RT_Install=False
Set Office2013RT_Update=False
Set Office2013RT_FileMissing=True

goto Office2013RTComplete

REM ====== End =========================================================================================================================================================

:Office2013RTComplete

If "%OfficeStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "OfficeStage="