@echo off
@setlocal enableextensions
@setlocal EnableDelayedExpansion

@Title Office Media Builder Cleanup

REM ====== Network Drive/Share Check ===================================================================================================================================

If "%~d0" == "\\" (
	Set BuildAbort=True
)

"%SystemRoot%\System32\net.exe" use > NUL 2>&1
If "!ErrorLevel!" EQU "2" goto SkipMappedDriveCheck

"%SystemRoot%\System32\net.exe" use | "%SystemRoot%\System32\findstr.exe" /I /L /C:" %~d0 " >nul
If not "!ErrorLevel!" EQU "1" (
	Set BuildAbort=True
)

:SkipMappedDriveCheck

If "%BuildAbort%" == "True" (
	echo Error: Media Builder cannot be run from a mapped drive or network share.
	goto ExitNoTempClear
)

@cd /d "%~dp0"

REM ====== Check only one instance is running ==========================================================================================================================

9>&2 2>nul (call :LockAndRestoreStdErr %* 8>>"%~f0") || (
	echo Error: Only one instance allowed. >&2
)
goto Exit

:LockAndRestoreStdErr
call :SingleInstance %* 2>&9
exit /b 0

:SingleInstance

9>&2 2>nul (call :LockAndRestoreStdErr1 %* 8>>"!CD!\Build.cmd") || (
	echo Error: Only one instance allowed. >&2
)
goto Exit

:LockAndRestoreStdErr1
call :SingleInstance1 %* 2>&9
exit /b 0

:SingleInstance1

REM ====== Checks ======================================================================================================================================================

:Start
setlocal

Set SkipDriveCheckInt=True
Set CleanupOnly=True

If exist "%CD%\Includes\Build_Common.cmd" (
	echo Please Wait...
	Call "%CD%\Includes\Build_Common.cmd" BuildCommon %~nx0
) else (
	echo %red%Error: File Missing...%ef%
	echo "!CD!\Includes\Build_Common.cmd"
	BuildAbort=True
)

If "%BuildRestart%"=="True" (
	cls
	endlocal
	goto Start
)

If "%BuildAbort%"=="True" goto Exit

REM ====== Menu ========================================================================================================================================================
:Select
cls
Set "Action="
echo ___________________________
echo.
echo Ofice Media Builder Cleanup
echo ___________________________
echo.
echo Select Action:	 1: Delete Temporary Files
echo			 2: Delete Office Downloads
echo.
echo			 9: Delete Office Installation Media
echo.
echo			 E: Exit
echo.
set /p Action=Enter Selection: 
echo.

if /i "%Action%"=="E" goto Exit

if "%Action%"=="1" goto DeleteTempFiles
if "%Action%"=="2" goto DeleteOfficeDownloads
if "%Action%"=="9" goto DeleteOfficeMedia
cls
goto Select

:DeleteTempFiles
If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	@echo on
	attrib -s -h -r /s /d "%TmpPath%\*.*"
	del "%TmpPath%\*.*" /F /Q /S
	rmdir /Q /S "%TmpPath%\"
	@echo off
)
echo.
pause
cls
goto Start


:DeleteOfficeDownloads
If not "%DownloadsPath%" == "" If exist "%DownloadsPath%" (
	@echo on
	attrib -s -h -r /s /d "%DownloadsPath%\*.*"
	del "%DownloadsPath%\*.*" /F /Q /S
	rmdir /Q /S "%DownloadsPath%\"
	@echo off
)
echo.
pause
cls
goto Start


:DeleteOfficeMedia
If not "%OutputPath%" == "" If exist "%OutputPath%" (
	@echo on
	attrib -s -h -r /s /d "%OutputPath%\*.*"
	del "%OutputPath%\*.*" /F /Q /S
	rmdir /Q /S "%OutputPath%\"
	@echo off
)
echo.
pause
cls
goto Start

:Exit
echo ________________________________________________________________________________________________________________________
echo.
Echo Goodbye^^!
pause
Exit