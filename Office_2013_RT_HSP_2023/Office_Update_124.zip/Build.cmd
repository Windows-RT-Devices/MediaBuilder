@echo off
@setlocal enableextensions
@setlocal EnableDelayedExpansion
cls

Set /a MBVerNumber=124

Set MBName=Office 2013 RT Home ^^^& Student Plus Media Builder
Set MBVer=v%MBVerNumber:~0,1%.%MBVerNumber:~1,2%
Set MBDate=26-07-2024
@Title %MBName% - %MBVer%

REM	jwa4

REM ====== Network Drive/Share Check ===================================================================================================================================

If "%~d0" == "\\" (
	Set BuildAbort=True
)

"%SystemRoot%\System32\net.exe" use > NUL 2>&1
If "!ErrorLevel!" EQU "2" goto SkipMappedDriveCheck

"%SystemRoot%\System32\net.exe" use | "%SystemRoot%\System32\findstr.exe" /I /L /C:" %~d0 " >nul
If not "!ErrorLevel!" EQU "1" (
	Set BuildAbort=True
)

:SkipMappedDriveCheck

If "%BuildAbort%" == "True" (
	echo Error: Media Builder cannot be run from a mapped drive or network share.
	goto ExitNoTempClear
)

@cd /d "%~dp0"

REM ====== Check only one instance is running ==========================================================================================================================

9>&2 2>nul (Call :LockAndRestoreStdErr %* 8>>"%~f0") || (
	echo %red%Error: Only one instance allowed. >&2%ef%
)
goto ExitNoTempClear

:LockAndRestoreStdErr
Call :SingleInstance %* 2>&9
exit /b 0

:SingleInstance

9>&2 2>nul (call :LockAndRestoreStdErr1 %* 8>>"!CD!\Cleanup.cmd") || (
	echo %red%Error: Only one instance allowed. >&2%ef%
)
goto ExitNoTempClear

:LockAndRestoreStdErr1
call :SingleInstance1 %* 2>&9
exit /b 0

:SingleInstance1

REM ====== Checks ======================================================================================================================================================

Set MBFirstRun=True

:Start
setlocal

If /i "!MBFirstRun!" == "True" (
	endlocal & Set MBFirstRun=False
	setlocal & Set MBFirstRunInt=True
)

If exist "%CD%\Includes\Build_Common.cmd" (
	echo Please Wait...
	Call "%CD%\Includes\Build_Common.cmd" BuildCommon %~nx0
) else (
	echo %red%Error: File Missing...%ef%
	echo "!CD!\Includes\Build_Common.cmd"
	Set BuildAbort=True
)

If "%BuildRestart%"=="True" (
	cls
	endlocal
	goto Start
)

If "%BuildAbort%"=="True" goto ExitNoTempClear

REM ====== Menu Text ===================================================================================================================================================
@Title %MBName% - %MBVer%
Set NL=^


Set MenuText=%white%%ul%___________________________________________________________________%ef%!NL!^
!NL!^
%white%%MBName% %MBVer% - %MBDate%%ef%!NL!^
%white%%ul%___________________________________________________________________%ef%!NL!^
!NL!^
7-Zip - Copyright (C) 1999-2019 Igor Pavlov.!NL!^
GNU Wget - Copyright (C) 1996-2008, Free Software Foundation, Inc.!NL!^
tget - Copyright (C) 2024, sweetbbak. !NL!^
!NL!^
This media builder will create an Office 2013 RT HSP installation package for any supported language and optionally!NL!^
download and integrate Office updates. The created installation package has only been tested on Windows 10 Build 15035!NL!^
for ARM32 and it may not be suitable for use on other ARM32 or ARM64 builds of Windows.!NL!^
!NL!^
Apart from a leaked Malaysian version there are no installation packages for Office 2013 RT HSP available. The output!NL!^
from this media builder is a kitbash of the Malaysian installer and publicly available language packs and updates.!NL!^
!NL!^
%red%The use of this builder or the installation package it produces is entirely at your own risk.%ef%!NL!^
%ul%________________________________________________________________________________________________________________________%ef%

Set InfoBar=%info%  INFO                                INFO                                    INFO                                INFO  %ef%
Set WarningBar=%warn% WARNING                             WARNING                                WARNING                             WARNING %ef%

REM ====== Main Menu ===================================================================================================================================================

:MainMenu
cls

echo !MenuText!
echo.
echo %white%Options:%ef%	 1: Create Office 2013 RT Home ^& Student Plus Installation Package
If "%SHA1Check%" == "True" (
echo		 	 2: Download ^& Verify Office 2013 RT Home ^& Student Plus Files Only
) else (
echo		 	 2: Download Office 2013 RT Home ^& Student Plus Files Only
)
echo.
If /i not "!DisableDownloadListUpdates!" == "True" (
echo			 U: Update Media Builder ^(Download Lists Only^)
)
If /i not "!DisableMediaBuilderUpdates!" == "True" (
echo			 B: Update Media Builder ^(Full Update^)
)
echo			 S: Settings
echo.
echo			 E: %red%Exit%ef%				!%MBMessageColour%!%MBMessage%%ef%
echo.
Set /p Target=%white%Enter Selection: %ef%

:SkipTarget

If exist "%CD%\Includes\Build_Mode.cmd" If /i "%Target%"=="1" (
	Set Build=True
	Call "%CD%\Includes\Build_Mode.cmd" DownloadModeSelect
	cls
	endlocal & Set "SkipDriveCheckInt="
	goto Start
)

If exist "%CD%\Includes\Build_Mode.cmd" If /i "%Target%"=="2" (
	Set Build=False
	Call "%CD%\Includes\Build_Mode.cmd" DownloadModeSelect
	cls
	endlocal & Set "SkipDriveCheckInt="
	goto Start
)

If exist "%CD%\Includes\Build_Settings.cmd" If /i "%Target%"=="S" (
	Set PathChange=False
	Call "%CD%\Includes\Build_Settings.cmd" Build_Settings_Start
	cls
	If "!PathChange!" == "True" endlocal & Set SkipDriveCheckInt=False
	If "!PathChange!" == "False" endlocal & Set SkipDriveCheckInt=True
	goto Start
)

If /i not "!DisableDownloadListUpdates!" == "True" If exist "%CD%\Includes\Build_UpdateLists.cmd" If /i "%Target%"=="U" (
	Call "%CD%\Includes\Build_UpdateLists.cmd" UpdateAllLists
	cls
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

If /i not "!DisableMediaBuilderUpdates!" == "True" If /i "%Target%"=="B" (
	Call "%CD%\Includes\Build_Common.cmd" ForceUpdateCheck %~nx0 True
	cls
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

If /i "%Target%"=="E" goto Exit

goto MainMenu

REM ====== Done / Cleanup ==============================================================================================================================================

:Exit

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)

:ExitNoTempClear
If "%MBInfoLink%" == "True" If exist "%MBInfoFile%_2.cmd" call "%MBInfoFile%_2.cmd" >nul 2>&1
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Echo Goodbye^^!
Pause
Exit