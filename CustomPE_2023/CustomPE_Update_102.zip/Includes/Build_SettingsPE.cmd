@echo off

REM ====== Set =========================================================================================================================================================

Set SettingsStage=%1

If "%SettingsStage%" == "" (
	goto Build_Settings_Complete
) else (
	goto %SettingsStage%
)

REM ====== Configuration ===============================================================================================================================================

:Build_Settings_Start
cls
For %%a in (
	BundledDISM
	ExportBootWinREWIM
	SkipDriveSpaceCheck
	WinToGo
	CustomAddon
	UseCMDColours
	ADKTools19041
	WDD
	UMCI
	TestMode
	Apply9600SSU
	Force9600BootFiles15035
	AIOInclude_SurfaceRT
	AIOInclude_Surface2
	AIOInclude_Yoga11
	AIOInclude_VivoTab
	AIOInclude_XPS10
	AIOInclude_Lumia2520
	AIOInclude_ATIVTab
	AIOInclude_Generic
	AIOInclude_Custom
	AIOInclude_DeviceScripts
	AIOInclude_BootIndexSelectionScript
	RunStartUpActions
) do (
	If "!%%a!" == "True" (
		Set MenuModeText=%green%Enabled%ef%
	) else (
		Set MenuModeText=%red%Disabled%ef%
	)

	Set %%aMenuModeText=!MenuModeText!
)

If "!DISMLogLevel!" == "1" Set DISMLogText=(Errors only)
If "!DISMLogLevel!" == "2" Set DISMLogText=(Errors and warnings)
If "!DISMLogLevel!" == "3" Set DISMLogText=(Errors, warnings, and informational)
If "!DISMLogLevel!" == "4" Set DISMLogText=(All information and debug output)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.

If "%BuildAbort%" == "True" (

	Set FirstErrorMessageLine=True

	For %%a in (
		!SettingsErrorList!
	) do (
		If "!FirstErrorMessageLine!" == "True" (
			echo %white%Info:%ef%		 %%~a
		) else (
			echo			 %%~a
		)
		Set FirstErrorMessageLine=False
	)
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
)

REM === BuldAbort True ===
If  "%BuildAbort%" == "True" (
echo %white%Settings:%ef%	 I: Ignore Errors ^& Continue
REM === BuldAbort False ===
) else (
echo %white%Settings:%ef%	 1: Include Microsoft Surface RT in All-in-one Output	      ^| !AIOInclude_SurfaceRTMenuModeText!
echo 		 2: Include Microsoft Surface 2 in All-in-one Output	      ^| !AIOInclude_Surface2MenuModeText!
echo 		 3: Include Lenovo IdeaPad Yoga 11 in All-in-one Output       ^| !AIOInclude_Yoga11MenuModeText!
echo 		 4: Include ASUS VivoTab RT in All-in-one Output	      ^| !AIOInclude_VivoTabMenuModeText!
echo 		 5: Include Dell XPS 10 in All-in-one Output		      ^| !AIOInclude_XPS10MenuModeText!
echo 		 6: Include Nokia Lumia 2520 in All-in-one Output	      ^| !AIOInclude_Lumia2520MenuModeText!
echo 		 7: Include Samsung Ativ Tab in All-in-one Output	      ^| !AIOInclude_ATIVTabMenuModeText!
echo 		 8: Include Generic/No Driver Image in All-in-one Output      ^| !AIOInclude_GenericMenuModeText!
rem echo 		 9: Include Custom Image in All-in-one Output		      ^| !AIOInclude_CustomMenuModeText!
echo.
echo 		 J: Enable Test Mode					      ^| !TestModeMenuModeText!
echo 		 K: Enable UMCI Audit Mode				      ^| !UMCIMenuModeText!
echo 		 L: Include 19041 ADK Tools				      ^| !ADKTools19041MenuModeText!
echo 		 M: Include WDD						      ^| !WDDMenuModeText!
echo 		 N: Apply Windows RT 8.1 Servicing Stack Updates	      ^| !Apply9600SSUMenuModeText!
echo 		 O: Use Windows RT 8.1 Boot Files for Windows 10 ^(USB Only^)   ^| !Force9600BootFiles15035MenuModeText!
echo 		 P: Include Separate Device Scripts			      ^| !AIOInclude_DeviceScriptsMenuModeText!
echo 		 Q: Include Boot Index Selection Script in All-in-one Output  ^| !AIOInclude_BootIndexSelectionScriptMenuModeText!

If exist "%CD%\Includes\Mod_WinToGoPE.cmd" (
echo 		 R: Offer Flat Boot/Non-RAM USB Output			      ^| !WinToGoMenuModeText!
)
If exist "%CD%\Addons\CustomPE\CustomPE.cmd" (
echo 		 S: Enable Custom Addon ^(\Addons\CustomPE\CustomPE.cmd^)       ^| !CustomAddonMenuModeText!
)
echo.
If exist "%CD%\Bin\DISM\%PROCESSOR_ARCHITECTURE%\dism.exe" (
echo 		 T: Bundled DISM					      ^| %BundledDISMMenuModeText%
)
echo 		 V: DISM Log Level					      ^| %green%!DISMLogLevel! !DISMLogText!%ef%
echo.
echo 		 U: Automatic Update Check ^(On Startup Only^)		      ^| !RunStartUpActionsMenuModeText!
REM === BuldAbort False ===
)

echo.
If "%BuildAbort%" == "True" (
	echo 		 E: %red%Exit Media Builder%ef%					      ^| D: Set Default Values
) else (
	echo 		 E: %red%Exit Settings%ef%					      ^| D: Set Default Values
)
echo.
Set ConfigOption=
Set /p ConfigOption=%white%Enter Selection: %ef%

REM === BuldAbort False ===
If not "%BuildAbort%" == "True" (
If /i "%ConfigOption%"=="1" goto ConfigAIOInclude_SurfaceRT
If /i "%ConfigOption%"=="2" goto ConfigAIOInclude_Surface2
If /i "%ConfigOption%"=="3" goto ConfigAIOInclude_Yoga11
If /i "%ConfigOption%"=="4" goto ConfigAIOInclude_VivoTab
If /i "%ConfigOption%"=="5" goto ConfigAIOInclude_XPS10
If /i "%ConfigOption%"=="6" goto ConfigAIOInclude_Lumia2520
If /i "%ConfigOption%"=="7" goto ConfigAIOInclude_ATIVTab
If /i "%ConfigOption%"=="8" goto ConfigAIOInclude_Generic
If /i "%ConfigOption%"=="69" goto ConfigAIOInclude_Custom

If /i "%ConfigOption%"=="J" goto ConfigTestMode
If /i "%ConfigOption%"=="K" goto ConfigUMCI
If /i "%ConfigOption%"=="L" goto ConfigADKTools19041
If /i "%ConfigOption%"=="M" goto ConfigWDD
If /i "%ConfigOption%"=="N" goto ConfigApply9600SSU
If /i "%ConfigOption%"=="O" goto ConfigForce9600BootFiles15035
If /i "%ConfigOption%"=="P" goto ConfigAIOInclude_DeviceScripts
If /i "%ConfigOption%"=="Q" goto ConfigAIOInclude_BootIndexSelectionScript

If exist "%CD%\Includes\Mod_WinToGoPE.cmd" (
  	If /i "%ConfigOption%"=="R" goto ConfigWinToGo
)

If exist "%CD%\Addons\CustomPE\CustomPE.cmd" (
	If /i "%ConfigOption%"=="S" goto ConfigCustomAddon
)

If exist "%CD%\Bin\DISM\%PROCESSOR_ARCHITECTURE%\dism.exe" (
	If /i "%ConfigOption%"=="T" goto ConfigDISM
)
If /i "%ConfigOption%"=="V" goto ConfigDISMLog

If /i "%ConfigOption%"=="D" goto ConfigDefault
REM === BuldAbort False ===
)

If /i "%ConfigOption%"=="E" (
	If "%BuildAbort%" == "True" Set BuildRestart=False
	goto Build_Settings_Complete
)

If "%BuildAbort%" == "True" If /i "%ConfigOption%"=="I" (
	Set IgnoreErrors=True
	goto Build_Settings_Complete
)

If /i "%ConfigOption%"=="U" goto ConfigRunStartUpActions

If "%ConfigOption%"=="CC" goto ConfigUseCMDColours
If "%ConfigOption%"=="TV" goto ConfigUseTestVersion
If "%ConfigOption%"=="IL" goto ConfigMBInfoLink

goto Build_Settings_Start


:ConfigUseCMDColours
Set Toggle=UseCMDColours
Set ExitSettings=True
goto ToggleSwitch

:ConfigRunStartUpActions
Set Toggle=RunStartUpActions
goto ToggleSwitch

:ConfigUseTestVersion
Set Toggle=UseTestVersion
goto ToggleSwitch

:ConfigMBInfoLink
Set Toggle=MBInfoLink
goto ToggleSwitch

:ConfigDISM
Set Toggle=BundledDISM
goto ToggleSwitch

:ConfigBootWinREWIM
Set Toggle=ExportBootWinREWIM
goto ToggleSwitch

:ConfigWinToGo
Set Toggle=WinToGo
goto ToggleSwitch

:ConfigCustomAddon
Set Toggle=CustomAddon
goto ToggleSwitch

:ConfigADKTools19041
Set Toggle=ADKTools19041
goto ToggleSwitch

:ConfigWDD
Set Toggle=WDD
goto ToggleSwitch

:ConfigUMCI
Set Toggle=UMCI
goto ToggleSwitch

:ConfigTestMode
Set Toggle=TestMode
goto ToggleSwitch

:ConfigApply9600SSU
Set Toggle=Apply9600SSU
goto ToggleSwitch

:ConfigForce9600BootFiles15035
Set Toggle=Force9600BootFiles15035
goto ToggleSwitch

:ConfigAIOInclude_DeviceScripts
Set Toggle=AIOInclude_DeviceScripts
goto ToggleSwitch

:ConfigAIOInclude_BootIndexSelectionScript
Set Toggle=AIOInclude_BootIndexSelectionScript
goto ToggleSwitch

:ConfigAIOInclude_SurfaceRT
Set Toggle=AIOInclude_SurfaceRT
goto ToggleSwitch

:ConfigAIOInclude_Surface2
Set Toggle=AIOInclude_Surface2
goto ToggleSwitch

:ConfigAIOInclude_Yoga11
Set Toggle=AIOInclude_Yoga11
goto ToggleSwitch

:ConfigAIOInclude_VivoTab
Set Toggle=AIOInclude_VivoTab
goto ToggleSwitch

:ConfigAIOInclude_XPS10
Set Toggle=AIOInclude_XPS10
goto ToggleSwitch

:ConfigAIOInclude_Lumia2520
Set Toggle=AIOInclude_Lumia2520
goto ToggleSwitch

:ConfigAIOInclude_ATIVTab
Set Toggle=AIOInclude_ATIVTab
goto ToggleSwitch

:ConfigAIOInclude_Generic
Set Toggle=AIOInclude_Generic
goto ToggleSwitch

:ConfigAIOInclude_Custom
Set Toggle=AIOInclude_Custom
goto ToggleSwitch

:ToggleSwitch
If "!%Toggle%!" == "True" (
	Set %Toggle%=False
) else (
	Set %Toggle%=True
)

Call "%CD%\Includes\Build_ConfigPE.cmd" BuildSaveCurrentConfig
If "%ExitSettings%" == "True" goto Build_Settings_Complete

goto Build_Settings_Start


:ConfigDISMLog
Set /a DISMLogLevel+=1
If !DISMLogLevel! GTR 4 Set /a DISMLogLevel=1
Call "%CD%\Includes\Build_ConfigPE.cmd" BuildSaveCurrentConfig	

goto Build_Settings_Start


:ConfigDefault
Set PathChange=True
Call "%CD%\Includes\Build_ConfigPE.cmd" BuildSetDefault
If "!ErrorLevel!" EQU "0" (
	echo %green%Default settings restored.%ef%
) else (
	echo %red%Error: Unable to restore default settings.%ef%
)

pause
goto Build_Settings_Start

REM ====== End =========================================================================================================================================================

:Build_Settings_Complete

If "%SettingsStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "SettingsStage="