@echo off

REM ====== Set =========================================================================================================================================================

Set ConfigStage=%1

If "%ConfigStage%" == "" (
	goto BuildConfigComplete
) else (

	If not exist "!CD!\Config" md "!CD!\Config" 1> nul
	Set MBConfig=!CD!\Config\Build_Config.cfg

	If exist "!MBConfig!" (
		Attrib -r -s -h "!MBConfig!" 1> nul
	)

	goto %ConfigStage%
)

:BuildConfig

REM ====== Build_Config.cfg Default Values (Do not edit) ===============================================================================================================

REM The values below are defaults if no Build_Config.cfg is found.


Set DownloadsFolderName=Resources
Set DownloadsSpaceReq=1
Set OutputFolderName=CustomPE_Media
Set OutputFolderSpaceReq=1
Set TmpFolderName=Tmp
Set TmpFolderSpaceReq=2
Set TmpFolderPathLen=64

Set SysDriveSpaceReq=1

Set DownloadsPath=%CD%\%DownloadsFolderName%
Set OutputPath=%CD%\%OutputFolderName%
Set TmpPath=%CD%\%TmpFolderName%
Set BundledDISM=False
Set SkipOSCheck=False
Set MediaLabel=WinPE
Set USBInstallMediaFixedOnly=False
Set ExportBootWinREWIM=True
Set SkipServiceChecks=False
Set SkipDriveSpaceCheck=False
Set SkipDriveFileSystemCheck=False
Set WinToGo=False
Set WinToGoDriveFixedOnly=False
Set ShowUSBCopyProgress=True
Set FileSource=A
Set DISMLogLevel=2
Set DISMLogPath=%CD%\DISM_Logs
Set DISMLogFile=Log-DISM
Set DISMLogFileExt=txt
Set CustomAddon=False
Set UseCMDColours=True
Set MBInfoLink=True
Set RunStartUpActions=True
Set UseTestVersion=False

Set AIOBootIndexSelectionScriptName=Boot_Device_Selection.cmd

Set ADKTools19041=False
Set WDD=False
Set UMCI=False
Set TestMode=False
Set Apply9600SSU=False
Set Force9600BootFiles15035=False

Set AIOInclude_SurfaceRT=True
Set AIOInclude_Surface2=True
Set AIOInclude_Yoga11=True
Set AIOInclude_VivoTab=True
Set AIOInclude_XPS10=True
Set AIOInclude_Lumia2520=True
Set AIOInclude_ATIVTab=True
Set AIOInclude_Generic=False
Set AIOInclude_Custom=False

Set AIOInclude_DeviceScripts=False
Set AIOInclude_BootIndexSelectionScript=True

Set MediaBuilderInfoURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/mediabuilder
Set WindowsListsURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/CustomPE_2023/CustomPE

REM ====== Write Build_Config.cfg if not found using the default values or read values from Build_Config.cfg if it is found ============================================

If not exist "%MBConfig%" (

	setlocal DisableDelayedExpansion
	(
		echo ###### Created by %~nx0 ######
		echo BundledDISM=%BundledDISM%
		echo SkipOSCheck=%SkipOSCheck%
		echo USBInstallMediaFixedOnly=%USBInstallMediaFixedOnly%
		echo ExportBootWinREWIM=%ExportBootWinREWIM%
		echo SkipServiceChecks=%SkipServiceChecks%
		echo SkipDriveSpaceCheck=%SkipDriveSpaceCheck%
		echo SkipDriveFileSystemCheck=%SkipDriveFileSystemCheck%
		echo WinToGo=%WinToGo%
		echo WinToGoDriveFixedOnly=%WinToGoDriveFixedOnly%
		echo ShowUSBCopyProgress=%ShowUSBCopyProgress%
		echo DISMLogLevel=%DISMLogLevel%
		echo CustomAddon=%CustomAddon%
		echo UseCMDColours=%UseCMDColours%
		echo ADKTools19041=%ADKTools19041%
		echo WDD=%WDD%
		echo UMCI=%UMCI%
		echo TestMode=%TestMode%
		echo Apply9600SSU=%Apply9600SSU%
		echo Force9600BootFiles15035=%Force9600BootFiles15035%
		echo AIOInclude_SurfaceRT=%AIOInclude_SurfaceRT%
		echo AIOInclude_Surface2=%AIOInclude_Surface2%
		echo AIOInclude_Yoga11=%AIOInclude_Yoga11%
		echo AIOInclude_VivoTab=%AIOInclude_VivoTab%
		echo AIOInclude_XPS10=%AIOInclude_XPS10%
		echo AIOInclude_Lumia2520=%AIOInclude_Lumia2520%
		echo AIOInclude_ATIVTab=%AIOInclude_ATIVTab%
		echo AIOInclude_Generic=%AIOInclude_Generic%
		echo AIOInclude_Custom=%AIOInclude_Custom%
		echo AIOInclude_DeviceScripts=%AIOInclude_DeviceScripts%
		echo AIOInclude_BootIndexSelectionScript=%AIOInclude_BootIndexSelectionScript%
		echo MBInfoLink=%MBInfoLink%
		echo RunStartUpActions=%RunStartUpActions%
		echo UseTestVersion=%UseTestVersion%
	) > "%MBConfig%"
	setlocal EnableDelayedExpansion

) else (

	For /f "usebackq skip=1 tokens=*" %%a in ("%MBConfig%") do (
		For /f "tokens=1* delims==" %%a in ("%%a") do (
			If not "%%b" == "" Set "%%a=%%b"
		)
	)

)

goto BuildConfigComplete

REM ====== Save Build_Config.cfg with current values ===================================================================================================================

:BuildSaveCurrentConfig

(
	echo ###### Created by %~nx0 ######
	echo BundledDISM=!BundledDISM!
	echo SkipOSCheck=!SkipOSCheck!
	echo USBInstallMediaFixedOnly=!USBInstallMediaFixedOnly!
	echo ExportBootWinREWIM=!ExportBootWinREWIM!
	echo SkipServiceChecks=!SkipServiceChecks!
	echo SkipDriveSpaceCheck=!SkipDriveSpaceCheck!
	echo SkipDriveFileSystemCheck=!SkipDriveFileSystemCheck!
	echo WinToGo=!WinToGo!
	echo WinToGoDriveFixedOnly=!WinToGoDriveFixedOnly!
	echo ShowUSBCopyProgress=!ShowUSBCopyProgress!
	echo DISMLogLevel=!DISMLogLevel!
	echo CustomAddon=!CustomAddon!
	echo UseCMDColours=!UseCMDColours!
	echo ADKTools19041=!ADKTools19041!
	echo WDD=!WDD!
	echo UMCI=!UMCI!
	echo TestMode=!TestMode!
	echo Apply9600SSU=!Apply9600SSU!
	echo Force9600BootFiles15035=!Force9600BootFiles15035!
	echo AIOInclude_SurfaceRT=!AIOInclude_SurfaceRT!
	echo AIOInclude_Surface2=!AIOInclude_Surface2!
	echo AIOInclude_Yoga11=!AIOInclude_Yoga11!
	echo AIOInclude_VivoTab=!AIOInclude_VivoTab!
	echo AIOInclude_XPS10=!AIOInclude_XPS10!
	echo AIOInclude_Lumia2520=!AIOInclude_Lumia2520!
	echo AIOInclude_ATIVTab=!AIOInclude_ATIVTab!
	echo AIOInclude_Generic=!AIOInclude_Generic!
	echo AIOInclude_Custom=!AIOInclude_Custom!
	echo AIOInclude_DeviceScripts=!AIOInclude_DeviceScripts!
	echo AIOInclude_BootIndexSelectionScript=!AIOInclude_BootIndexSelectionScript!
	echo MBInfoLink=!MBInfoLink!
	echo RunStartUpActions=!RunStartUpActions!
	echo UseTestVersion=!UseTestVersion!
) > "%MBConfig%"

goto BuildConfigComplete

REM ====== Set default Build_Config.cfg values =========================================================================================================================

:BuildSetDefault

If exist "%MBConfig%" (
	Del "%MBConfig%" /F /Q 1> nul
)

goto BuildConfig

REM ====== End =========================================================================================================================================================

:BuildConfigComplete

If "%ConfigStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "ConfigStage="