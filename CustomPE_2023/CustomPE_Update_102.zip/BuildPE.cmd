@echo off
@setlocal enableextensions
@setlocal EnableDelayedExpansion
@cd /d "%~dp0"
cls

Set /a MBVerNumber=102

Set MBName=CustomPE Media Builder
Set MBName2=!MBName!
Set MBVer=v%MBVerNumber:~0,1%.%MBVerNumber:~1,2%
Set MBDate=04-07-2024
@Title %MBName2% - %MBVer%

REM	jwa4

REM ====== Network Drive/Share Check ===================================================================================================================================

If "%~d0" == "\\" (
	Set BuildAbort=True
)

"%SystemRoot%\System32\net.exe" use > NUL 2>&1
If "!ErrorLevel!" EQU "2" goto SkipMappedDriveCheck

"%SystemRoot%\System32\net.exe" use | "%SystemRoot%\System32\findstr.exe" /I /L /C:" %~d0 " >nul
If not "!ErrorLevel!" EQU "1" (
	Set BuildAbort=True
)

:SkipMappedDriveCheck

If "%BuildAbort%" == "True" (
	echo Error: Media Builder cannot be run from a mapped drive or network share.
	goto ExitNoTempClear
)

@cd /d "%~dp0"

REM ====== Check only one instance is running ==========================================================================================================================

9>&2 2>nul (Call :LockAndRestoreStdErr %* 8>>"%~f0") || (
	echo %red%Error: Only one instance allowed. >&2%ef%
)
goto ExitNoTempClear

:LockAndRestoreStdErr
Call :SingleInstance %* 2>&9
exit /b 0

:SingleInstance

9>&2 2>nul (call :LockAndRestoreStdErr1 %* 8>>"!CD!\CleanupPE.cmd") || (
	echo %red%Error: Only one instance allowed. >&2%ef%
)
goto ExitNoTempClear

:LockAndRestoreStdErr1
call :SingleInstance1 %* 2>&9
exit /b 0

:SingleInstance1

REM ====== Checks ======================================================================================================================================================

Set MBFirstRun=True

:Start
setlocal

If /i "!MBFirstRun!" == "True" (
	endlocal & Set MBFirstRun=False
	setlocal & Set MBFirstRunInt=True
)

If exist "%CD%\Includes\Build_CommonPE.cmd" (
	echo Please Wait...
	Call "%CD%\Includes\Build_CommonPE.cmd" BuildCommon %~nx0
) else (
	echo %red%Error: File Missing...%ef%
	echo "!CD!\Includes\Build_CommonPE.cmd"
	Set BuildAbort=True
)

If "%BuildRestart%"=="True" (
	cls
	endlocal
	goto Start
)

If "%BuildAbort%"=="True" goto ExitNoTempClear

REM ====== Main Menu ===================================================================================================================================================

:MainMenu
cls

If /i not "!DisableMediaBuilderUpdates!" == "True" (
	Set MBUpdateMenuText=B: Update Media Builder
) else (
	Set MBUpdateMenuText=
)

echo %white%%ul%_________________________________________%ef%
echo.
echo %white%%MBName2% !MBVer! - !MBDate!%ef%
echo %white%%ul%_________________________________________%ef%
echo.
echo 7-Zip - Copyright (C) 1999-2019, Igor Pavlov.
echo QEMU - Copyright (C) 2003-2021 Fabrice Bellard and the QEMU Project developers. (Thanks to @x86corez ^& @driver1998)
echo SetACL - Copyright (C) 2012, Helge Klein.
echo dd for Windows (C) 2018, Sergey Zolotarev. (Thanks to @jeybee)
echo.
echo This media builder will create a bootable USB for the selected device(s) using a winre.wim from Windows RT 8.1 IR5 or
echo Windows 10 Build 15035 which will be modified to launch a command prompt by default.
echo.
echo %red%The use of this media builder or the media it produces is entirely at your own risk.%ef%
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Options:%ef%	 W: Write Existing Media		!MBUpdateMenuText!
echo 		 S: Media Builder Settings
echo.
echo %white%Select Device:%ef%	 1: Microsoft Surface RT		5: Dell XPS 10
echo			 2: Microsoft Surface 2			6: Nokia Lumia 2520
echo			 3: Lenovo IdeaPad Yoga 11		7: Samsung Ativ Tab
echo			 4: ASUS VivoTab RT			8: None (No Drivers)
echo.
echo			 A: All-in-one				Q: QEMU %red%^(Flat Boot ^& Windows 10 Build 15035 Only^)%ef%
echo.
echo			 E: %red%Exit%ef%				!%MBMessageColour%!%MBMessage%%ef%
echo.
Set /p Target=%white%Enter Selection: %ef%

:SkipTarget

If "%Target%"=="1" goto SurfaceRT
If "%Target%"=="2" goto Surface2
If "%Target%"=="3" goto Yoga11
If "%Target%"=="4" goto VivoTab
If "%Target%"=="5" goto XPS10
If "%Target%"=="6" goto Lumia2520
If "%Target%"=="7" goto ATIVTab
If "%Target%"=="8" goto Generic
If "%Target%"=="69" goto Custom
If /i "%Target%"=="A" goto AIO
If /i "%Target%"=="Q" goto QEMU

If exist "%CD%\Includes\Mod_MediaPE.cmd" If exist "%CD%\Includes\Mod_Media_RewritePE.cmd" If /i "%Target%"=="W" (
	Call "%CD%\Includes\Mod_Media_RewritePE.cmd" Windows_Media_Select_Start
	If /i "!Windows_Media_Selection!" == "C" (
		cls
		endlocal & Set SkipDriveCheckInt=True
		goto Start
	)
	goto ReturnMainMenu
)

If exist "%CD%\Includes\Build_SettingsPE.cmd" If /i "%Target%"=="S" (
	Set PathChange=False
	Call "%CD%\Includes\Build_SettingsPE.cmd" Build_Settings_Start
	cls
	If "!PathChange!" == "True" endlocal & Set SkipDriveCheckInt=False
	If "!PathChange!" == "False" endlocal & Set SkipDriveCheckInt=True
	goto Start
)

If /i not "!DisableMediaBuilderUpdates!" == "True" If /i "%Target%"=="B" (
	Call "%CD%\Includes\Build_CommonPE.cmd" ForceUpdateCheck %~nx0 True
	cls
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

If /i "%Target%"=="E" goto Exit

goto MainMenu

:SurfaceRT
Set SoC=Nvidia
Set Devices=!Devices!;"1#SurfaceRT#%SoC%"
goto Continue

:Surface2
Set SoC=Nvidia
Set Devices=!Devices!;"2#Surface2#%SoC%"
goto Continue

:Yoga11
Set SoC=Nvidia
Set Devices=!Devices!;"3#Yoga11#%SoC%"
goto Continue

:VivoTab
Set SoC=Nvidia
Set Devices=!Devices!;"4#VivoTabRT#%SoC%"
goto Continue

:XPS10
Set SoC=Qualcomm
Set Devices=!Devices!;"5#XPS10#%SoC%"
goto Continue

:Lumia2520
Set SoC=Qualcomm
Set Devices=!Devices!;"6#Lumia2520#%SoC%"
goto Continue

:ATIVTab
Set SoC=Qualcomm
Set Devices=!Devices!;"7#ATIVTab#%SoC%"
goto Continue

:Generic
Set SoC=None
Set Devices=!Devices!;"8#Generic#%SoC%"
goto Continue

:Custom
Set SoC=Custom
Set Devices=!Devices!;"69#Custom#%SoC%"
goto Continue

:QEMU
Set SoC=Emulated
Set Devices=!Devices!;"100#QEMU#%SoC%"
Set WindowsVersionPrompt=2
Goto SkipWindowsVersionPrompt
goto Continue

:AIO
Set WinreAIO=True
If /i "%AIOInclude_SurfaceRT%" == "True" Set Devices=!Devices!;"1#SurfaceRT#Nvidia"
If /i "%AIOInclude_Surface2%" == "True" Set Devices=!Devices!;"2#Surface2#Nvidia"
If /i "%AIOInclude_Yoga11%" == "True" Set Devices=!Devices!;"3#Yoga11#Nvidia"
If /i "%AIOInclude_VivoTab%" == "True" Set Devices=!Devices!;"4#VivoTabRT#Nvidia"
If /i "%AIOInclude_XPS10%" == "True" Set Devices=!Devices!;"5#XPS10#Qualcomm"
If /i "%AIOInclude_Lumia2520%" == "True" Set Devices=!Devices!;"6#Lumia2520#Qualcomm"
If /i "%AIOInclude_ATIVTab%" == "True" Set Devices=!Devices!;"7#ATIVTab#Qualcomm"
If /i "%AIOInclude_Generic%" == "True" Set Devices=!Devices!;"8#Generic#None"
If /i "%AIOInclude_Custom%" == "True" Set Devices=!Devices!;"69#Custom#Custom"
If "%Devices%" == "" (
	echo.
	echo Error: All devices have been excluded from the All-in-one option.
	echo.
	pause
	endlocal
	goto Start
)
goto Continue

:Continue

:WindowsVersionSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set WindowsVersionPrompt=
echo Select which version of Windows you would like to use:
echo.
echo Select Version:	 1: Windows RT 8.1 IR5 ^(9600^)
echo 		 2: Windows 10 ^(15035^)
echo.
echo			 C: %red%Cancel%ef%
echo.
Set /p WindowsVersionPrompt=%white%Enter Selection: %ef%
:SkipWindowsVersionPrompt

If /i "%WindowsVersionPrompt%"=="1" (
	Set CustomPEVer=9600
	goto WindowsVersionSelected
)
If /i "%WindowsVersionPrompt%"=="2" (
	Set CustomPEVer=15035
	goto WindowsVersionSelected
)
If /i "%WindowsVersionPrompt%"=="69" (
	Set CustomPEVer=Custom
	goto WindowsVersionSelected
)
If /i "%WindowsVersionPrompt%"=="C" (
	cls
	endlocal
	goto Start
rem	goto MainMenu
)
goto WindowsVersionSelect

:WindowsVersionSelected

If "%CustomPEVer%" == "Custom" (
	Set FolderNameInsert=Custom
	Set WinreWIM=%DownloadsPath%\Windows_Custom\Windows_Custom_Winre.wim
	Set WinreBootFiles=%DownloadsPath%\Windows_Custom\Windows_Custom_USB_Boot_Files.zip
	Set MediaLabel=WinPE_Cust
)

If "%CustomPEVer%" == "9600" (
	Set FolderNameInsert=8.1_IR5
	Set WinreWIM=%DownloadsPath%\Windows_RT_8.1_IR5\Windows_RT_8.1_IR5_Winre.wim
	Set WinreBootFiles=%DownloadsPath%\Windows_RT_8.1_IR5\Windows_RT_8.1_IR5_USB_Boot_Files.zip
	Set MediaLabel=WinPE_9600
)

If "%CustomPEVer%" == "15035" (
	Set FolderNameInsert=10_Build_15035
	Set WinreWIM=%DownloadsPath%\Windows_10_Build_15035\Windows_10_Build_15035_Winre.wim
	If /i "%Force9600BootFiles15035%" == "True" (
		Set WinreBootFiles=%DownloadsPath%\Windows_RT_8.1_IR5\Windows_RT_8.1_IR5_USB_Boot_Files.zip
	) else (
		Set WinreBootFiles=%DownloadsPath%\Windows_10_Build_15035\Windows_10_Build_15035_USB_Boot_Files.zip
	)
	Set MediaLabel=WinPE_15035
)

For %%d in (
	"%WinreWIM%"
	"%WinreBootFiles%"
) do (
	If not exist %%d goto ExitNoTempClear
)

REM ====== Custom ======================================================================================================================================================

If "%CustomAddon%" == "True" If exist "%CD%\Addons\CustomPE\CustomPE.cmd" (
	Call "%CD%\Addons\CustomPE\CustomPE.cmd" CustomMenu
) else (
	Set BuildCustom=False
)

REM ====== Archive =====================================================================================================================================================

:MakePEArcSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set MakePEArcPrompt=
Set /p MakePEArcPrompt=Would you like to create a ZIP file containing the Windows PE files? (Y/N)? 
If /i "%MakePEArcPrompt%"=="Y" Set MakePEArc=True
If /i "%MakePEArcPrompt%"=="N" Set MakePEArc=False
If "%MakePEArc%" == "" goto MakePEArcSelect

REM ====== Confirm =====================================================================================================================================================

:ConfirmSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
If /i not "%WinreAIO%" == "True" If /i "%SoC%" == "Qualcomm" If "%CustomPEVer%" == "15035" (
	cls
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %warn% WARNING                             WARNING                                WARNING                             WARNING %ef%
	echo.
	echo 	%white%%ul%Device Notes%ef%%white%
	echo.
	echo 	Media Builder cannot currently produce working output for Qualcomm devices.
	echo.
	echo %warn% WARNING                             WARNING                                WARNING                             WARNING %ef%
	echo.
)
Set ConfirmPrompt=
Set /p ConfirmPrompt=Would you like to start the build process? (Y/N)? 
If /i "%ConfirmPrompt%"=="Y" goto Confirmed
If /i "%ConfirmPrompt%"=="N" (
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

goto ConfirmSelect

:Confirmed

REM ====== Timer =======================================================================================================================================================

Set "startTime=%time: =0%"

REM ====== Make sure Tmp folder empty ==================================================================================================================================

Set Retry=0

:RetryTempClear

If exist "%TmpPath%\" If "%Retry%" == "1" (
	echo.
	echo %red%Error: Unable to clear "%TmpPath%" folder, please reboot and try again.%ef%
	goto ExitNoTempClear
)

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo Clearing Temporary Files.
	echo Please wait.
	echo.
	If exist "%TmpPath%\Mount\winre\" start /b /wait "" "%DISMEXE%" /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre" /discard >NUL
	echo Please wait...

	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1

	If not exist "%TmpPath%\" (
		echo.
		echo %green%"%TmpPath%" Cleared.%ef%
	) else (
		Set Retry=1
		goto RetryTempClear
	)
)

REM ====== Create folders ==============================================================================================================================================

For %%d in (
	"%TmpPath%\ScratchDir"
	"%TmpPath%\Source\"
	"%TmpPath%\Mount\winre\"
	"%TmpPath%\Updated\winre\"
) do (
	If not exist %%d md %%d 1> nul
)

REM ====== Winre.wim ===================================================================================================================================================

For %%z in (
	!Devices!
) do (
	For /f "tokens=1-3 delims=#" %%q in (%%z) do (
		Set /a RunCount+=1
		echo ________________________________________________________________________________________________________________________
		echo.
		echo Winre.wim - ^(%%r^)
		echo.
		Set DeviceIndex=%%q
		Set Device=%%r
		Set SoC=%%s
		Set Name=None

		If not "!SoC!" == "None" (
			Call "%CD%\Devices\!SoC!\!Device!\!Device!.cmd" DeviceInfo
		)

		attrib -s -h -r /s /d "%WinreWIM%"
		Copy "%WinreWIM%" "%TmpPath%\Source\winre.wim"

		Start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Mount-Wim /WimFile:"%TmpPath%\Source\winre.wim" /index:1 /MountDir:"%TmpPath%\Mount\winre"

		If "%CustomPEVer%" == "9600" If /i "%Apply9600SSU%" == "True" (
			For  %%i in ("%DownloadsPath%\Windows_RT_8.1_IR5\Windows_RT_8.1_IR5_Servicing_Stack\*") do (
				Start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\winre" /Add-Package:"%%i"
				Start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Commit-Image /MountDir:"%TmpPath%\Mount\winre"
			)
		)

		If not "!Device!" == "Generic" (
			If exist "%CD%\Devices\!SoC!\!Device!\!Device!.cmd" Call "%CD%\Devices\!SoC!\!Device!\!Device!.cmd" winre
			If "%CustomPEVer%" == "15035" If exist "%CD%\Devices\!SoC!\!Device!\Boot_WinRe_10" (
				start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\winre" /Add-Driver /Driver:"%CD%\Devices\!SoC!\!Device!\Boot_WinRe"_10 /Recurse
			)
		)

		If "%CustomPEVer%" == "15035" If /i "!SoC!" == "Nvidia" If Exist "%CD%\Devices\!SoC!\Common_10\SD_Drivers_Boot_WinRe.cmd" (
			Set DeviceStage=winre
			Call "%CD%\Devices\!SoC!\Common_10\SD_Drivers_Boot_WinRe.cmd" SDFixPE
		)

		If Exist "%TmpPath%\Mount\winre\RunCustomInt.cmd" Del "%TmpPath%\Mount\winre\RunCustomInt.cmd" /F /Q 1> nul
		(
			echo @echo off
			echo @setlocal enableextensions
			echo @setlocal EnableDelayedExpansion
			echo @cd /d "%%~dp0"
			echo.
			echo REM	jwa4
			echo.
			echo Set Device=!Device!
			echo Set Name=!Name!
			echo Set SoC=!SoC!
			echo.
			echo Start /b "" "X:\Program Files\Common Files\Microsoft Shared\ink\TabTip.exe" /WinRE
			echo.
			echo Wpeutil.exe UpdateBootInfo
			echo For /f "tokens=2,*" %%%%a in ^('reg query HKLM\SYSTEM\CurrentControlSet\Control /v PEBootRamDiskSourceDrive 2^^^> nul ^^^| find /i "PEBootRamDiskSourceDrive"'^) do Set ScriptSourceDrive=%%%%~db
			echo If "^!ScriptSourceDrive^!" == "" ^(
			echo 	For /f "delims=\ " %%%%a IN ^('mountvol.exe^^^|find.exe ":\"'^) do ^(
			echo 		If exist "%%%%a\CustomPE\CustomPE.cmd" set ScriptSourceDrive=%%%%a
			echo 	^)
			echo ^)
			echo.
			echo If Exist "^!ScriptSourceDrive^!\CustomPE\CustomPE.cmd" ^(
			echo 	Call "^!ScriptSourceDrive^!\CustomPE\CustomPE.cmd"
			echo ^) else ^(
			echo 	echo Error: "^!ScriptSourceDrive^!\CustomPE\CustomPE.cmd" not found.
			echo 	cmd.exe
			echo ^)
			echo.
			echo echo.
			echo echo Goodbye^!
			echo pause
			echo exit
		) > "%TmpPath%\Mount\winre\Windows\System32\StartCustomPE.cmd"

		If Exist "%TmpPath%\Mount\winre\Windows\System32\winpeshl.ini" Del "%TmpPath%\Mount\winre\Windows\System32\winpeshl.ini" /F /Q 1> nul
		(
			echo [LaunchApp]
			echo AppPath=X:\Windows\System32\StartCustomPE.cmd
		) > "%TmpPath%\Mount\winre\Windows\System32\winpeshl.ini"

		If /i "%UMCI%" == "True" (
			"%systemroot%\System32\reg.exe" load HKLM\RT_SYSTEM "%TmpPath%\Mount\winre\Windows\System32\Config\SYSTEM" 1> nul
			"%systemroot%\System32\reg.exe" add "HKLM\RT_SYSTEM\ControlSet001\Control\CI" /v "UMCIAuditMode" /t REG_DWORD /d 1 /f
			"%systemroot%\System32\reg.exe" unload HKLM\RT_SYSTEM 1> nul
		)

		If "%BuildCustom%" == "True" (
			Call "%CD%\Addons\CustomPE\CustomPE.cmd" winre
		)

		Start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre" /Commit
		Start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\winre.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\winre\winre.wim" /DestinationName:"!Name!" /Compress:max

		Del "%TmpPath%\Source\winre.wim" /F /Q 1> nul

	)
)

REM ====== Set output folder and filename ==============================================================================================================================

For /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set DTS=%%a
Set Date1=%DTS:~6,2%-%DTS:~4,2%-%DTS:~0,4%
Set Time1=%DTS:~8,2%-%DTS:~10,2%-%DTS:~12,2%

If /i "%WinreAIO%" == "True" Set Device=AIO

Set MediaFolder=CustomPE_Media
Set MediaFolderName=CustomPE_%FolderNameInsert%_%Device%_%Date1%_%Time1%
Set MediaFolderPath=%TmpPath%\%MediaFolder%\%MediaFolderName%

If not exist "%MediaFolderPath%" Md "%MediaFolderPath%" 1> nul

REM ====== Output ======================================================================================================================================================

If not exist "%MediaFolderPath%\CustomPE" md "%MediaFolderPath%\CustomPE" 1> nul

"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%WinreBootFiles%" -o"%MediaFolderPath%"
If /i "%WinreAIO%" == "True" If /i "%AIOInclude_BootIndexSelectionScript%" == "True" "%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%DownloadsPath%\ImageX.zip" -o"%MediaFolderPath%\sources\Bin\ImageX"
If /i "%WDD%" == "True" "%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%DownloadsPath%\wdd_ARM.zip" -o"%MediaFolderPath%\CustomPE\Bin\wdd"
If /i "%ADKTools19041%" == "True" "%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%DownloadsPath%\Windows_ADK_Tools_19041_ARM.zip" -o"%MediaFolderPath%\CustomPE\Bin\Windows_ADK_Tools"

If /i "%WinreAIO%" == "True" If /i "%AIOInclude_BootIndexSelectionScript%" == "True" (
	echo @echo off
	echo @setlocal enableextensions
	echo @setlocal EnableDelayedExpansion
	echo @cd /d "%%~dp0"
	echo.
	echo REM	jwa4
	echo.
	echo If "%%Target%%" == "" ^(
	echo 	Set Title=%%~n0
	echo 	Set Title=^^!Title:_= ^^!
	echo @title ^^!Title^^!
	echo ^)
	echo.
	echo If "%%Target%%" == "" ^(
	echo 	Set ImageXEXE=%%CD%%\sources\Bin\ImageX\%%PROCESSOR_ARCHITECTURE%%\imagex.exe
	echo 	Set BootWIM=%%CD%%\sources\boot.wim
	echo ^) else ^(
	echo 	Set ImageXEXE=%%CD%%\sources\Bin\ImageX\%%PROCESSOR_ARCHITECTURE%%\imagex.exe
	echo 	Set BootWIM=%%CD%%\sources\boot.wim
	echo ^)
	echo.
	echo REM ====== Checks ======================================================================================================================================================
	echo.
	echo For %%%%a in ^(
	echo 	"%%BootWIM%%"
	echo 	"%%ImageXEXE%%"
	echo ^) do ^(
	echo 	If not exist %%%%a ^(
	echo 		echo Error: File Missing...
	echo 		echo %%%%a
	echo 		Pause ^& goto WIMBootTargetSelected
	echo 	^)
	echo ^)
	echo.
	echo attrib -s -h -r /s /d "^!BootWIM^!" ^>nul 2^>^&1
	echo "^!ImageXEXE^!" /info "^!BootWIM^!" ^>nul 2^>^&1
	echo If ^^!ErrorLevel^^! NEQ 0 ^(
	echo 	echo ImageX Error: ^^!ErrorLevel^^!
	echo 	Pause ^& goto WIMBootTargetSelected
	echo ^)
	echo.
	echo REM ====== Menu ========================================================================================================================================================
	echo.
	echo :WIMBootTarget
	echo cls
rem	echo If "%%Target%%" == "" cls
	echo Set WIMBootTarget=
	echo Set WIMBootSelection=
	echo Set WIMBootList=
	echo Set WimBootListIndex=
	echo.
	echo For /f "usebackq tokens=3* delims=: " %%%%a in ^(`""^^!ImageXEXE^^!" /info "^^!BootWIM^^!" ^^^| "%%SystemRoot%%\System32\find.exe" "Boot Index:""`^) do ^(
	echo 	Set /a WIMBootSelection=%%%%a
	echo ^)
	echo.
	echo For /f "usebackq tokens=3* delims=<>" %%%%a in ^(`""^^!ImageXEXE^^!" /info "^^!BootWIM^^!" ^^^| "%%SystemRoot%%\System32\find.exe" "^^^^^<NAME^^^^^>""`^) do ^(
	echo 	Set /a WimBootListIndex+=1
	echo 	Set WIMBootList=^^!WIMBootList^^!;"^!WimBootListIndex^!#%%%%a"
	echo ^)
	echo.
	echo If "%%Target%%" == "" ^(
	echo 	echo Select the required device from the list below:
	echo ^) else ^(
	echo 	echo %%ul%%________________________________________________________________________________________________________________________%%ef%%
	echo 	echo.
	echo 	echo Select the default boot index from the list below:
	echo ^)
	echo echo.
	echo For %%%%z in ^(
	echo 	^^!WIMBootList^^!
	echo ^) do ^(
	echo 	For /f "tokens=1-2 delims=#" %%%%a in ^(%%%%z^) do ^(
	echo 		If %%%%a EQU 1 ^(
	echo 			If ^^!WIMBootSelection^^! EQU %%%%a ^(
	echo 				echo Select Index:	 %%%%a: %%%%b ^^^(Current Selection^^^)
	echo 			^) else ^(
	echo 				echo Select Index:	 %%%%a: %%%%b
	echo 			^)
	echo 		^) else ^(
	echo 			If ^^!WIMBootSelection^^! EQU %%%%a ^(
	echo 				echo			 %%%%a: %%%%b ^^^(Current Selection^^^)
	echo 			^) else ^(
	echo 				echo			 %%%%a: %%%%b
	echo 			^)
	echo 		^)
	echo 		If %%%%a EQU ^^!WimBootListIndex^^! ^(
	echo 			If "%%Target%%" == "" ^(
	echo 				echo.
	echo 				echo			 E: Exit
	echo 			^) else ^(
	echo 				echo.
	echo 				echo			 C: Confirm Selection ^^^& Continue
	echo 			^)
	echo.
	echo 		^)
	echo 	^)
	echo ^)
	echo echo.
	echo Set /p WIMBootTarget=Enter Selection: 
	echo.
	echo For %%%%z in ^(
	echo 	^^!WIMBootList^^!
	echo ^) do ^(
	echo 	For /f "tokens=1-2 delims=#" %%%%a in ^(%%%%z^) do ^(
	echo 		If ^^!WIMBootTarget^^! EQU %%%%a ^(
	echo			echo.
	echo			echo Please wait...
	echo 			"^!ImageXEXE^!" /info "^!BootWIM^!" /boot %%%%a ^>nul 2^>^&1
	echo 			If ^^!ErrorLevel^^! NEQ 0 ^(
	echo 				echo ImageX Error: ^^!ErrorLevel^^!
	echo 				pause
	echo 			^)
	echo 		^)
	echo 	^)
	echo ^)
	echo.
	echo If "%%Target%%" == "" If /i "%%WIMBootTarget%%"=="E" pause ^& exit
	echo If not "%%Target%%" == "" If /i "%%WIMBootTarget%%"=="C" goto WIMBootTargetSelected
	echo cls
	echo goto WIMBootTarget
	echo.
	echo :WIMBootTargetSelected
) > "%MediaFolderPath%\%AIOBootIndexSelectionScriptName%"

(
	echo @echo off
	echo @setlocal enableextensions
	echo @setlocal EnableDelayedExpansion
	echo @cd /d "%%~dp0"
	echo.
	echo REM	jwa4
	echo.
	echo @title %%Name%%
rem	echo If "%%Device%%" == "" goto CustomPEComplete
	echo If exist "%%CD%%\Bin" Set BinDir=%%CD%%\Bin
	If /i "%AIOInclude_DeviceScripts%" == "True" (
	echo Set CommonDir=%%CD%%\Common
	)
	echo cls
	echo echo Running Script: "%%~dpnx0"
	echo echo To reboot use the "Wpeutil.exe Reboot" or "Exit" commands.
	echo echo To shutdown use the "Wpeutil.exe Shutdown" command.
	echo echo.
	echo echo %%%%CD%%%%: "%%CD%%"
	echo If exist "%%CD%%\Bin" echo %%%%BinDir%%%%: "%%BinDir%%"
	If /i "%AIOInclude_DeviceScripts%" == "True" (
	echo echo %%%%CommonDir%%%%: "%%CommonDir%%"
	)
	echo echo.
	echo echo %%%%Device%%%%: "%%Device%%"
	echo echo %%%%Name%%%%: "%%Name%%"
	echo echo %%%%SoC%%%%: "%%SoC%%"
	echo echo.
	If /i "%AIOInclude_DeviceScripts%" == "True" (
	echo REM ====== Do All Devices Stuff Here ======
	echo.
	echo REM ====== Do Device Specific Stuff Here ======
	echo If exist "%%CD%%\Device_%%Device%%\%%Device%%.cmd" ^(
	echo 	echo Launching %%Name%% Script...
	echo 	Call "%%CD%%\Device_%%Device%%\%%Device%%.cmd"
	echo ^)
	) else (
	echo REM ====== Do Stuff Here ======
	echo cmd.exe
	)
rem	echo :CustomPEComplete
) > "%MediaFolderPath%\CustomPE\CustomPE.cmd"

If /i not "%AIOInclude_DeviceScripts%" == "True" goto SkipAllDeviceScripts

For %%z in (
	!Devices!
) do (
	For /f "tokens=1-3 delims=#" %%q in (%%z) do (
		If not exist "%MediaFolderPath%\CustomPE\Device_%%r" md "%MediaFolderPath%\CustomPE\Device_%%r" 1> nul
		If not exist "%MediaFolderPath%\CustomPE\Common" md "%MediaFolderPath%\CustomPE\Common" 1> nul
		(
			echo @echo off
			echo @setlocal enableextensions
			echo @setlocal EnableDelayedExpansion
			echo @cd /d "%%~dp0"
			echo.
			echo REM	jwa4
			echo.
			echo @title %%Name%%
			rem echo If "%%Device%%" == "" goto CustomPEDeviceComplete
			echo REM ====== To reboot use the "Wpeutil.exe Reboot" or "Exit" commands.
			echo REM ====== To shutdown use the "Wpeutil.exe Shutdown" command.
			echo echo Now Running Script: "%%~dpnx0"
			echo echo.
			echo echo %%%%CD%%%%: "%%CD%%"
			echo echo.
			echo REM ====== Do %%r Stuff Here ======
			rem echo echo Running: "%%BinDir%%\wdd\wdd.exe"...
			rem echo "%%BinDir%%\wdd\wdd.exe" /?
			echo cmd.exe
			rem echo :CustomPEDeviceComplete
		) > "%MediaFolderPath%\CustomPE\Device_%%r\%%r.cmd"
	)
)

:SkipAllDeviceScripts

(
	echo %MediaLabel%
) > "%MediaFolderPath%\%MediaLabel%.mrk"

If /i "%TestMode%" == "True" (
	echo.
	bcdedit /store "%MediaFolderPath%\EFI\Microsoft\Boot\BCD" /set {bootmgr} testsigning on
	bcdedit /store "%MediaFolderPath%\EFI\Microsoft\Boot\BCD" /set {default} testsigning on
	bcdedit /store "%MediaFolderPath%\EFI\Microsoft\Boot\BCD" /set {default} NoIntegrityChecks Yes
)

If exist "%MediaFolderPath%\Sources\ResetConfig.xml" Del "%MediaFolderPath%\Sources\ResetConfig.xml" /F /Q 1> nul
If exist "%MediaFolderPath%\Sources\CreatePartitions-UEFI.txt" Move /y "%MediaFolderPath%\Sources\CreatePartitions-UEFI.txt" "%MediaFolderPath%\CustomPE" 1> nul

If "%CustomOutput%" == "True" (
	Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" CustomOutput
	If exist "%DISMLogPath%\%DISMLogCurrent%" (
		rename "%DISMLogPath%\%DISMLogCurrent%" !MediaFolderName!.txt 1> nul
	)
	goto Timer
)

If "%BuildCustom%" == "True" (
	Call "%CD%\Addons\CustomPE\CustomPE.cmd" OutputFileSystem
)

Move /y "!TmpPath!\Updated\winre\winre.wim" "%MediaFolderPath%\Sources\boot.wim" 1> nul

Set MediaFolderOutputPath=!OutputPath!
If not exist "!MediaFolderOutputPath!" Md "!MediaFolderOutputPath!" 1> nul

If "%MakePEArc%" == "True" (
	echo.
	echo %white%Creating ZIP file.%ef%
	echo Please wait....

	"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" a "%TmpPath%\!MediaFolderName!.zip" "%MediaFolderPath%\*"
	If "!ErrorLevel!" NEQ "0" (
		echo Error: Failed to create ZIP file.
		echo 7-Zip Error !ErrorLevel!.
	) else (
		Move /y "%TmpPath%\!MediaFolderName!.zip" "!OutputPath!" 1> nul
	)
)

Move /y "%MediaFolderPath%" "!MediaFolderOutputPath!" 1> nul
Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%

If exist "%DISMLogPath%\%DISMLogCurrent%" (
	rename "%DISMLogPath%\%DISMLogCurrent%" !MediaFolderName!.txt 1> nul
)

REM ====== Timer =======================================================================================================================================================

:Timer

Set "endTime=%time: =0%"
Set "end=!endTime:%time:~8,1%=%%100)*100+1!"  &  set "start=!startTime:%time:~8,1%=%%100)*100+1!"
Set /A "elap=((((10!end:%time:~2,1%=%%100)*60+1!%%100)-((((10!start:%time:~2,1%=%%100)*60+1!%%100), elap-=(elap>>31)*24*60*60*100"
Set /A "cc=elap%%100+100,elap/=100,ss=elap%%60+100,elap/=60,mm=elap%%60+100,hh=elap/60+100"
Set RunTime=%hh:~1%%time:~2,1%%mm:~1%%time:~2,1%%ss:~1%

If /i "%WinreAIO%" == "True" Set Name=All-In-One

If not "%MBInfoLink%" == "True" goto SkipMBInfoLink

Set MBInfoFile=%temp%\mb_%random%_%random%_%random%
"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -O "%MBInfoFile%.tmp" %MediaBuilderInfoURL% -nc --timeout=2 --read-timeout=2 --tries=2 --no-check-certificate -q --show-progress --progress=bar:force:noscroll >nul 2>&1
If exist "%MBInfoFile%.tmp" %systemroot%\System32\certutil.exe -f -decode "%MBInfoFile%.tmp" "%MBInfoFile%.cmd" >nul 2>&1
If exist "%MBInfoFile%.cmd" call "%MBInfoFile%.cmd" >nul 2>&1

:SkipMBInfoLink

If "%CustomOutput%" == "True" goto OpenFolderSelect

REM ====== Media =======================================================================================================================================================

If exist "%CD%\Includes\Mod_MediaPE.cmd" (
	Call "%CD%\Includes\Mod_MediaPE.cmd" MediaMenu %MediaLabel% "%MediaFolderOutputPath%"
)

If exist "%CD%\Includes\Mod_WinToGoPE.cmd" (
	Call "%CD%\Includes\Mod_WinToGoPE.cmd" WinToGoMenu "%MediaFolderOutputPath%" PE
)

REM ====== Open output folder ==========================================================================================================================================

:OpenFolderSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo Files are located at:
If "%MakePEArc%" == "True" (
	echo "%OutputPath%"
) else (
	echo "%MediaFolderOutputPath%"
)
echo.
Set /p OpenFolderPrompt=Would you like to open this folder (Y/N)? 
If /i "%OpenFolderPrompt%"=="Y" Set OpenFolder=True
If /i "%OpenFolderPrompt%"=="N" Set OpenFolder=False
If "%OpenFolder%" == "" goto OpenFolderSelect

If "%OpenFolder%" == "True" (
	If "%MakePEArc%" == "True" (
		explorer.exe "%OutputPath%"
	) else (
		explorer.exe "%MediaFolderOutputPath%"
	)
)

REM ====== Return to Menu ==============================================================================================================================================

:ReturnMainMenu
If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo All Done - Returning to Main Menu...
echo.
pause
cls
rem endlocal & Set "SkipDriveCheckInt=True" & goto Start
endlocal & Set "SkipDriveCheckInt=" & goto Start

REM ====== Done ========================================================================================================================================================

:Exit

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)

:ExitNoTempClear
If "%MBInfoLink%" == "True" If exist "%MBInfoFile%_2.cmd" call "%MBInfoFile%_2.cmd" >nul 2>&1
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Echo Goodbye^^!
pause
exit