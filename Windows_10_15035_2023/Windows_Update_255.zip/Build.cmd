@echo off
@setlocal enableextensions
@setlocal EnableDelayedExpansion
cls

Set /a MBVerNumber=255

Set MBName=Windows 10 Build 15035 Media Builder
Set MBVer=v%MBVerNumber:~0,1%.%MBVerNumber:~1,2%
Set MBDate=31-07-2024
@Title %MBName% - %MBVer%

REM
REM	The download location of Windows 10 Build 15035 can be updated in the text file below:
REM
REM	\Download_Lists\Windows_10.txt:
REM	URL to Windows 10 Build 15035 archive.
REM
REM	A Windows 10 Build 15035 archive may also be manually placed in \Downloads\Windows\
REM
REM	The following files will be recognised, as of v1.8 a check of file hash is made.
REM	- Archive.org Release - 10.0.15035.0.armfre.rs2_release.170209-1535.7z - SHA1: c3e6831bd6f066a34412a063c5315aad1ddd0d1e
REM	- Betaarchive Release - media_install.rar - SHA1: 14a17a8242dc9c55ab863418abc379e46d551b7d
REM
REM	This will only modify a clean release of Windows 10 Build 15035, it will not work on modified images from other sources.
REM	
REM	Drivers are currently included for these devices:
REM
REM	Microsoft Surface RT 
REM	Microsoft Surface 2
REM	Lenovo IdeaPad Yoga 11
REM	ASUS VivoTab RT
REM	Dell XPS 10 (Untested)
REM	Nokia Lumia 2520 (Untested)
REM	Samsung Ativ Tab (Untested)
REM
REM	jwa4
REM	https://forum.xda-developers.com/t/windows-10-build-15035-media-builder.4232301/

REM ====== Network Drive/Share Check ===================================================================================================================================

If "%~d0" == "\\" (
	Set BuildAbort=True
)

"%SystemRoot%\System32\net.exe" use > NUL 2>&1
If "!ErrorLevel!" EQU "2" goto SkipMappedDriveCheck

"%SystemRoot%\System32\net.exe" use | "%SystemRoot%\System32\findstr.exe" /I /L /C:" %~d0 " >nul
If not "!ErrorLevel!" EQU "1" (
	Set BuildAbort=True
)

:SkipMappedDriveCheck

If "%BuildAbort%" == "True" (
	echo Error: Media Builder cannot be run from a mapped drive or network share.
	goto ExitNoTempClear
)

@cd /d "%~dp0"

REM ====== Check only one instance is running ==========================================================================================================================

9>&2 2>nul (Call :LockAndRestoreStdErr %* 8>>"%~f0") || (
	echo %red%Error: Only one instance allowed. >&2%ef%
)
goto ExitNoTempClear

:LockAndRestoreStdErr
Call :SingleInstance %* 2>&9
exit /b 0

:SingleInstance

9>&2 2>nul (call :LockAndRestoreStdErr1 %* 8>>"!CD!\Cleanup.cmd") || (
	echo %red%Error: Only one instance allowed. >&2%ef%
)
goto ExitNoTempClear

:LockAndRestoreStdErr1
call :SingleInstance1 %* 2>&9
exit /b 0

:SingleInstance1

REM ====== Checks ======================================================================================================================================================

Set MBFirstRun=True

:Start
setlocal

If /i "!MBFirstRun!" == "True" (
	endlocal & Set MBFirstRun=False
	setlocal & Set MBFirstRunInt=True
)

If exist "%CD%\Includes\Build_Common.cmd" (
	echo Please Wait...
	Call "%CD%\Includes\Build_Common.cmd" BuildCommon %~nx0
) else (
	echo %red%Error: File Missing...%ef%
	echo "!CD!\Includes\Build_Common.cmd"
	Set BuildAbort=True
)

If "%BuildRestart%"=="True" (
	cls
	endlocal
	goto Start
)

If "%BuildAbort%"=="True" goto ExitNoTempClear

REM ====== Menu Text ===================================================================================================================================================

For /f "tokens=1" %%a in ('powershell -c "$ErrorActionPreference='Stop'; Get-Date -Format yyyy"') do Set /a Build15035Age=%%a-2017

If exist "%CD%\Download_Lists\Last_Updated" (
	Set /p WindowsUpdateListsUpdated=< "%CD%\Download_Lists\Last_Updated"
	For /f "tokens=1-2 delims=#" %%a in ("!WindowsUpdateListsUpdated!") do (
		Set WindowsUpdateListsRelease=%%a
		Set WindowsUpdateListsUpdated=%%b
	)
) else (
	Set WindowsUpdateListsRelease=Unknown Release
	Set WindowsUpdateListsUpdated=Unknown Date
)

Set NL=^


Set MenuText=%white%%ul%_______________________________________________________%ef%!NL!^
!NL!^
%white%%MBName% %MBVer% - %MBDate%%ef%!NL!^
%white%%ul%_______________________________________________________%ef%!NL!^
!NL!^
7-Zip - Copyright (C) 1999-2019 Igor Pavlov.!NL!^
GNU Wget - Copyright (C) 1996-2008, Free Software Foundation, Inc.!NL!^
QEMU - Copyright (C) 2003-2021 Fabrice Bellard and the QEMU Project developers. (Thanks to @x86corez ^& @driver1998)!NL!^
SetACL - Copyright (C) 2012, Helge Klein.!NL!^
tget - Copyright (C) 2024, sweetbbak. !NL!^
!NL!^
This media builder will download Windows 10 Build 15035, apply common modifications, install apps, install drivers!NL!^
and generate custom installation media ready for use on the selected device.!NL!^
!NL!^
%red%The use of this media builder or the media it produces is entirely at your own risk.%ef%!NL!^
%ul%________________________________________________________________________________________________________________________%ef%


Set InfoBar=%info%  INFO                                INFO                                    INFO                                INFO  %ef%
Set WarningBar=%warn% WARNING                             WARNING                                WARNING                             WARNING %ef%

REM ====== Main Menu ===================================================================================================================================================

:MainMenu
cls

If exist "%CD%\Includes\Build_Preset.cmd" (
	Call "%CD%\Includes\Build_Preset.cmd" FindPreset
)

echo !MenuText!

If exist "%CD%\Includes\Mod_Media.cmd" (
	If exist "%CD%\Includes\Mod_Media_Rewrite.cmd" (
		Set ExistingMedia=W: Write Existing Installation Files
	) else (
		Set ExistingMedia=%black%%ef%
	)
) else (
	Set ExistingMedia=%black%%ef%
)

If exist "%CD%\Includes\Build_Settings.cmd" (
	Set SettingsText=S: Media Builder Settings
) else (
	Set SettingsText=%black%%ef%
)

If exist "%CD%\Includes\Build_UpdateLists.cmd" (
	Set MiscText=M: Miscellaneous
) else (
	Set MiscText=%black%%ef%
)

If "%CreatePreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" MenuItemsDesc
) else (
	If exist "%CD%\Includes\Build_Preset.cmd" (
		Call "%CD%\Includes\Build_Preset.cmd" MenuItemsPreset
	) else (
			echo.
			echo %white%Options:%ef%	 %ExistingMedia%
			echo 		 %SettingsText%
			echo 		 %MiscText%
		)
	)
)

echo.
echo %white%Select Device:%ef%	 1: Microsoft Surface RT		5: Dell XPS 10 %red%(Non-functional)%ef%
echo			 2: Microsoft Surface 2			6: Nokia Lumia 2520 %red%(Non-functional)%ef%
echo			 3: Lenovo IdeaPad Yoga 11		7: Samsung Ativ Tab %red%(Non-functional)%ef%
echo			 4: ASUS VivoTab RT			8: None (No Drivers)
echo.
If "%CreatePreset%" == "True" (
	echo			 E: %red%Exit Preset Mode%ef%
) else (
	echo			 E: %red%Exit%ef%				!%MBMessageColour%!%MBMessage%%ef%
)

echo.
Set /p Target=%white%Enter Selection: %ef%

:SkipTarget

If "%Target%"=="1" goto SurfaceRT
If "%Target%"=="2" goto Surface2
If "%Target%"=="3" goto Yoga11
If "%Target%"=="4" goto VivoTab
If "%Target%"=="5" goto XPS10
If "%Target%"=="6" goto Lumia2520
If "%Target%"=="7" goto ATIVTab
If "%Target%"=="8" goto Generic

If /i "%Target%"=="Lumia2020" goto Lumia2020
If /i "%Target%"=="SurfaceMini" goto SurfaceMini

rem If not "%CreatePreset%" == "True" If /i "%Target%"=="QEMU" goto QEMU

If not "%CreatePreset%" == "True" If exist "%CD%\Includes\Build_Misc.cmd" If /i "%Target%"=="M" (
	Call "%CD%\Includes\Build_Misc.cmd" MiscMenu
	If /i "!MiscTarget!" == "Q" (
		goto QEMU
	)
	If /i "!MiscTarget!" == "B" (
		Call "%CD%\Includes\Build_Common.cmd" ForceUpdateCheck %~nx0 True
	)
	cls
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

If /i "%Target%"=="E" (
	If "%CreatePreset%" == "True" (
		endlocal & Set SkipDriveCheckInt=True
		goto Start
	) else (
		goto Exit
	)
)

If exist "%CD%\Includes\Build_Preset.cmd" If /i "%Target%"=="C" (
	Call "%CD%\Includes\Build_Preset.cmd" CreatePreset
)

If exist "%CD%\Includes\Build_Preset.cmd" If /i "%Target%"=="D" (
	Call "%CD%\Includes\Build_Preset.cmd" DownloadPreset
	If "!DownloadPreset!" == "True" goto SkipTarget
)

If exist "%CD%\Includes\Build_Preset.cmd" If /i "%Target%"=="B" (
	Call "%CD%\Includes\Build_Preset.cmd" BuildPreset
	If "!BuildPreset!" == "True" goto SkipTarget
)

If not "%CreatePreset%" == "True" If exist "%CD%\Includes\Mod_Media.cmd" If exist "%CD%\Includes\Mod_Media_Rewrite.cmd" If /i "%Target%"=="W" (
	Call "%CD%\Includes\Mod_Media_Rewrite.cmd" Windows_Media_Select_Start
	If /i "!Windows_Media_Selection!" == "C" (
		cls
		endlocal & Set SkipDriveCheckInt=True
		goto Start
	)
	goto ReturnMainMenu
)

If not "%CreatePreset%" == "True" If exist "%CD%\Includes\Build_Settings.cmd" If /i "%Target%"=="S" (
	Set PathChange=False
	Call "%CD%\Includes\Build_Settings.cmd" Build_Settings_Start
	cls
	If "!PathChange!" == "True" endlocal & Set SkipDriveCheckInt=False
	If "!PathChange!" == "False" endlocal & Set SkipDriveCheckInt=True
rem	endlocal & Set SkipDriveCheckInt=False
	goto Start
)

goto MainMenu

:SurfaceRT
Set Device=SurfaceRT
Set SoC=Nvidia
goto Continue

:Surface2
Set Device=Surface2
Set SoC=Nvidia
goto Continue

:Yoga11
Set Device=Yoga11
Set SoC=Nvidia
goto Continue

:VivoTab
Set Device=VivoTabRT
Set SoC=Nvidia
goto Continue

:XPS10
Set Device=XPS10
Set SoC=Qualcomm
goto Continue

:Lumia2520
Set Device=Lumia2520
Set SoC=Qualcomm
goto Continue

:Lumia2020
Set Device=Lumia2020
Set SoC=Qualcomm
goto Continue

:ATIVTab
Set Device=ATIVTab
Set SoC=Qualcomm
goto Continue

:SurfaceMini
Set Device=SurfaceMini
Set SoC=Qualcomm
goto Continue

:Generic
Set Device=Generic
Set Name=None
Set SoC=None
goto Continue

:QEMU
Set Device=QEMU
Set SoC=Emulated
goto Continue

:Continue
If not "%SoC%" == "None" (
	If exist "!CD!\Devices\%SoC%\%Device%\%Device%.cmd" (
		Call "!CD!\Devices\%SoC%\%Device%\%Device%.cmd" DeviceInfo
	) else (
		cls
		echo Error: File Missing...
		echo "!CD!\Devices\%SoC%\%Device%\%Device%.cmd"
		Set BuildAbort=True
	)
)

If /i "%BuildAbort%"=="True" goto ExitNoTempClear

cls

REM ====== Device Notes ================================================================================================================================================

If "!ReadPreset!" == "True" goto DeviceConfirmed

If "%SkipNotes%" == "True" goto DeviceConfirmed

If "%MediaBuilderWorks%" == "False" (
	Set Bar=%WarningBar%
) else (
	Set Bar=%InfoBar%
)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %Bar%
echo. %white%
echo 	%ul%Device Notes%ef%%white%
echo.

If "%Device%" == "Generic" (
	echo 	Media Builder will produce output without device drivers.
) else (
	If "%MediaBuilderWorks%" == "False" (
		echo 	Media Builder cannot currently produce working output for %Name%.
	) else (

		If "%SetupFromUSB%" == "True" If "%YahalloSupported%" == "True" If "%YahalloRequired%" == "True" (
			echo 	%Name% requires Yahallo to be applied and Golden Keys to be removed from the device in
			echo 	order to install Windows 10 Build 15035 from USB via its original Setup/Recovery Environment.
		)

		If "%SetupFromUSB%" == "True" If "%YahalloSupported%" == "True" If "%YahalloRequired%" == "False" (
			echo 	%Name% requires Golden Keys to be removed from the device in order to install Windows
			echo 	10 Build 15035 from USB via its original Setup/Recovery Environment. Yahallo is optional.
		)

		If "%SetupFromUSB%" == "True" If "%YahalloSupported%" == "False" If "%YahalloRequired%" == "False" (
			echo 	%Name% requires Golden Keys to be removed from the device in order to install Windows
			echo 	10 Build 15035 from USB via its original Setup/Recovery Environment.
		)

		If "%SetupFromUSB%" == "False" If "%GoldenKeysRequired%" == "True" (
			echo 	%Name% does not support installation of Windows 10 Build 15035 from USB via its
			echo 	original Setup/Recovery Environment.
			echo.
			echo 	To use Windows 10 on this device the install.wim created by Media Builder must be manually applied
			echo 	with DISM ^(replacing the Windows RT 8.1 installation^) once Golden Keys has been installed.
		)

		If Exist "%CD%\Addons\WinRE9600\WinRE9600.cmd" Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600JailbreakInfo

	)
)

echo.
echo 	%red%Windows 10 Build 15035 is now %Build15035Age% years old and it should not be considered as suitable for daily use,
echo 	in addition to being outdated it has numerous bugs and other issues expected of an expired pre-release 
echo 	build.
echo. %ef%
echo %Bar%
echo.

Set /p DeviceConfirmPrompt=Would you like to continue? (Y/N)? 
If /i "%DeviceConfirmPrompt%"=="Y" (
	cls
	goto DeviceConfirmed
)

If /i "%DeviceConfirmPrompt%"=="N" (
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

goto Continue

:DeviceConfirmed

REM ====== Install Appx ================================================================================================================================================

If exist "%CD%\Addons\Appx\Install_Appx.cmd" (
	Call "%CD%\Addons\Appx\Install_Appx.cmd" AppxMenu
)

REM ====== Uninstall Appx ==============================================================================================================================================

If exist "%CD%\Includes\Uninstall_Appx.cmd" (
	Call "%CD%\Includes\Uninstall_Appx.cmd" UninstallAppxMenu
)

REM ====== Install Device Appx =========================================================================================================================================

If "%DeviceApps%" == "True" If exist "%CD%\Addons\Appx\Install_Appx_%Device%.cmd" (
	Call "%CD%\Addons\Appx\Install_Appx_%Device%.cmd" DeviceAppxMenu 10
)

REM ====== Uninstall BitLocker =========================================================================================================================================

If exist "%CD%\Includes\Uninstall_BitLocker.cmd" (
	Call "%CD%\Includes\Uninstall_BitLocker.cmd" UninstallBitLockerMenu
)

REM ====== Uninstall Cortana ===========================================================================================================================================

If exist "%CD%\Includes\Uninstall_Cortana.cmd" (
	Call "%CD%\Includes\Uninstall_Cortana.cmd" UninstallCortanaMenu
)

REM ====== Uninstall Defender ==========================================================================================================================================

If exist "%CD%\Includes\Uninstall_Defender.cmd" (
	Call "%CD%\Includes\Uninstall_Defender.cmd" UninstallDefenderMenu
)

REM ====== Activation ==================================================================================================================================================

If exist "%CD%\Includes\Mod_Install_SetupComplete_Activation.cmd" (
	Call "%CD%\Includes\Mod_Install_SetupComplete_Activation.cmd" ActivationMenu
)

REM ====== Office 2013 RT ==============================================================================================================================================

If exist "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" (
	Call "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" Office2013RTMenu
)

REM ====== Custom ======================================================================================================================================================

If "%CustomAddon%" == "True" If exist "%CD%\Addons\Custom\Custom.cmd" (
	Call "%CD%\Addons\Custom\Custom.cmd" CustomMenu
) else (
	Set BuildCustom=False
)

REM ====== Installer ===================================================================================================================================================

:SelectSetupMode
If "!ReadPreset!" == "True" goto SkipSetupModeSelection

If "%CustomSetup%" == "True" (
	If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" SetupMode
	goto SetupModeSelected
)

cls
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Select Windows Setup Mode:%ef%
echo.
echo		1: %magenta%Windows Setup (Default)%ef%
echo.
If /i "%RecoveryMode%" == "True" (
echo		Creates installation media using default Windows Setup, this mode is not as touch friendly as the
echo		Windows Recovery Environment and does not create a recovery partition.
) Else (
echo		Creates installation media using default Windows Setup, this mode is not as touch friendly as the
echo		Windows Recovery Environment.
)
echo.
echo		2: %blue%Windows Recovery Environment (WinRE)%ef%
echo.
If /i "%RecoveryMode%" == "True" (
echo		Creates installation media using the Windows Recovery Environment, this mode is touch friendly and
echo		will create a recovery partition.
) Else (
echo		Creates installation media using the Windows Recovery Environment, this mode is touch friendly.
)
echo.
echo		3: %white%Modified WIM Files Only (No Setup)%ef%
echo.
echo		Creates modified WIM files for manual installation.

If Exist "%CD%\Addons\WinRE9600\WinRE9600.cmd" Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600Menu

echo. %white%
Set /p SetupModeSelection=Enter Selection: 
echo. %ef%

:SkipSetupModeSelection

If "%SetupModeSelection%"=="1" goto Setup
If "%SetupModeSelection%"=="2" goto WinRE
If "%SetupModeSelection%"=="3" goto WIM

If Exist "%CD%\Addons\WinRE9600\WinRE9600.cmd" If "%SetupModeSelection%"=="4" goto WinRE9600

goto SelectSetupMode

:Setup
Set SetupMode=Setup
Set OfferInstallESD=True
Set SetupModeDesc=Windows Setup
Set WinREInInstall=True
goto SetupModeSelected

:WinRE
Set SetupMode=WinRE
Set OfferInstallESD=True
Set SetupModeDesc=Windows Recovery Environment
Set WinREInInstall=False
goto SetupModeSelected

:WIM
Set SetupMode=WimOnly
Set OfferInstallESD=False
Set SetupModeDesc=WIM

:WinREInInstallSelect
If "!ReadPreset!" == "True" (
	If "%WinREInInstall%" == "True" (
		Set WinREInInstallPrompt=Y
	) else (
		Set WinREInInstallPrompt=N
	)
	Goto SkipWinREInInstallPrompt
)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p WinREInInstallPrompt=Include Winre.wim in Install.wim (Y/N)? 

:SkipWinREInInstallPrompt

If /i "%WinREInInstallPrompt%"=="Y" (
	Set WinREInInstall=True
	Set SetupModeDescNote=Include Winre.wim in Install.wim
	goto SetupModeSelected
)

If /i "%WinREInInstallPrompt%"=="N" (
	Set WinREInInstall=False
	Set SetupModeDescNote=Do not include Winre.wim in Install.wim
	goto SetupModeSelected
)

goto WinREInInstallSelect

:WinRE9600
Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600SetupInfo
goto SetupModeSelected

:SetupModeSelected

If "%OfferInstallESD%" == "False" (
	Set InstallESD=False
	goto SkipInstallESDPrompt
)

:InstallESDSelect
cls
If "!ReadPreset!"=="True" Goto SkipInstallESDPrompt
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %White%Windows Image Compression Mode:%ef%
echo.
echo		1: %green%Windows Imaging Format (WIM) Format%ef%
echo.
echo		Offers shorter image creation time at the expense of lower compression.
echo.
echo		2: %red%Electronic Software Delivery (ESD) Format%ef%
echo.
echo		Offers higher compression at the expense of longer image creation time. Using this option will result in
If /i "%RecoveryMode%" == "True" (
echo		lower disk space usage on the installation USB and where applicable result in a smaller recovery partition.
) else (
echo		lower disk space usage on the installation USB.
)
echo. %white%
Set /p InstallESDPrompt=Enter Selection: 
echo. %ef%

If "%InstallESDPrompt%"=="1" Set InstallESD=False
If "%InstallESDPrompt%"=="2" Set InstallESD=True

:SkipInstallESDPrompt

If "%InstallESD%" == "True" (
	Set InstallFormat=ESD
) else (
	Set InstallFormat=WIM
)

If "%InstallESD%" == "" goto InstallESDSelect

REM ====== Confirm =====================================================================================================================================================

:ConfirmSelect
cls
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %red%Excluding download time this process may take up to one hour, please confirm the following selections are correct:%ef%
echo.

Call "%CD%\Includes\Mod_Info_Files.cmd" infopreview 0 mediabuilder

For %%d in (
	UpdateAppx
	Office2013RT_Install
	BuildCustom
) do (
	If "!%%d!" == "True" Set ShowInfoBar=True
)

If "%ShowInfoBar%" == "True" (
	echo %InfoBar%
	echo.
)

If "%UpdateAppx%" == "True" (
	Call "%CD%\Addons\Appx\Install_Appx.cmd" AppxInfo
)

If "%Office2013RT_Install%" == "True" (
	Call "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" Office2013RTInfo
)

If "%BuildCustom%" == "True" (
	Call "%CD%\Addons\Custom\Custom.cmd" CustomInfo
)

If "%ShowInfoBar%" == "True" (
	echo %InfoBar%
	echo.
)

echo %red%Please do not close this window while downloads and image modifications are in progress.%ef%
echo.

If "%CreatePreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" CreatePresetInfo
)

If "%DownloadPreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" DownloadPresetInfo
)

If not "%DownloadPreset%" == "True" If "%ReadPreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" BuildPresetInfo
)

Set /p ConfirmPrompt=Would you like to continue%ConfirmPromptText%? (Y/N)? 
If /i "%ConfirmPrompt%"=="Y" (

	If "%CreatePreset%" == "True" (
		Call "%CD%\Includes\Build_Preset.cmd" SavePreset
		Call "%CD%\Includes\Build_Preset.cmd" CreatePresetComplete
		endlocal & Set SkipDriveCheckInt=True
		goto Start
	)

	goto Confirmed

)

If /i "%ConfirmPrompt%"=="N" (
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

goto ConfirmSelect

:Confirmed

REM ====== Timer =======================================================================================================================================================

Set "startTime=%time: =0%"

REM ====== Make sure Tmp folder empty ==================================================================================================================================

Set Retry=0

:RetryTempClear

If exist "%TmpPath%\" If "%Retry%" == "1" (
	echo.
	echo %red%Error: Unable to clear "%TmpPath%" folder, please reboot and try again.%ef%
	goto ExitNoTempClear
)

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %white%Clearing Temporary Files.%ef%
	echo Please wait.
	echo.
	If exist "%TmpPath%\Mount\boot\" start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\boot" /discard >NUL
	echo Please wait..
	echo.
	If exist "%TmpPath%\Mount\winre\" start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre" /discard >NUL
	echo Please wait...
	echo.
	If exist "%TmpPath%\Mount\winre9600\" start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre9600" /discard >NUL
	echo Please wait....
	echo.
	If exist "%TmpPath%\Mount\install\" start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\install" /discard >NUL
	echo Please wait.....

	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1

	If not exist "%TmpPath%\" (
		echo.
		echo %green%"%TmpPath%" Cleared.%ef%
	) else (
		Set Retry=1
		goto RetryTempClear
	)
)

REM ====== Create folders ==============================================================================================================================================

For %%d in (
	"%CD%\Addons\Appx\Apps\"
	"%CD%\Addons\Appx\Store\"
	"%CD%\Addons\Appx\Dependency\"
	"%CD%\Addons\Custom\"
	"%CD%\Addons\Office\"
	"%DownloadsPath%\Windows\"
	"%TmpPath%\ScratchDir"
	"%TmpPath%\Source\"
	"%TmpPath%\Mount\boot\"
	"%TmpPath%\Mount\winre\"
	"%TmpPath%\Mount\install\"
	"%TmpPath%\Updated\boot\"
	"%TmpPath%\Updated\winre\"
	"%TmpPath%\Updated\install\"
	"%TmpPath%\Logs"
) do (
	If not exist %%d md %%d 1> nul
)

REM ====== Read Windows download URL & SHA1 ============================================================================================================================

:WindowsRetry
rem Set /p WindowsDownloadList=< "%CD%\Download_Lists\Windows_10.txt"

rem For /f "tokens=1,2,3,4 delims=#" %%a in ("%WindowsDownloadList%") do (
rem	Set SHA1=%%a
rem	Set Windows_URL=%%b
rem	Set Windows_FileName=%%~NXb
rem	Set Windows_TorrentURL=%%c
rem	Set Windows_TorrentFileName=%%~NXc
rem	Set Windows_TorrentDir=!Windows_TorrentFileName:_archive.torrent=!
rem	Set Windows_Source=%%d
rem )

Set FindLanguage=en-us
Set WindowsDownloadList="%CD%\Download_Lists\Windows_10.txt"

For /F "usebackq tokens=* skip=1" %%a in (%WindowsDownloadList%) do (
	For /f "tokens=1-19 delims=," %%a in ("%%a") do (
		If /i "%%a" == "%FindLanguage%" (
			Set Windows_Tag=%%a
			Set Windows_Language=%%b
			Set Windows_Country=%%c
			Set Windows_LCID=%%d
			Set Windows_UNUSED1=%%e
			Set Windows_AppxSafe=%%f

			If /i "!WindowsForceAltDownload!" == "True" (

				Set Windows_HTTPSourceName=%%n
				Set Windows_URL=%%o
				Set Windows_FileName=%%~NXo

				Set Windows_TorrentSourceName=%%p
				Set Windows_TorrentURL=%%q
				Set Windows_TorrentFileName=%%~NXq
				Set Windows_TorrentDir=!Windows_TorrentFileName:_archive.torrent=!
				Set Windows_TorrentM=%%r
				Set Windows_TorrentIndex=%%s

			) else (

				Set Windows_HTTPSourceName=%%g
				Set Windows_URL=%%h
				Set Windows_FileName=%%~NXh

				Set Windows_TorrentSourceName=%%i
				Set Windows_TorrentURL=%%j
				Set Windows_TorrentFileName=%%~NXj
				Set Windows_TorrentDir=!Windows_TorrentFileName:_archive.torrent=!
				Set Windows_TorrentM=%%k
				Set Windows_TorrentIndex=%%l

			)

			Set SHA1=%%m

		)
	)
)

If /i "%ArchiveOrgTorrent%" == "True" (
	Set Windows_Source=!Windows_TorrentSourceName!
) else (
	Set Windows_Source=!Windows_HTTPSourceName!
)

If exist "%CD%\Temp.cmd" Call "%CD%\Temp.cmd" Windows_List

REM ====== Check if Windows already downloaded =========================================================================================================================

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Downloading Windows 10 Build 15035.%ef%
echo Please wait...
echo.

If exist "%DownloadsPath%\Windows\media_install.rar" (
	Set Windows_FileName=media_install.rar
	Set SHA1=14a17a8242dc9c55ab863418abc379e46d551b7d
	echo %white%Betaarchive release found, skipping download.%ef%

	If "%Office2013RT_Install%" == "True" If /i "%SHA1Check%" == "True" echo.

	If not "%Office2013RT_Install%" == "True" echo.
	goto SkipArchiveOrgDownload
)

If exist "%DownloadsPath%\Windows\%Windows_FileName%" (
	echo %white%%Windows_Source% release found, skipping download.%ef%

	If "%Office2013RT_Install%" == "True" If /i "%SHA1Check%" == "True" echo.

	If not "%Office2013RT_Install%" == "True" echo.
	goto SkipArchiveOrgDownload
)

REM ====== Download Windows ============================================================================================================================================

If /i "%Windows_TorrentIndex%" == "False" goto WindowsWget

If "%Windows_TorrentIndex%" == "True" (
	Set TorrentSelect=
) else (
	Set TorrentSelect=--select-file=%Windows_TorrentIndex%
)

If /i "%ArchiveOrgTorrent%" == "True" (
	netsh advfirewall firewall add rule name="Windows Media Builder - tget" dir=in action=allow program="%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" enable=yes 1> nul
	"%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" /1 /t "%Windows_TorrentURL%" /o "%TmpPath%" /n
	Set TorrentClientStatus=!ErrorLevel!
	netsh advfirewall firewall delete rule name="Windows Media Builder - tget" program="%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" 1> nul
)

If /i "%ArchiveOrgTorrent%" == "True" (
	If !TorrentClientStatus! EQU 0 (
		Move /y "%TmpPath%\%Windows_TorrentDir%\%Windows_FileName%" "%DownloadsPath%\Windows\" 1> nul
		echo.
		goto SkipArchiveOrgDownload
	) else (
		echo.
		echo %red%Error: Unable to download Windows.%ef%
		echo %red%Error: !TorrentClientStatus!%ef%
		Goto Exit
	)
)

:WindowsWget

"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" %Windows_URL% -P "%DownloadsPath%\Windows" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to download Windows.%ef%
	echo %red%Wget Error: !ErrorLevel!%ef%
	Goto Exit
) else (
	echo.
)

:SkipArchiveOrgDownload

REM ====== SHA1 Check ==================================================================================================================================================

If /i "%SHA1Check%" == "True" (
	echo %white%Verifying file.%ef%
	echo Please wait...
	echo.

	For /f "delims=" %%_ in ('%SystemRoot%\System32\certutil.exe -hashfile "%DownloadsPath%\Windows\%Windows_FileName%" SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
		Set x=%%_
		Set Windows_FileFoundSHA1=!x: =!
	)

	If not %SHA1% equ !Windows_FileFoundSHA1! (

		echo %red%File Bad: %Windows_FileName%%ef%

		If "!Windows_RetryCount!" == "1" (
			echo %red%Error: Failed to replace corrupt Windows Installation Media.%ef%
			goto Exit
		)

		:RenameExistingDownloadSelect
		echo.
		Set /p RenameExistingDownloadPrompt=Would you like to move the corrupt file and download a new copy ^(Y/N^)? 
		If /i "!RenameExistingDownloadPrompt!"=="Y" Set RenameExistingDownload=True
		If /i "!RenameExistingDownloadPrompt!"=="N" Set RenameExistingDownload=False
		If "!RenameExistingDownload!" == "" goto RenameExistingDownloadSelect

		If "!RenameExistingDownload!" == "True" (
			echo.
			Attrib -r -s -h "%DownloadsPath%\Windows\%Windows_FileName%" 1> nul
			for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a
			If Not Exist "%DownloadsPath%\Windows_Corrupt\!RenameTime:~0,14!\" md "%DownloadsPath%\Windows_Corrupt\!RenameTime:~0,14!\" 1> nul

			Move /y "%DownloadsPath%\Windows\%Windows_FileName%" "%DownloadsPath%\Windows_Corrupt\!RenameTime:~0,14!\" 1> nul

			If exist "%DownloadsPath%\Windows\%Windows_FileName%" (
				echo %red%Error: Unable to move:%ef%
				echo %red%"%DownloadsPath%\Windows\%Windows_FileName%"%ef%
				goto Exit
			) else (
				echo Moved To: "%DownloadsPath%\Windows_Corrupt\!RenameTime:~0,14!\"
				echo.
				echo Retrying...
				Set Windows_RetryCount=1
				goto WindowsRetry
			)
		) else (
			goto Exit
		)
	) else (
		echo %green%File OK: %Windows_FileName%%ef%
		rem X
		If not "%Office2013RT_Install%" == "True" echo.
	)

)

REM ====== Office 2013 RT ==============================================================================================================================================

:OfficeUpdateRetry

For %%o in (
	Office2013RTDownload#%Office2013RT_Install%
	Office2013RTVerify#%Office2013RT_Install%
	Office2013RTUpdates#%Office2013RT_Update%
) do (
	For /f "tokens=1,2 delims=#" %%a in ("%%o") do (
		Set Office2013RT_Stage=%%a
		Set Office2013RT_Run=%%b
		If "!Office2013RT_Run!" == "True" (
			Call "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" !Office2013RT_Stage!
			If "!Office2013RT_Abort!" == "True" goto Exit
		)
	)
)

If "%OfficeUpdate_Retry%" == "True" (
	set OfficeUpdate_Retry=False
	goto OfficeUpdateRetry
)

REM ====== Preset Download Only ========================================================================================================================================

If "%DownloadPreset%" == "True" (
	Call "%CD%\Includes\Build_Preset.cmd" DownloadPresetComplete
	endlocal & Set SkipDriveCheckInt=True
	goto Start
)

REM ====== Set output folder and filename ==============================================================================================================================

for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set DTS=%%a
Set Date1=%DTS:~6,2%-%DTS:~4,2%-%DTS:~0,4%
Set Time1=%DTS:~8,2%-%DTS:~10,2%-%DTS:~12,2%

Set MediaFolder=Windows_Media
Set MediaFolderName=Windows10_15035_%Device%_%Date1%_%Time1%
Set MediaFolderPath=%TmpPath%\%MediaFolder%\%MediaFolderName%

If not exist "%MediaFolderPath%" Md "%MediaFolderPath%" 1> nul

REM ====== Extract Windows Setup Media files to output directory =======================================================================================================

rem If /i "%SHA1Check%" == "True" echo.

If not "%Office2013RT_Install%" == "True" goto SkipExtWinSetupLine
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
:SkipExtWinSetupLine

echo %white%Extracting %Windows_FileName%%ef%
echo Please wait...

"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%DownloadsPath%\Windows\%Windows_FileName%" -o"%MediaFolderPath%"
echo.
If "!ErrorLevel!" NEQ "0" (
	echo %red%7-Zip Error: !ErrorLevel!%ef%
	goto Exit
) else (
	echo %green%Extracted OK.%ef%
)

REM ====== Copy WIM Files to working directory =========================================================================================================================

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Preparing WIM Files.%ef%

For %%d in (
	"%MediaFolderPath%\sources\boot.wim"
	"%MediaFolderPath%\sources\install.wim"
) do (
	Move /y %%d "%TmpPath%\Source\" 1> nul
	If not exist "%TmpPath%\Source\%%~nxd" (
		echo %red%Error: %%~nxd missing.%ef%
		goto Exit
	)
)

REM ====== Mount Install.wim first to get Winre.wim ====================================================================================================================

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Mount-Wim /WimFile:"%TmpPath%\Source\install.wim" /index:1 /MountDir:"%TmpPath%\Mount\install"
Set DismError=!ErrorLevel!

If not !DismError! EQU 0 (
	If !DismError! EQU 1314 (
		echo.
		echo %red%Error: User "%username%" may not have "Manage auditing and security log" permission, unable to mount install.wim.%ef%
	) else (
		echo.
		echo %red%Error: Unable to mount install.wim.%ef%
	)
	echo DISM Error: !DismError!
	goto ExitNoTempClear
)

Attrib -r -s -h "%TmpPath%\Mount\install\Windows\System32\Recovery\winre.wim" 1> nul
Move /y "%TmpPath%\Mount\install\Windows\System32\Recovery\winre.wim" "%TmpPath%\Source\" 1> nul

If "%SetupMode%" == "WinRE9600" Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600CopyWIM

REM ====== Boot.wim ====================================================================================================================================================

If "%SetupMode%" == "WinRE9600" goto SkipBootTemp

If "%SetupMode%" == "WinRE" (
	Del "%TmpPath%\Source\boot.wim" /F /Q 1> nul
) else (

	For /l %%e in (1,1,2) do (

		echo %ul%________________________________________________________________________________________________________________________%ef%
		echo.
		echo %white%Modifying Boot.wim - Index:%%e%ef%

		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Mount-Wim /WimFile:"%TmpPath%\Source\boot.wim" /index:%%e /MountDir:"%TmpPath%\Mount\boot"

		If not "%Device%" == "Generic" (
			If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" boot
		)

		If "%BuildCustom%" == "True" (
			Call "%CD%\Addons\Custom\Custom.cmd" boot
		)

		If "%%e" == "2" (
			If exist "%CD%\Includes\Mod_Setup.cmd" Call "%CD%\Includes\Mod_Setup.cmd" ModSetupIndex2
		)

		Call "%CD%\Includes\Mod_Info_Files.cmd" boot %%e mounted

		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\boot" /Commit

		If "%ExportBootWinREWIM%" == "True" (
			start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\boot.wim" /SourceIndex:%%e /DestinationImageFile:"%TmpPath%\Updated\boot\boot.wim" /Compress:max
			If "%%e" == "2" Del "%TmpPath%\Source\boot.wim" /F /Q 1> nul
		) else (
			echo.
			echo %white%Skipping WIM Export%ef%
			If "%%e" == "2" Move /y "%TmpPath%\Source\boot.wim" "%TmpPath%\Updated\boot" 1> nul
		)
	)
	Call "%CD%\Includes\Mod_Info_Files.cmd" boot 1 unmounted
	Call "%CD%\Includes\Mod_Info_Files.cmd" boot 2 unmounted
)

:SkipBootTemp

REM ====== Winre.wim ===================================================================================================================================================

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Modifying Winre.wim - Index:1%ef%

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Mount-Wim /WimFile:"%TmpPath%\Source\winre.wim" /index:1 /MountDir:"%TmpPath%\Mount\winre"

If not "%Device%" == "Generic" (
	If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" winre
)

If "%BuildCustom%" == "True" (
	Call "%CD%\Addons\Custom\Custom.cmd" winre
)

Call "%CD%\Includes\Mod_Info_Files.cmd" winre 1 mounted

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre" /Commit

If "%ExportBootWinREWIM%" == "True" (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\winre.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\winre\winre.wim" /Compress:max
	Del "%TmpPath%\Source\winre.wim" /F /Q 1> nul
) else (
	echo.
	echo %white%Skipping WIM Export%ef%
	Move /y "%TmpPath%\Source\winre.wim" "%TmpPath%\Updated\winre" 1> nul
)

Call "%CD%\Includes\Mod_Info_Files.cmd" winre 1 unmounted

REM ====== Winre.wim 9600 ==============================================================================================================================================

If "%SetupMode%" == "WinRE9600" Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600WIM

REM ====== Install.wim =================================================================================================================================================

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Modifying Install.wim - Index:1%ef%

If not "%Device%" == "Generic" (
	If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" install
)

If "%UpdateAppx%" == "True" (
	Call "%CD%\Addons\Appx\Install_Appx.cmd" AppxCopy
)

If "%UninstallAppx%" == "True" (
	Call "%CD%\Includes\Uninstall_Appx.cmd" UninstallProvisionedAppx
)

If "%ManufacturerAppxInstall%" == "True" (
	Call "%CD%\Addons\Appx\Install_Appx_%Device%.cmd" ManufacturerAppx 10
)

If "%OperatorAppxInstall%" == "True" (
	Call "%CD%\Addons\Appx\Install_Appx_%Device%.cmd" OperatorAppx 10
)

If "%UninstallBitLocker%" == "True" (
	Call "%CD%\Includes\Uninstall_BitLocker.cmd" UninstallBitLocker
)

If "%UninstallCortana%" == "True" (
	Call "%CD%\Includes\Uninstall_Cortana.cmd" UninstallCortana
)

If "%UninstallDefender%" == "True" (
	Call "%CD%\Includes\Uninstall_Defender.cmd" UninstallDefender
)

If "%Office2013RT_Install%" == "True" (
	Call "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" Office2013RTCopy
)

If "%WinREInInstall%" == "True" (
	copy "%TmpPath%\Updated\winre\winre.wim" "%TmpPath%\Mount\install\Windows\System32\Recovery\winre.wim" 1> nul
)

Call "%CD%\Includes\Mod_Install.cmd" InstallWim
Call "%CD%\Includes\Mod_Install_OOBE.cmd" OOBE
Call "%CD%\Includes\Mod_Install_SetupComplete.cmd" SetupComplete
Call "%CD%\Includes\Mod_Install_Unattend.cmd" Unattend

If "%ActivationBackupScript%" == "True" (
	Call "%CD%\Includes\Mod_ActivationBackup.cmd" WriteActivationBackup 10
)

If "%BuildCustom%" == "True" (
	Call "%CD%\Addons\Custom\Custom.cmd" install
)

Call "%CD%\Includes\Mod_Info_Files.cmd" install 1 mounted

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\install" /Commit

If "%InstallESD%" == "True" (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\install.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\install\install.esd" /Compress:recovery
) else (
	If "%ExportInstallWIM%" == "True" (
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Export-Image /SourceImageFile:"%TmpPath%\Source\install.wim" /SourceIndex:1 /DestinationImageFile:"%TmpPath%\Updated\install\install.wim" /Compress:max
		Del "%TmpPath%\Source\install.wim" /F /Q 1> nul
	) else (
		echo.
		echo %white%Skipping WIM Export%ef%
		Move /y "%TmpPath%\Source\install.wim" "%TmpPath%\Updated\install" 1> nul
	)
)

For /f "USEBACKQ skip=3 tokens=1 delims=. " %%f IN (`""!CD!\Bin\Diruse\DIRUSE.EXE" /m "!TmpPath!\Updated\install\""`) DO (
	Set /a InstallWimDirSize=%%f
)


If "%SkipWIMSplit%" == "True" goto SkipWIMSplit

If %InstallWimDirSize% GEQ 4096 (
	If "%InstallESD%" == "True" (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Split-Image /ImageFile:"%TmpPath%\Updated\install\install.esd" /SWMFile:"%TmpPath%\Updated\install\install.swm" /FileSize:4096
	) else (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Split-Image /ImageFile:"%TmpPath%\Updated\install\install.wim" /SWMFile:"%TmpPath%\Updated\install\install.swm" /FileSize:4096
	)
	Set WimSplit=True
rem	Set WimFAT32Warning=True
)

:SkipWIMSplit

Call "%CD%\Includes\Mod_Info_Files.cmd" install 1 unmounted

If "%WimSplit%" == "True" (
	Del "%TmpPath%\Updated\install\install.wim" /F /Q
)

REM ====== Copy info files =============================================================================================================================================

Call "%CD%\Includes\Mod_Info_Files.cmd" infowrite 0 mediabuilder

REM ====== Output ======================================================================================================================================================

If "%CustomOutput%" == "True" (
	Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" CustomOutput
	goto Timer
)

If "%SetupMode%" == "Setup" (

	Set MediaFolderOutputPath=!OutputPath!
	If not exist "!MediaFolderOutputPath!" Md "!MediaFolderOutputPath!" 1> nul

	Move /y "!TmpPath!\Updated\boot\boot.wim" "%MediaFolderPath%\sources" 1> nul
	Move /y "!TmpPath!\Updated\install\*.*" "%MediaFolderPath%\sources" 1> nul

	If "%SameDrv%" == "True" (
		Move /y "%MediaFolderPath%" "!MediaFolderOutputPath!" 1> nul
		Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%
	) else (
		Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%
		"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%" "!MediaFolderOutputPath!" 1> nul
	)

)

If "%SetupMode%" == "WinRE" (

	Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%
	If not exist "!MediaFolderOutputPath!" Md "!MediaFolderOutputPath!" 1> nul

	Move /y "!TmpPath!\Updated\winre\winre.wim" "%MediaFolderPath%\sources\boot.wim" 1> nul
	Move /y "!TmpPath!\Updated\install\*.*" "%MediaFolderPath%\sources" 1> nul

	Call "!CD!\Includes\Mod_WinRe_Config_Files.cmd" ConfigFiles

	Md "!MediaFolderOutputPath!\sources" 1> nul

	If "%SameDrv%" == "True" (
		Move /y "%MediaFolderPath%\boot" "!MediaFolderOutputPath!" 1> nul
		Move /y "%MediaFolderPath%\efi" "!MediaFolderOutputPath!" 1> nul
		Move /y "%MediaFolderPath%\logs" "!MediaFolderOutputPath!" 1> nul
	) else (
		"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%\boot" "!MediaFolderOutputPath!\boot" 1> nul
		"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%\efi" "!MediaFolderOutputPath!\efi" 1> nul
		"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%\logs" "!MediaFolderOutputPath!\logs" 1> nul
	)

	For %%a in (esd swm wim) do (
		If Exist "%MediaFolderPath%\sources\*.%%a" Move /y "%MediaFolderPath%\sources\*.%%a" "!MediaFolderOutputPath!\sources" 1> nul
	)

	Move /y "%MediaFolderPath%\sources\CreatePartitions-UEFI.txt" "!MediaFolderOutputPath!\sources" 1> nul
	Move /y "%MediaFolderPath%\sources\ResetConfig.xml" "!MediaFolderOutputPath!\sources" 1> nul

	Move /y "%MediaFolderPath%\bootmgr.efi" "!MediaFolderOutputPath!" 1> nul
rem	Move /y "%MediaFolderPath%\*.txt" "!MediaFolderOutputPath!" 1> nul

)

If "%SetupMode%" == "WimOnly" (

	Set MediaFolderOutputPath=!OutputPath!\%MediaFolderName%
	If not exist "!MediaFolderOutputPath!" Md "!MediaFolderOutputPath!" 1> nul

	If "%SameDrv%" == "True" (
		Move /y "%MediaFolderPath%\logs" "!MediaFolderOutputPath!" 1> nul
	) else (
		"%SystemRoot%\System32\xcopy.exe" /I /E "%MediaFolderPath%\logs" "!MediaFolderOutputPath!\logs" 1> nul
	)

	Move /y "!TmpPath!\Updated\boot\boot.wim" "!MediaFolderOutputPath!" 1> nul
	Move /y "!TmpPath!\Updated\install\*.*" "!MediaFolderOutputPath!" 1> nul

	If "%WinREInInstall%" == "False" (
		Move /y "!TmpPath!\Updated\winre\winre.wim" "!MediaFolderOutputPath!" 1> nul
	)

rem	Move /y "%MediaFolderPath%\*.txt" "!MediaFolderOutputPath!" 1> nul

	rem goto OpenFolderSelect

)

If "%SetupMode%" == "WinRE9600" Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600SetupMode

REM ====== Timer =======================================================================================================================================================

:Timer

Set "endTime=%time: =0%"
Set "end=!endTime:%time:~8,1%=%%100)*100+1!"  &  set "start=!startTime:%time:~8,1%=%%100)*100+1!"
Set /A "elap=((((10!end:%time:~2,1%=%%100)*60+1!%%100)-((((10!start:%time:~2,1%=%%100)*60+1!%%100), elap-=(elap>>31)*24*60*60*100"
Set /A "cc=elap%%100+100,elap/=100,ss=elap%%60+100,elap/=60,mm=elap%%60+100,hh=elap/60+100"
Set RunTime=%hh:~1%%time:~2,1%%mm:~1%%time:~2,1%%ss:~1%

If not "%MBInfoLink%" == "True" goto SkipMBInfoLink

Set MBInfoFile=%temp%\mb_%random%_%random%_%random%
"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -O "%MBInfoFile%.tmp" %MediaBuilderInfoURL% -nc --timeout=2 --read-timeout=2 --tries=2 --no-check-certificate -q --show-progress --progress=bar:force:noscroll >nul 2>&1
If exist "%MBInfoFile%.tmp" %systemroot%\System32\certutil.exe -f -decode "%MBInfoFile%.tmp" "%MBInfoFile%.cmd" >nul 2>&1
If exist "%MBInfoFile%.cmd" call "%MBInfoFile%.cmd" >nul 2>&1

:SkipMBInfoLink

If "%CustomOutput%" == "True" goto OpenFolderSelect

REM ====== Media =======================================================================================================================================================

If exist "%CD%\Includes\Mod_Media.cmd" (
	Call "%CD%\Includes\Mod_Media.cmd" MediaMenu %MediaLabel% "%MediaFolderOutputPath%"
)

If exist "%CD%\Includes\Mod_WinToGo.cmd" (
	Call "%CD%\Includes\Mod_WinToGo.cmd" WinToGoMenu "%MediaFolderOutputPath%" 10
)

REM ====== Open output folder ==========================================================================================================================================

:OpenFolderSelect
echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
rem echo Installation files are located at:
If /i "%Name%" == "None" (
echo %SetupModeDesc% files are located at:
) else (
echo %Name% %SetupModeDesc% files are located at:
)
echo "%MediaFolderOutputPath%"
echo.
Set /p OpenFolderPrompt=Would you like to open this folder (Y/N)? 
If /i "%OpenFolderPrompt%"=="Y" Set OpenFolder=True
If /i "%OpenFolderPrompt%"=="N" Set OpenFolder=False
If "%OpenFolder%" == "" goto OpenFolderSelect

If "%OpenFolder%" == "True" (
	explorer.exe "%MediaFolderOutputPath%"
)

REM ====== Return to Menu ==============================================================================================================================================

:ReturnMainMenu
If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)
echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%All Done - Returning to Main Menu...%ef%
echo.
pause
cls
rem endlocal & Set "SkipDriveCheckInt=True" & goto Start
endlocal & Set "SkipDriveCheckInt=" & goto Start

REM ====== Done / Cleanup ==============================================================================================================================================

:Exit

If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	attrib -s -h -r /s /d "%TmpPath%\*.*" > NUL 2>&1
	del "%TmpPath%\*.*" /F /Q /S > NUL 2>&1
	rmdir /Q /S "%TmpPath%\" > NUL 2>&1
)

:ExitNoTempClear
If "%MBInfoLink%" == "True" If exist "%MBInfoFile%_2.cmd" call "%MBInfoFile%_2.cmd" >nul 2>&1
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Echo Goodbye^^!
Pause
Exit