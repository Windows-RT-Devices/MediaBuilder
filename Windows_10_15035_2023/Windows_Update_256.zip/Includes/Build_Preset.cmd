@echo off

REM ====== Set =========================================================================================================================================================

Set PresetStage=%1

If "%PresetStage%" == "" (
	goto PresetComplete
) else (
	If not exist "!CD!\Config" md "!CD!\Config" 1> nul
	Set PresetConfig=!CD!\Config\Build_Preset.cfg
	Attrib -r -s -h "!PresetConfig!" 1> nul
	goto %PresetStage%
)

REM ====== Menu Items ==================================================================================================================================================

:MenuItemsDesc

If "%FoundPreset%" == "True" (
	Set FoundPresetText=Existing preset will be overwritten.
)

	echo.
	echo %White%Preset Mode:%ef%	 Create a preset configuration by selecting your options below.

If "%FoundPreset%" == "True" (
	echo.
	echo			 %red%%FoundPresetText%%ef%
)

goto PresetComplete

REM ====== Menu Items ==================================================================================================================================================

:MenuItemsPreset

		echo.
		echo %white%Options:%ef%	 C: Create Preset			%ExistingMedia%
		If "%FoundPreset%" == "True" (
			If "%SHA1Check%" == "True" (
			echo			 D: Download ^& Verify Files Only	%SettingsText%
			) else (
			echo			 D: Download Files Only			%SettingsText%
			)
			echo			 B: Build Preset			%MiscText%
		) else (
			echo								%SettingsText%
			echo								%MiscText%
		)

goto PresetComplete

REM ====== Find / Verify Preset ========================================================================================================================================

:FindPreset

REM Need to add verification.

If exist "%PresetConfig%" (
	Set FoundPreset=True
) else (
	Set FoundPreset=False
	Set ReadPreset=False
	Set DownloadPreset=False
	Set BuildPreset=False
)

goto PresetComplete

REM ====== Save Preset ===============================================================================================================================================

:SavePreset

Set CreatePreset=False

If exist "%PresetConfig%" (
	attrib -s -h -r "%PresetConfig%" 1> nul
	del "%PresetConfig%" /F /Q 1> nul
)

(
	echo ###### Created by %~nx0 ######
) > "%PresetConfig%"

For %%a in (
	"Target=%Target%"
	"UpdateAppx=%UpdateAppx%"
	"UninstallAppx=%UninstallAppx%"
	"ManufacturerAppxInstall=%ManufacturerAppxInstall%"
	"OperatorAppxInstall=%OperatorAppxInstall%"
	"AppxCustomInstall=%AppxCustomInstall%"
	"Office2013RT_Install=%Office2013RT_Install%"
	"BuildCustom=%BuildCustom%"
	"SetupModeSelection=%SetupModeSelection%"
	"WinREInInstall=%WinREInInstall%"
	"InstallESD=%InstallESD%"
	"AppxModeSelection=%AppxModeSelection%"
	"UninstallBitLocker=%UninstallBitLocker%"
	"UninstallCortana=%UninstallCortana%"
	"UninstallDefender=%UninstallDefender%"
	"Office2013RT_SelectedLanguage=%Office2013RT_SelectedLanguage%"
	"Office2013RT_UpdateModeSelect=%Office2013RT_UpdateModeSelect%"
	"ActLink=%ActLink%"
) do (
	For /f "tokens=1-2 delims==" %%a in (%%a) do (
		(
			echo %%a=%%b
		) >> "%PresetConfig%"
		Set %%a=
	)
)

goto PresetComplete

REM ====== Read Preset =================================================================================================================================================

:ReadPreset

If exist "%PresetConfig%" (
	Set ReadPreset=True
	For /f "usebackq skip=1 tokens=*" %%a in ("%PresetConfig%") do (

		For /f "tokens=1-2 delims==" %%a in ("%%a") do (
			Set "%%a=%%b"
		)
	)
) else (
	Set FoundPreset=False
	Set ReadPreset=False
	Set DownloadPreset=False
	Set BuildPreset=False
)

goto PresetComplete

REM ====== Create Preset ===============================================================================================================================================

:CreatePreset

Set CreatePreset=True

goto PresetComplete

REM ====== Create Preset Info ========================================================================================================================================

:CreatePresetInfo

Set ConfirmPromptText= - Save Preset Only

goto PresetComplete

REM ====== Create Preset Complete ====================================================================================================================================

:CreatePresetComplete

Set CreatePreset=False

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo Preset Created
pause
cls

goto PresetComplete

REM ====== Build Preset ===============================================================================================================================================

:BuildPreset

If not "%CreatePreset%" == "True" (
	Set BuildPreset=True
	goto ReadPreset
)

goto PresetComplete

REM ====== Build Preset Info ========================================================================================================================================

:BuildPresetInfo

Set ConfirmPromptText= - Build Preset

goto PresetComplete

REM ====== Download Preset =============================================================================================================================================

:DownloadPreset

If not "%CreatePreset%" == "True" (
	Set DownloadPreset=True
	goto ReadPreset
)

goto PresetComplete

REM ====== Download Preset Info ========================================================================================================================================

:DownloadPresetInfo

If "%SHA1Check%" == "True" (
	Set ConfirmPromptText= - Download ^^^& Verify Files Only
) else (
	Set ConfirmPromptText= - Download Files Only
)

goto PresetComplete

REM ====== Download Preset Complete ====================================================================================================================================

:DownloadPresetComplete

Set DownloadPreset=False
Set ReadPreset=False

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo Preset Download Complete
pause
cls

goto PresetComplete

REM ====== End =========================================================================================================================================================

:PresetComplete

If "%PresetStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "PresetStage="