@echo off

REM ====== Write Info Files ============================================================================================================================================

rem InfoStage = boot, winre, install, infopreview, infowrite
rem Index = WIM index - 1, 2 etc.
rem InfoMode = mounted, unmounted, mediabuilder

Set InfoStage=%1
Set Index=%2
Set InfoMode=%3

If "%InfoMode%" == "" (
	goto InfoComplete
) else (
	If not "%InfoMode%" == "mediabuilder" (
		echo.
		If "%InfoStage%" == "install" (
			If "%InstallESD%" == "True" (
				echo %white%Saving Info File ^(%InfoStage%.esd - index:%Index% - %InfoMode%^).%ef%
			) else (
				echo %white%Saving Info File ^(%InfoStage%.wim - index:%Index% - %InfoMode%^).%ef%
			)
		) else (
			echo %white%Saving Info File ^(%InfoStage%.wim - index:%Index% - %InfoMode%^).%ef%
		)
		echo Please wait...
	)
	goto %InfoMode%
)

REM ====== WIM Mounted =================================================================================================================================================

:mounted

(
	echo === Drivers ==========================================================================================================================================
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\%InfoStage%" /Get-Drivers /Format:Table
	echo.
	echo === Windows Packages =================================================================================================================================
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\%InfoStage%" /Get-Packages /Format:Table
	echo.
	If "%InfoStage%" == "install" (
		echo === Apps =============================================================================================================================================
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\%InfoStage%" /Get-ProvisionedAppxPackages /Format:Table
		echo.
	)
) > "%TmpPath%\Updated\%InfoStage%_%Index%_%InfoMode%.txt"

copy "%TmpPath%\Mount\%InfoStage%\Windows\INF\setupapi.offline.log" "%TmpPath%\logs\Log-setupapi.offline.%InfoStage%.%Index%.txt" /b 1> nul

goto InfoComplete

REM ====== WIM Unmounted ===============================================================================================================================================

:unmounted

(
	echo === WIM Information ==================================================================================================================================
	If "%InfoStage%" == "winre" If "%WinREInInstall%" == "True" (
		echo.
		If "%CustomSetup%" == "True" (
		echo This file is located in "\Windows\System32\Recovery\winre.wim".
		) else (
		If "%InstallESD%" == "True" (
		echo This file is contained within "install.esd" in "\Windows\System32\Recovery\winre.wim".
		) else (
		echo This file is contained within "install.wim" in "\Windows\System32\Recovery\winre.wim".
		)
		)
	)

	If "%InfoStage%" == "winre9600" If "%SetupMode%" == "WinRE9600" Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600InfoUnmounted

	If "%SetupMode%" == "WinRE" If "%InfoStage%" == "winre" (
		If not "%CustomSetup%" == "True" (
		echo.
		echo This file was originally named "winre.wim" and has been renamed to "boot.wim".
		)
	)
	If "%WimSplit%" == "True"  If "%InfoStage%" == "install" (
		echo.
		echo This file was originally named "install.wim", due to FAT32 file size limitations it has been renamed and split to the following files:
		dir /b "%TmpPath%\Updated\%InfoStage%\*.swm"
	)

	If "%InfoStage%" == "install" (
		If "%InstallESD%" == "True" (
			start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Get-ImageInfo /imagefile:"%TmpPath%\Updated\%InfoStage%\%InfoStage%.esd" /Index:%Index% /Format:Table
		) else (
			start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Get-ImageInfo /imagefile:"%TmpPath%\Updated\%InfoStage%\%InfoStage%.wim" /Index:%Index% /Format:Table
		)
	) else (
		start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Get-ImageInfo /imagefile:"%TmpPath%\Updated\%InfoStage%\%InfoStage%.wim" /Index:%Index% /Format:Table
	)
	echo.
) > "%TmpPath%\Updated\%InfoStage%_%Index%_%InfoMode%.txt"

goto InfoComplete

REM ====== Mod Kit Info Output =========================================================================================================================================

:mediabuilder

If "%InfoStage%" == "infopreview" (
	Set Tab=	
	goto Preview
) else (
	Set Tab=
)

(
	:Preview
	If not "!CustomInfo!" == "" Set CustomInfo1=!CustomInfo:TABSTR=%Tab%!
	If "%InfoStage%" == "infowrite" (
		echo === Media Information ================================================================================================================================
		echo.
		echo %MBName% %MBVer%
		If "%InfoStage%" == "infowrite" (
		echo Windows Download List: %WindowsUpdateListsUpdated%
		)
		If "%InfoStage%" == "infowrite" If "%Office2013RT_Install%" == "True" (
		echo Office Download List: %Office2013RT_UpdatedLast%
		)
		echo.
	)
	echo %Tab%Device: %Name%
	If "%CustomSetup%" == "True" (
		echo %Tab%Setup Mode: %SetupModeDesc%
	) else (
	If not "%SetupMode%" == "WimOnly" (
		echo %Tab%Setup Mode: %SetupModeDesc% ^(%InstallFormat%^)
	)
	If "%SetupMode%" == "WimOnly" (
		echo %Tab%Setup Mode: %SetupModeDesc% - %SetupModeDescNote%
	)
	)
	If "%InfoStage%" == "infowrite" (
		echo %Tab%Creation Date: %Date1%
		echo %Tab%Creation Time: %Time1%
		echo %Tab%Source: %Windows_FileName%
	)
	If not "%AppxFileMissing%" == "True" If exist "%CD%\Addons\Appx\Install_Appx.cmd" (
		echo %Tab%Install App Pack%AppxUpdateLevel%: %UpdateAppx%
	)
	If not "%UpdateAppx%" == "True" If exist "%CD%\Includes\Uninstall_Appx.cmd" (
		echo %Tab%Uninstall Provisioned Apps: %UninstallAppx%
	)

	If "%DeviceApps%" == "True" (

		If not "%DeviceAppxFileMissing%" == "True" If "%ManufacturerAppxInstall%" == "True" (
			echo %Tab%Install !Manufacturer! App Pack: %ManufacturerAppxInstall%
		)

		If not "%DeviceAppxFileMissing%" == "True" If "%OperatorAppxInstall%" == "True" (
			echo %Tab%Install !OperatorName! App Pack: %OperatorAppxInstall%
		)

	)

	If exist "%CD%\Includes\Uninstall_BitLocker.cmd" (
		echo %Tab%Uninstall BitLocker: %UninstallBitLocker%
	)
	If exist "%CD%\Includes\Uninstall_Cortana.cmd" (
		echo %Tab%Uninstall Cortana: %UninstallCortana%
	)
	If exist "%CD%\Includes\Uninstall_Defender.cmd" (
		echo %Tab%Uninstall Windows Defender: %UninstallDefender%
	)
	If exist "%CD%\Includes\Mod_Install_SetupComplete_Activation.cmd" (
		If "%ActLink%" == "True" (
			echo %Tab%!WindowsActInfoText! ^(!WindowsActTypText!!WindowsActTypText1!^): %ActLink%
		) else (
			echo %Tab%Set Windows Product Key/Activate Windows: %ActLink%
		)
	)
	If not "%Office2013RT_FileMissing%" == "True" If exist "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" (
		If "%Office2013RT_Install%" == "False" (
			echo %Tab%Install Office 2013 RT Home ^& Student Plus%Office2013RT_UpdateDescription%: %Office2013RT_Install%
		) else (
			echo %Tab%Install Office 2013 RT Home ^& Student Plus ^(%Office2013RT_LP_Language%^)%Office2013RT_UpdateDescription%: %Office2013RT_Install%
			If "%InfoStage%" == "infowrite" (
				echo %Tab%Office Activation Script Type: %OfficeActTypText%
			)
		)
	)
	If not "!CustomInfo1!" == "" echo !CustomInfo1!
	If "%CustomAddon%" == "True" If exist "%CD%\Addons\Custom\Custom.cmd" (
		echo %Tab%Custom Commands: %BuildCustom%
	)
	echo.
	If "%InfoStage%" == "infopreview" goto InfoComplete
) > "%TmpPath%\Updated\info.txt"

If not exist "%MediaFolderPath%\logs" md "%MediaFolderPath%\logs" 1> nul

If not "%SetupMode%" == "WinRE" (
	copy "%TmpPath%\Updated\boot_1_unmounted.txt"+"%TmpPath%\Updated\boot_1_mounted.txt"+"%TmpPath%\Updated\boot_2_unmounted.txt"+"%TmpPath%\Updated\boot_2_mounted.txt" "%MediaFolderPath%\logs\Info-Boot.txt" /b 1> nul
)

copy "%TmpPath%\Updated\install_1_unmounted.txt"+"%TmpPath%\Updated\install_1_mounted.txt" "%MediaFolderPath%\logs\Info-Install.txt" /b 1> nul

If "%SetupMode%" == "WinRE" (
	copy "%TmpPath%\Updated\winre_1_unmounted.txt"+"%TmpPath%\Updated\winre_1_mounted.txt" "%MediaFolderPath%\logs\Info-Boot.txt" /b 1> nul
) else (
	copy "%TmpPath%\Updated\winre_1_unmounted.txt"+"%TmpPath%\Updated\winre_1_mounted.txt" "%MediaFolderPath%\logs\Info-WinRe.txt" /b 1> nul
)

If "%SetupMode%" == "WinRE9600" (
	Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600InfoOutput
)

(
	echo === System Info ======================================================================================================================================
	"%systemroot%\System32\systeminfo.exe"
	echo.
	echo === Tasklist =========================================================================================================================================
	"%systemroot%\System32\tasklist.exe" /svc
) > "%TmpPath%\logs\Log-Host.txt"

copy "%TmpPath%\Updated\info.txt" "%MediaFolderPath%\logs\Info.txt" /b 1> nul

If exist "%DISMLogPath%\%DISMLogCurrent%.bak" (
	rename "%DISMLogPath%\%DISMLogCurrent%.bak" "Log-DISM-0.!DISMLogFileExt!"
	rename "%DISMLogPath%\%DISMLogCurrent%" "Log-DISM-1.!DISMLogFileExt!"
	copy "%DISMLogPath%\Log-DISM-0.!DISMLogFileExt!"+"%DISMLogPath%\Log-DISM-1.!DISMLogFileExt!" "%DISMLogPath%\%DISMLogFile%.!DISMLogFileExt!" /b 1> nul
	del "%DISMLogPath%\Log-DISM-0.!DISMLogFileExt!" /q 1> nul
	del "%DISMLogPath%\Log-DISM-1.!DISMLogFileExt!" /q 1> nul
	rename "%DISMLogPath%\%DISMLogFile%.!DISMLogFileExt!" "%DISMLogCurrent%"
)

copy "%DISMLogPath%\%DISMLogCurrent%" "%MediaFolderPath%\logs\%DISMLogFile%.!DISMLogFileExt!" /b 1> nul
rename "%DISMLogPath%\%DISMLogCurrent%" "!MediaFolderName!.!DISMLogFileExt!"

copy "%TmpPath%\logs\*.*" "%MediaFolderPath%\logs\" /b 1> nul

del "%TmpPath%\Updated\*.txt" /q 1> nul

goto InfoComplete

REM ====== End =========================================================================================================================================================

:InfoComplete

If "%InfoStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "InfoStage="
Set "Index="
Set "InfoMode="