@echo off

REM ====== Set =========================================================================================================================================================

Set Install_SiPolicyStage=%1

If "%Install_SiPolicyStage%" == "" (
	goto Install_SiPolicyComplete
) else (
	Set Install_SiPolicySource=!CD!\Addons\SiPolicy
	Set Install_SiPolicyDest=!TmpPath!\Mount\install
	goto %Install_SiPolicyStage%
)

REM ====== Install_SiPolicy Options ======================================================================================================================================

:Install_SiPolicyMenu

For %%a in (
	"%Install_SiPolicySource%\SiPolicy_Audit\SiPolicy_Audit.inf"
	"%Install_SiPolicySource%\SiPolicy_Audit\SiPolicy.p7b"
) do (
	If not exist %%a (
		Set SiPolicyFileMissing=True
		Set Install_SiPolicy=False
		goto Install_SiPolicyComplete
	)
)

:Install_SiPolicy_AuditSelect
If "!ReadPreset!" == "True" goto Install_SiPolicyComplete
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p Install_SiPolicyPrompt=Would you like to install the Audit Mode Policy (SiPolicy_Audit.p7b) (Y/N)? 
If /i "%Install_SiPolicyPrompt%"=="Y" Set Install_SiPolicy_Audit=True
If /i "%Install_SiPolicyPrompt%"=="N" Set Install_SiPolicy_Audit=False
If "%Install_SiPolicyPrompt%" == "" goto Install_SiPolicy_AuditSelect

If /i "%Install_SiPolicy_Audit%" == "True" (
	Set Install_SiPolicy=True
	goto Install_SiPolicyComplete
)

goto Install_SiPolicyComplete

REM ====== Install Install_SiPolicy ======================================================================================================================================

:Install_SiPolicy

If /i "%Install_SiPolicy_Audit%" == "True" (
	echo.
	echo %white%Installing Audit Mode Policy ^(SiPolicy_Audit.p7b^).%ef%

	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%Install_SiPolicyDest%" /Add-Driver /Driver:"%Install_SiPolicySource%\SiPolicy_Audit" /Recurse
	echo.
	If "!ErrorLevel!" NEQ "0" (
		echo %red%Error Installing Audit Mode Policy.%ef%
		echo %red%DISM Error: !ErrorLevel!%ef%
	) else (
		echo %green%Audit Mode Policy Installed.%ef%
	)
)

goto Install_SiPolicyComplete

REM ====== End =========================================================================================================================================================

:Install_SiPolicyComplete

If "%Install_SiPolicyStage%" == "" (
	echo This file is an addon for the Windows 10 Build 15035 Media Builder.
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "Install_SiPolicyStage="