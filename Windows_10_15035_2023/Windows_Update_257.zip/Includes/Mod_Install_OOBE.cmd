@echo off

REM ====== Set =========================================================================================================================================================

Set InstallOOBEStage=%1

If "%InstallOOBEStage%" == "" (
	goto OOBEComplete
) else (
	goto %InstallOOBEStage%
)

:OOBE

REM ====== Write OOBE.cmd ==============================================================================================================================================

echo.
echo %white%Installing OOBE.cmd.%ef%

For %%a in (
	"%TmpPath%\Mount\install\Windows\Setup\Scripts\"
	"%TmpPath%\Inf\OOBE"
) do (
	If not exist %%a md %%a 1> nul
)

If Exist "%TmpPath%\LayoutModification.xml" (
	Move /y "%TmpPath%\LayoutModification.xml" "%TmpPath%\Inf\OOBE\" 1> nul
	Set LayoutModification=True
)

(
	echo ;
	echo ; OOBE.inf
	echo ;
	echo.
	echo [Version]
	echo Signature   = "$Windows NT$"
	echo Class       = System
	echo ClassGuid   = {4d36e97d-e325-11ce-bfc1-08002be10318}
	echo Provider    = %%IHV%%
	echo DriverVer   = 05/25/2021,1.0.0.0000
	echo.
	echo [DestinationDirs]
	echo ; 10 = Windows
	echo ; 11 = System32
	echo ; 24 = System Disk Root
	echo OOBE.Files = 10,Setup\Scripts
	If "%LayoutModification%"=="True" (
		echo Start_LayoutModification.Files = 24,Users\Default\AppData\Local\Microsoft\Windows\Shell
	)
	echo.
	echo [SourceDisksNames]
	echo 0 = %%DiskId1%%
	echo.
	echo [SourceDisksFiles]
	echo OOBE.cmd = 0,,
	If "%LayoutModification%"=="True" (
		echo LayoutModification.xml = 0,,
	)
	echo.
	echo ;*****************************************
	echo ; OOBE Install Section
	echo ;*****************************************
	echo.
	echo [DefaultInstall.NTarm]
	echo Addreg = System_EnableLUA
	echo Addreg = MemoryManagement_PagingFiles
	echo CopyFiles = OOBE.Files
	If "%LayoutModification%"=="True" (	
		echo CopyFiles = Start_LayoutModification.Files
	)
	echo.
	echo [System_EnableLUA]
	echo HKLM, "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", "EnableLUA", 0x10001, 0x0
	echo.
	echo [MemoryManagement_PagingFiles]
	echo HKLM, "SYSTEM\ControlSet001\Control\Session Manager\Memory Management", "PagingFiles", 0x10000, "?:\pagefile.sys 256 1024"
	echo.
	echo [OOBE.Files]
	echo OOBE.cmd
	echo.
	If "%LayoutModification%"=="True" (
		echo [Start_LayoutModification.Files]
		echo LayoutModification.xml
	echo.
	)
	echo [Strings]
	echo IHV     = "Media Builder"
	echo DiskId1 = "Media Builder OOBE"
) > "%TmpPath%\Inf\OOBE\OOBE.inf"

(
	echo @echo off
	echo @setlocal enableextensions
	echo echo.
	echo REM ====== Hide Expired Build Nag ======================================================================================================================================
	echo "%%SystemRoot%%\system32\takeown.exe" /F "%%%^%SystemRoot%%%^%\system32\LicensingUI.exe"
	echo "%%SystemRoot%%\system32\icacls.exe" "%%%^%SystemRoot%%%^%\system32\LicensingUI.exe" /grant *S-1-5-32-545:F
	echo rename "%%%^%SystemRoot%%%^%\system32\LicensingUI.exe" "LicensingUI.awj"
	echo echo.
	echo REM ====== Enable Windows 7 Style Context Menus ^(Avoid double spaced context menu^) =====================================================================================
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\FlightedFeatures" /t REG_DWORD /v ImmersiveContextMenu /d 00000000 /f
	echo echo.
	If "%OnlyUseLatestCLR%" == "True" (
	echo REM ====== Use Latest .Net CLR =========================================================================================================================================
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\SOFTWARE\Microsoft\.NETFramework" /t REG_DWORD /v OnlyUseLatestCLR /d 00000001 /f
	echo echo.
	)
	echo REM ====== Disable Preview Build Notification ==========================================================================================================================
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds" /t REG_DWORD /v AllowBuildPreview /d 00000000 /f
	If not "%Device%" == "Generic" (
		If exist "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" Call "%CD%\Devices\%SoC%\%Device%\%Device%.cmd" OOBE
	)
	If "%AppxRegMod%" == "True" (
		Call "%CD%\Addons\Appx\Install_Appx.cmd" AppxOOBE
	)
	If "%AppxCustomRegMod%" == "True" (
		Call "%CD%\Addons\AppxCustom\Install_AppxCustom.cmd" AppxCustomOOBE
	)
	If "%UninstallCortana%" == "True" (
		Call "%CD%\Includes\Uninstall_Cortana.cmd" UninstallCortanaOOBE
	)
	If "%UninstallDefender%" == "True" (
		Call "%CD%\Includes\Uninstall_Defender.cmd" UninstallDefenderOOBE
	)
) > "%TmpPath%\Inf\OOBE\OOBE.cmd"

start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%TmpPath%\Mount\install" /Add-Driver /Driver:"%TmpPath%\Inf\OOBE" /Recurse
echo.
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error Installing OOBE.cmd.%ef%
	echo %red%DISM Error: !ErrorLevel!%ef%
) else (
	echo %green%OOBE.cmd Installed.%ef%
)

REM ====== Entries below would apply to first run only and do not survive "Reset this PC" unlike the entries above.

(
rem	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\Explorer" /V "AsyncRunOnce" /t REG_DWORD /d 0 /f
rem	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\System" /V "EnableFirstLogonAnimation" /t REG_DWORD /d 0 /f
	echo echo.
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx"
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx" /V "Title" /D "Installing..." /f
	echo echo.
	If "%Office2013RT_Install%" == "True" (
		echo REM ====== Office 2013 RT =============================================================================================================================================
		call "%CD%\Addons\Office\Install_Office_2013_RT_HSP.cmd" Office2013RTOOBE
	)
	If "%BuildCustom%" == "True" (
		echo REM ====== Custom OOBE.cmd ============================================================================================================================================
		call "%CD%\Addons\Custom\Custom.cmd" CustomOOBE
	)
	echo del "%%systemdrive%%\Windows\Setup\Scripts\OOBE.cmd"
) >> "%TmpPath%\Mount\install\Windows\Setup\Scripts\OOBE.cmd"

goto OOBEComplete

REM ====== End =========================================================================================================================================================

:OOBEComplete

If "%InstallOOBEStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "InstallOOBEStage="