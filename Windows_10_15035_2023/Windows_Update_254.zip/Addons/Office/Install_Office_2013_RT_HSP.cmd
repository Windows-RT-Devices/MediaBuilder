@echo off

Set Office2013RT_Source=!CD!\Addons\Office
Set Office2013RT_Destination=!TmpPath!\Mount\install

Set Office2013RT_DownloadLists=!Office2013RT_Source!\Download_Lists
Set Office2013RT_Downloads=!DownloadsPath!\Office

Set Office2013RT_Installer=Office_2013_RT_HSP_Installer.txt
Set Office2013RT_LanguagePacks=Office_2013_RT_HSP_Language_Packs.txt

If "%AltOfficeActivation%" == "True" (
Set Office2013RT_XrMLZip=AltXrML.zip
Set Office2013RT_XrMLZipSHA1=8888a6ab7d5bf8e8b51ed0ee0442cafd5d3bf9d3
) else (
Set Office2013RT_XrMLZip=XrML.zip
Set Office2013RT_XrMLZipSHA1=8e43f5d362928bcef44d20611a908ce80496b833
)

Set Office2013RT_UpdateTmp=!TmpPath!\Office\Updates
Set Office2013RT_UpdateListTmp=!TmpPath!\Office\UpdateList

REM ====== Set =========================================================================================================================================================

Set OfficeStage=%1

If "%OfficeStage%" == "" (
	goto Office2013RTComplete
) else (
	goto %OfficeStage%
)

REM ====== Office Options Menu==========================================================================================================================================

:Office2013RTMenu

If "%AltOfficeActivation%" == "True" (
	Set OfficeActTypText=Retail
) else (
	Set OfficeActTypText=GVLK
)

For %%a in (
	"%Office2013RT_Source%\XrML\%Office2013RT_XrMLZip%"
	"%Office2013RT_DownloadLists%\%Office2013RT_Installer%"
	"%Office2013RT_DownloadLists%\%Office2013RT_LanguagePacks%"
) do (
	If not exist %%a (
		goto Office2013RTError
	)
)

cls

:Office2013RT_InstallSelect

If "!ReadPreset!" == "True" (
	If "%Office2013RT_Install%" == "True" (
		Set Office2013RT_Prompt=Y
	) else (
		Set Office2013RT_Prompt=N
	)
	Goto SkipOfficePrompt
)

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.

Set /p Office2013RT_Prompt=Would you like to install Office 2013 RT Home ^& Student Plus (Y/N)? 
:SkipOfficePrompt
If /i "%Office2013RT_Prompt%"=="Y" Set Office2013RT_Install=True
If /i "%Office2013RT_Prompt%"=="N" (
	Set Office2013RT_Install=False
	Goto Office2013RTComplete
)
If "%Office2013RT_Install%" == "" goto Office2013RT_InstallSelect

rem Set /p OfficeDownloadList=< "%Office2013RT_DownloadLists%\%Office2013RT_Installer%"

rem For /f "tokens=1,2,3,4 delims=#" %%a in ("%OfficeDownloadList%") do (
rem 		Set Office2013RT_Installer_URL=%%a
rem 		Set Office2013RT_Installer_FileName=%%~NXa
rem 		Set Office2013RT_Installer_SHA1=%%c
rem 		Set Office2013RT_Installer_Torrent=%%b
rem 		Set Office2013RT_Installer_TorrentFileName=%%~NXb
rem 		Set Office2013RT_Installer_TorrentDir=!Office2013RT_Installer_TorrentFileName:_archive.torrent=!
rem 		Set Office2013RT_Installer_Source=%%d
rem )

Set FindLanguage=ms-MY
Set OfficeDownloadList="%Office2013RT_DownloadLists%\%Office2013RT_Installer%"

For /F "usebackq tokens=* skip=1" %%a in (%OfficeDownloadList%) do (
	For /f "tokens=1-19 delims=," %%a in ("%%a") do (
		If /i "%%a" == "%FindLanguage%" (
			Set Office2013RT_Installer_Tag=%%a
			Set Office2013RT_Installer_Language=%%b
			Set Office2013RT_Installer_Country=%%c
			Set Office2013RT_Installer_LCID=%%d
			Set Office2013RT_Installer_UNUSED1=%%e
			Set Office2013RT_Installer_UNUSED2=%%f

			If /i "!OfficeForceAltDownload!" == "True" (

				Set Office2013RT_Installer_HTTPSourceName=%%n
				Set Office2013RT_Installer_URL=%%o
				Set Office2013RT_Installer_FileName=%%~NXo

				Set Office2013RT_Installer_TorrentSourceName=%%p
				Set Office2013RT_Installer_TorrentURL=%%q
				Set Office2013RT_Installer_TorrentFileName=%%~NXq
				Set Office2013RT_Installer_TorrentDir=!Office2013RT_Installer_TorrentFileName:_archive.torrent=!
				Set Office2013RT_Installer_TorrentM=%%r
				Set Office2013RT_Installer_TorrentIndex=%%s

			) else (

				Set Office2013RT_Installer_HTTPSourceName=%%g
				Set Office2013RT_Installer_URL=%%h
				Set Office2013RT_Installer_FileName=%%~NXh

				Set Office2013RT_Installer_TorrentSourceName=%%i
				Set Office2013RT_Installer_TorrentURL=%%j
				Set Office2013RT_Installer_TorrentFileName=%%~NXj
				Set Office2013RT_Installer_TorrentDir=!Office2013RT_Installer_TorrentFileName:_archive.torrent=!
				Set Office2013RT_Installer_TorrentM=%%k
				Set Office2013RT_Installer_TorrentIndex=%%l

			)

			Set Office2013RT_Installer_SHA1=%%m

		)
	)
)

If /i "%ArchiveOrgTorrent%" == "True" (
	Set Office2013RT_Installer_Source=!Office2013RT_Installer_TorrentSourceName!
) else (
	Set Office2013RT_Installer_Source=!Office2013RT_Installer_HTTPSourceName!
)

If exist "%CD%\Temp.cmd" Call "%CD%\Temp.cmd" Office2013RT_Installer_List

:Office2013RT_LanguageSelect
If "!ReadPreset!" == "True" goto Office2013RT_UseDefaultLanguage
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p Office2013RT_LanguageSelectPrompt=The default Office language is English, would you like to select another language (Y/N)? 
If /i "%Office2013RT_LanguageSelectPrompt%"=="Y" Goto Office2013RT_LanguageMenuSelect
If /i "%Office2013RT_LanguageSelectPrompt%"=="N" (
	Set Office2013RT_SelectedLanguage=en-US
	Goto Office2013RT_UseDefaultLanguage
)
If "%Office2013RT_Language%" == "" goto Office2013RT_LanguageSelect

:Office2013RT_LanguageMenuSelect
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Select Office Language:%ef%
echo.
echo		 1: Arabic ^(Saudi Arabia^)		15: Hebrew ^(Israel^)		29: Portuguese ^(Portugal^)
echo		 2: Bulgarian ^(Bulgaria^)		16: Hindi ^(India^)		30: Romanian ^(Romania^)
echo		 3: Chinese ^(Peoples Republic of China^)	17: Hungarian ^(Hungary^)		31: Russian ^(Russia^)
echo		 4: Chinese ^(Taiwan^)			18: Indonesian ^(Indonesia^)	32: Serbian ^(Serbia^)
echo		 5: Croatian ^(Croatia^)			19: Italian ^(Italy^)		33: Slovak ^(Slovakia^)
echo		 6: Czech ^(Czech Republic^)		20: Japanese ^(Japan^)		34: Slovenian ^(Slovenia^)
echo		 7: Danish ^(Denmark^)			21: Kazakh ^(Kazakhstan^)		35: Spanish ^(Spain^)
echo		 8: Dutch ^(Netherlands^)			22: Korean ^(Korea^)		36: Swedish ^(Sweden^)
echo		 9: English ^(United States^)		23: Latvian ^(Latvia^)		37: Thai ^(Thailand^)
echo		10: Estonian ^(Estonia^)			24: Lithuanian ^(Lithuania^)	38: Turkish ^(Turkey^)
echo		11: Finnish ^(Finland^)			25: Malay ^(Malaysia^)		39: Ukrainian ^(Ukraine^)
echo		12: French ^(France^)			26: Norwegian ^(Norway^)		40: Vietnamese ^(Vietnam^)
echo		13: German ^(Germany^)			27: Polish ^(Poland^)
echo		14: Greek ^(Greece^)			28: Portuguese ^(Brazil^)		0: %red%Cancel Office Installation%ef%
echo.
Set /p Office2013RT_LanguageMenuSelectPrompt=%white%Select Language: 
echo. %ef%

If "%Office2013RT_LanguageMenuSelectPrompt%"=="1" Set Office2013RT_SelectedLanguage=ar-SA
If "%Office2013RT_LanguageMenuSelectPrompt%"=="2" Set Office2013RT_SelectedLanguage=bg-BG
If "%Office2013RT_LanguageMenuSelectPrompt%"=="3" Set Office2013RT_SelectedLanguage=zh-CN
If "%Office2013RT_LanguageMenuSelectPrompt%"=="4" Set Office2013RT_SelectedLanguage=zh-TW
If "%Office2013RT_LanguageMenuSelectPrompt%"=="5" Set Office2013RT_SelectedLanguage=hr-HR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="6" Set Office2013RT_SelectedLanguage=cs-CZ
If "%Office2013RT_LanguageMenuSelectPrompt%"=="7" Set Office2013RT_SelectedLanguage=da-DK
If "%Office2013RT_LanguageMenuSelectPrompt%"=="8" Set Office2013RT_SelectedLanguage=nl-NL
If "%Office2013RT_LanguageMenuSelectPrompt%"=="9" Set Office2013RT_SelectedLanguage=en-US
If "%Office2013RT_LanguageMenuSelectPrompt%"=="10" Set Office2013RT_SelectedLanguage=et-EE
If "%Office2013RT_LanguageMenuSelectPrompt%"=="11" Set Office2013RT_SelectedLanguage=fi-FI
If "%Office2013RT_LanguageMenuSelectPrompt%"=="12" Set Office2013RT_SelectedLanguage=fr-FR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="13" Set Office2013RT_SelectedLanguage=de-DE
If "%Office2013RT_LanguageMenuSelectPrompt%"=="14" Set Office2013RT_SelectedLanguage=el-GR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="15" Set Office2013RT_SelectedLanguage=he-IL
If "%Office2013RT_LanguageMenuSelectPrompt%"=="16" Set Office2013RT_SelectedLanguage=hi-IN
If "%Office2013RT_LanguageMenuSelectPrompt%"=="17" Set Office2013RT_SelectedLanguage=hu-HU
If "%Office2013RT_LanguageMenuSelectPrompt%"=="18" Set Office2013RT_SelectedLanguage=id-ID
If "%Office2013RT_LanguageMenuSelectPrompt%"=="19" Set Office2013RT_SelectedLanguage=it-IT
If "%Office2013RT_LanguageMenuSelectPrompt%"=="20" Set Office2013RT_SelectedLanguage=ja-JP
If "%Office2013RT_LanguageMenuSelectPrompt%"=="21" Set Office2013RT_SelectedLanguage=kk-KZ
If "%Office2013RT_LanguageMenuSelectPrompt%"=="22" Set Office2013RT_SelectedLanguage=ko-KR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="23" Set Office2013RT_SelectedLanguage=lv-LV
If "%Office2013RT_LanguageMenuSelectPrompt%"=="24" Set Office2013RT_SelectedLanguage=lt-LT
If "%Office2013RT_LanguageMenuSelectPrompt%"=="25" Set Office2013RT_SelectedLanguage=ms-MY
If "%Office2013RT_LanguageMenuSelectPrompt%"=="26" Set Office2013RT_SelectedLanguage=nb-NO
If "%Office2013RT_LanguageMenuSelectPrompt%"=="27" Set Office2013RT_SelectedLanguage=pl-PL
If "%Office2013RT_LanguageMenuSelectPrompt%"=="28" Set Office2013RT_SelectedLanguage=pt-BR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="29" Set Office2013RT_SelectedLanguage=pt-PT
If "%Office2013RT_LanguageMenuSelectPrompt%"=="30" Set Office2013RT_SelectedLanguage=ro-RO
If "%Office2013RT_LanguageMenuSelectPrompt%"=="31" Set Office2013RT_SelectedLanguage=ru-RU
If "%Office2013RT_LanguageMenuSelectPrompt%"=="32" Set Office2013RT_SelectedLanguage=sr-latn-CS
If "%Office2013RT_LanguageMenuSelectPrompt%"=="33" Set Office2013RT_SelectedLanguage=sk-SK
If "%Office2013RT_LanguageMenuSelectPrompt%"=="34" Set Office2013RT_SelectedLanguage=sl-SI
If "%Office2013RT_LanguageMenuSelectPrompt%"=="35" Set Office2013RT_SelectedLanguage=es-ES
If "%Office2013RT_LanguageMenuSelectPrompt%"=="36" Set Office2013RT_SelectedLanguage=sv-SE
If "%Office2013RT_LanguageMenuSelectPrompt%"=="37" Set Office2013RT_SelectedLanguage=th-TH
If "%Office2013RT_LanguageMenuSelectPrompt%"=="38" Set Office2013RT_SelectedLanguage=tr-TR
If "%Office2013RT_LanguageMenuSelectPrompt%"=="39" Set Office2013RT_SelectedLanguage=uk-UA
If "%Office2013RT_LanguageMenuSelectPrompt%"=="40" Set Office2013RT_SelectedLanguage=vi-VN

If "%Office2013RT_LanguageMenuSelectPrompt%"=="0" goto SelectOfficeCancel

If "%Office2013RT_SelectedLanguage%" == "" goto Office2013RT_LanguageMenuSelect

:Office2013RT_UseDefaultLanguage

rem For /F "usebackq tokens=*" %%a in ("%Office2013RT_DownloadLists%\%Office2013RT_LanguagePacks%") do (
rem 	For /f "tokens=1,2,3,4,5,6 delims=#" %%a in ("%%a") do (
rem 		If "%%d" == "%Office2013RT_SelectedLanguage%" (
rem 			Set Office2013RT_LP_Language=%%a
rem 			Set Office2013RT_LP_Country=%%b
rem 			Set Office2013RT_LP_LCID=%%c
rem 			Set Office2013RT_LP_Tag=%%d
rem 			Set Office2013RT_LP_URL=%%e
rem 			Set Office2013RT_LP_FileName=%%~NXe
rem 			For /f "tokens=1-3 delims=_." %%a in ("!Office2013RT_LP_FileName!") do (
rem 				Set Office2013RT_LP_SHA1=%%b
rem 			)
rem 		)
rem 	)
rem )

Set OfficeLPDownloadList="%Office2013RT_DownloadLists%\%Office2013RT_LanguagePacks%"

For /F "usebackq tokens=* skip=1" %%a in (%OfficeLPDownloadList%) do (
	For /f "tokens=1-19 delims=," %%a in ("%%a") do (
		If /i "%%a" == "%Office2013RT_SelectedLanguage%" (
			Set Office2013RT_LP_Tag=%%a
			Set Office2013RT_LP_Language=%%b
			Set Office2013RT_LP_Country=%%c
			Set Office2013RT_LP_LCID=%%d
			Set Office2013RT_LP_UNUSED1=%%e
			Set Office2013RT_LP_AllowLP=%%f

			If /i "!OfficeLangPackForceAltDownload!" == "True" (

				Set Office2013RT_LP_HTTPSourceName=%%n
				Set Office2013RT_LP_URL=%%o
				Set Office2013RT_LP_FileName=%%~NXo
				For /f "tokens=1-3 delims=_." %%a in ("!Office2013RT_LP_FileName!") do (
					Set Office2013RT_LP_SHA1=%%b
				)

				Set Office2013RT_LP_TorrentSourceName=%%p
				Set Office2013RT_LP_TorrentURL=%%q
				Set Office2013RT_LP_TorrentFileName=%%~NXq
				Set Office2013RT_LP_TorrentDir=!Office2013RT_LP_TorrentFileName:_archive.torrent=!
				Set Office2013RT_LP_TorrentM=%%r
				Set Office2013RT_LP_TorrentIndex=%%s

			) else (

				Set Office2013RT_LP_HTTPSourceName=%%g
				Set Office2013RT_LP_URL=%%h
				Set Office2013RT_LP_FileName=%%~NXh
				For /f "tokens=1-3 delims=_." %%a in ("!Office2013RT_LP_FileName!") do (
					Set Office2013RT_LP_SHA1=%%b
				)

				Set Office2013RT_LP_TorrentSourceName=%%i
				Set Office2013RT_LP_TorrentURL=%%j
				Set Office2013RT_LP_TorrentFileName=%%~NXj
				Set Office2013RT_LP_TorrentDir=!Office2013RT_LP_TorrentFileName:_archive.torrent=!
				Set Office2013RT_LP_TorrentM=%%k
				Set Office2013RT_LP_TorrentIndex=%%l

			)

			Set Custom=%%m

		)
	)
)

If /i "%ArchiveOrgTorrent%" == "True" (
	Set Office2013RT_LP_Source=!Office2013RT_LP_TorrentSourceName!
) else (
	Set Office2013RT_LP_Source=!Office2013RT_LP_HTTPSourceName!
)

If exist "%CD%\Temp.cmd" Call "%CD%\Temp.cmd" Office2013RT_LP_List

:Office2013RT_UpdateModeSelect

If exist "%Office2013RT_DownloadLists%\Last_Updated" (
	Set /p Office2013RT_UpdatedLast=< "%Office2013RT_DownloadLists%\Last_Updated"
	For /f "tokens=1-2 delims=#" %%a in ("!Office2013RT_UpdatedLast!") do (
		Set Office2013RT_UpdatedRelease=%%a
		Set Office2013RT_UpdatedLast=%%b
	)
) else (
	Set Office2013RT_UpdatedRelease=Unknown Release
	Set Office2013RT_UpdatedLast=Unknown Date
)


If /i "!OfficeUpdateForceAltDownload!" == "True" Set OfficeUpdateListExt=_Alt


Set Office2013RT_UpdateListSP1Common=Office_2013_RT_HSP_SP1!OfficeUpdateListExt!.txt
Set Office2013RT_UpdateListSP1=%Office2013RT_LP_Tag%\Office_2013_RT_HSP_SP1!OfficeUpdateListExt!.txt

Set Office2013RT_UpdateListPostSP1Common=Office_2013_RT_HSP_Post_SP1!OfficeUpdateListExt!.txt
Set Office2013RT_UpdateListPostSP1=%Office2013RT_LP_Tag%\Office_2013_RT_HSP_Post_SP1!OfficeUpdateListExt!.txt


For %%a in (
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1Common%"
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1%"
) do (
	If not exist %%a Set Office2013RT_NoSP1List=True
)

For %%a in (
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1Common%"
	"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1%"
) do (
	If not exist %%a Set Office2013RT_NoPostSP1List=True
)

If "!ReadPreset!" == "True" goto Office2013RT_UpdateModeSelectSkip

If not "%Office2013RT_NoSP1List%" == "True" (
	cls
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %white%Select Office Update Options:%ef%
	echo.
	echo		1: %blue%No Updates%ef%
	echo.
	echo		2: %blue%Service Pack 1%ef%
	echo.
	If not "%Office2013RT_NoPostSP1List%" == "True" (
	echo		3: %blue%Service Pack 1 ^& Post Service Pack 1 Updates to %Office2013RT_UpdatedLast%%ef%
	echo.
	)
	echo		0: %red%Cancel Office Installation%ef%
	echo.
	Set /p Office2013RT_UpdateModeSelect=%white%Enter Selection: %ef%
	echo. %ef%
) else (
	goto SelectOfficeNoUpdate
)

:Office2013RT_UpdateModeSelectSkip

If "!Office2013RT_UpdateModeSelect!"=="1" goto SelectOfficeNoUpdate
If not "%Office2013RT_NoSP1List%" == "True" If "!Office2013RT_UpdateModeSelect!"=="2" goto SelectOfficeSP1
If not "%Office2013RT_NoPostSP1List%" == "True" If "!Office2013RT_UpdateModeSelect!"=="3" goto SelectOfficePostSP1
If "!Office2013RT_UpdateModeSelect!"=="0" goto SelectOfficeCancel

goto Office2013RT_UpdateModeSelect

:SelectOfficeNoUpdate
Set Office2013RT_InstallTime=5
goto Office2013RTComplete

:SelectOfficeSP1
Set Office2013RT_Update=True
Set Office2013RT_UpdateDescription= - Including Service Pack 1
Set Office2013RT_InstallTime=10
goto Office2013RTComplete

:SelectOfficePostSP1
Set Office2013RT_Update=True
Set Office2013RT_PostSP1=True
Set Office2013RT_UpdateDescription= - Including updates to %Office2013RT_UpdatedLast%
Set Office2013RT_InstallTime=30
goto Office2013RTComplete

:SelectOfficeCancel
Set Office2013RT_Install=False
Set Office2013RT_Update=False
Set Office2013RT_PostSP1=False
goto Office2013RTComplete

Goto Office2013RTComplete

REM ====== Office 2013 RT Info =========================================================================================================================================

:Office2013RTInfo

echo		%white%%ul%Office 2013 RT Home ^& Student Plus%ef%%white% - Installation will be completed after the Out of Box Experience has
echo		finished and the desktop is shown for the first time. Installation will take up to %Office2013RT_InstallTime% minutes with the
echo		options selected, interacting with the desktop before installation is complete is not recommended.%ef%
echo.

goto Office2013RTComplete

REM ====== Download Office 2013 RT =====================================================================================================================================

:Office2013RTDownload

echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Downloading Office 2013 RT Home ^& Student Plus Installation Files.%ef%
echo Please wait...
echo.

For %%d in (
	"%Office2013RT_Downloads%"
	"%Office2013RT_UpdateTmp%"
	"%Office2013RT_UpdateListTmp%"
) do (
	If not exist %%d md %%d 1> nul
)

REM ====== Check if Office already downloaded ==========================================================================================================================

If exist "%Office2013RT_Downloads%\!Office2013RT_Installer_FileName!" (
	echo %white%Installer found, skipping download.%ef%
	goto SkipOfficeInstallerDownload
)

REM ====== Download Office =============================================================================================================================================

If /i "%Office2013RT_Installer_TorrentIndex%" == "False" goto OfficeWget

If /i "%ArchiveOrgTorrent%" == "True" (
	netsh advfirewall firewall add rule name="Windows Media Builder - tget" dir=in action=allow program="%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" enable=yes 1> nul
	"%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" /1 /t "%Office2013RT_Installer_TorrentURL%" /o "%TmpPath%" /n
	Set TorrentClientStatus=!ErrorLevel!
	netsh advfirewall firewall delete rule name="Windows Media Builder - tget" program="%CD%\Bin\tget\%PROCESSOR_ARCHITECTURE%\tget.exe" 1> nul
)

If /i "%ArchiveOrgTorrent%" == "True" (
	If !TorrentClientStatus! EQU 0 (
		Move /y "%TmpPath%\%Office2013RT_Installer_TorrentDir%\%Office2013RT_Installer_FileName%" "%DownloadsPath%\Office\" 1> nul
		echo.
		goto SkipOfficeInstallerDownload
	) else (
		echo.
		echo %red%Error: Unable to download Office installer.%ef%
		echo %red%Error: !TorrentClientStatus!%ef%
		Set Office2013RT_Abort=True
		Goto Office2013RTError
	)
)

:OfficeWget

"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" "!Office2013RT_Installer_URL!" -P "%Office2013RT_Downloads%" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to download Office installer.%ef%
	echo %red%Wget Error: !ErrorLevel!%ef%
	Set Office2013RT_Abort=True
	Goto Office2013RTError
)

:SkipOfficeInstallerDownload

If not exist "%Office2013RT_Downloads%\!Office2013RT_LP_FileName!" (
	"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" "!Office2013RT_LP_URL!" -P "%Office2013RT_Downloads%" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
) else (
	echo %white%!Office2013RT_LP_Language! language pack found, skipping download.%ef%
)

If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to download Office language pack.%ef%
	echo %red%Wget Error: !ErrorLevel!%ef%
	Set Office2013RT_Abort=True
	Goto Office2013RTError
)

If "%Office2013RT_Update%" == "True" (

	For /F "usebackq tokens=*" %%A in (
		"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1Common%"
		"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListSP1%"
	) do (
		echo %%A>> "%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt"
	)
	Set Office2013RT_UpdateList="%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt"

	If "%Office2013RT_PostSP1%" == "True" (

		For /F "usebackq tokens=*" %%A in (
			"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1Common%"
			"%Office2013RT_DownloadLists%\%Office2013RT_UpdateListPostSP1%"
		) do (
			echo %%A>> "%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_Post_SP1.txt"
		)
	Set Office2013RT_UpdateList="%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_SP1.txt";"%Office2013RT_UpdateListTmp%\Office_2013_RT_HSP_Post_SP1.txt"
	)

	For %%a in (
		!Office2013RT_UpdateList!
	) do (
		"%CD%\Bin\wget\%PROCESSOR_ARCHITECTURE%\wget.exe" -i %%a -P "%Office2013RT_Downloads%\%%~na" -nc --no-check-certificate -q --show-progress --progress=bar:force:noscroll
		Set WgetErrorLevel=!ErrorLevel!
	)
)

If not "!WgetErrorLevel!" == "" If "!WgetErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to download Office updates.%ef%
	echo %red%Wget Error: !WgetErrorLevel!%ef%
	Set Office2013RT_Abort=True
	Goto Office2013RTError
)

Goto Office2013RTComplete

REM ====== Office 2013 RT Verify =======================================================================================================================================

:Office2013RTVerify
If /i "%SHA1Check%" == "True" (

	echo.
	echo %white%Verifying Installation Files.%ef%
	echo Please wait...
	echo.

	for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a

	For %%a in (
		%Office2013RT_Installer_SHA1%#"%Office2013RT_Downloads%\%Office2013RT_Installer_FileName%"
		%Office2013RT_LP_SHA1%#"%Office2013RT_Downloads%\%Office2013RT_LP_FileName%"
		%Office2013RT_XrMLZipSHA1%#"%Office2013RT_Source%\XrML\%Office2013RT_XrMLZip%"
	) do (
		For /f "tokens=1,2 delims=#" %%b in ("%%a") do (

			Set Office2013RT_FileSHA1=%%b
			Set Office2013RT_File=%%c
			Set Office2013RT_BrokenPath=%%~dpc%%~nc_Corrupt\!RenameTime:~0,14!

	 		For /f "delims=" %%d in ('%SystemRoot%\System32\certutil.exe -hashfile !Office2013RT_File! SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
				Set z=%%d
				Set Office2013RT_FileFoundSHA1=!z: =!
			)

			If not !Office2013RT_FileSHA1! equ !Office2013RT_FileFoundSHA1! (
				echo %red%File Bad: %%~nxc%ef%

				attrib -s -h -r /s /d "%%a" 1> nul

				If Not Exist "!Office2013RT_BrokenPath!\" md "!Office2013RT_BrokenPath!\" 1> nul
				Move /y !Office2013RT_File! "!Office2013RT_BrokenPath!\" 1> nul
				If exist !Office2013RT_File! (
					echo.
					echo %red%Error: Unable to move corrupt file...%ef%
					echo %red%!Office2013RT_File!%ef%
					Set Office2013RT_Abort=True
					goto Office2013RTComplete
				) else (
					echo Moved To: "!Office2013RT_BrokenPath!\"
				)
				
				If !Office2013RT_File! == "%Office2013RT_Source%\XrML\%Office2013RT_XrMLZip%" (
					echo.
					echo %red%Error: "%Office2013RT_XrMLZip%" cannot be replaced automatically, reinstall Media Builder.%ef%
					Set Office2013RT_Abort=True
					goto Office2013RTComplete
				)

				Set OfficeUpdate_Retry=True

			) else (
				echo %green%File OK: %%~nxc%ef%
			)
		)
	)

	If not "!OfficeUpdate_Retry!" == "True" If not "%Office2013RT_Update%" == "True" (
		echo.
		echo %white%Verified Office Files.%ef%
	)

	If not "%Office2013RT_Update%" == "True" If "!OfficeUpdate_Retry!" == "True" (
		echo.

		If "!OfficeUpdate_RetryCount!" == "1" (
			echo %red%Error: Failed to replace corrupt Office files.%ef%
			Set Office2013RT_Abort=True
			goto Office2013RTComplete
		) else (
			echo %white%Corrupt Office Files Found ^& Moved.%ef%
			echo.
			echo Attempting to replace corrupt files...

			If exist "%Office2013RT_Tmp%\" (
				attrib -s -h -r /s /d "%Office2013RT_Tmp%\*.*" > NUL 2>&1
				del "%Office2013RT_Tmp%\*.*" /F /Q /S > NUL 2>&1
				rmdir /Q /S "%Office2013RT_Tmp%" > NUL 2>&1
			)

			If exist "%Office2013RT_Tmp%\" (
				echo %red%Error: Failed to delete Office temporary files.%ef%
				Set Office2013RT_Abort=True
				goto Office2013RTComplete
			) else (
				Set OfficeUpdate_RetryCount=1
			)

		)
	)

)

REM ====== Check Office Updates SHA1 ===================================================================================================================================

If /i "%SHA1Check%" == "True" If "%Office2013RT_Update%" == "True" (

	echo.
	echo %white%Verifying Updates.%ef%
	echo Please wait...
	echo.

	for /f "tokens=1 delims= " %%a in ('powershell -c "$ErrorActionPreference='Stop'; [system.management.ManagementDateTimeConverter]::ToDmtfDateTime((Get-Date))"') Do Set RenameTime=%%a

	For %%i in (
		%Office2013RT_UpdateList%
	) do (

		Set OfficeUpdateListFileName=%%~ni
		Set OfficeUpdatePath=!Office2013RT_Downloads!\!OfficeUpdateListFileName!
		Set OfficeUpdatePathBroken=!OfficeUpdatePath!_Corrupt\!RenameTime:~0,14!

		For /F "usebackq tokens=*" %%b in (%%i) do (

			Set Office2013RT_UpdateURL=%%b
			For %%c in ("!Office2013RT_UpdateURL!") do (
				Set Office2013RT_UpdateFileName=%%~NXc
			)

			Set Office2013RT_UpdateFileNameList=!Office2013RT_UpdateFileNameList!;!Office2013RT_UpdateFileName!

		)

		For %%a in (!Office2013RT_UpdateFileNameList!) do (

			Attrib -a -r -s -h "%%a" 1> nul

			Set OfficeUpdate_FileName=%%~NXa
			For /f "tokens=1-3 delims=_." %%a in ("!OfficeUpdate_FileName!") do (
				Set OfficeUpdate_SHA1=%%b
			)

	 		For /f "delims=" %%d in ('%SystemRoot%\System32\certutil.exe -hashfile "!OfficeUpdatePath!\%%a" SHA1 ^| %SystemRoot%\System32\find.exe /v ":"') do (
				Set z=%%d
				Set OfficeUpdate_FileFoundSHA1=!z: =!
			)

			If /I not !OfficeUpdate_SHA1! equ !OfficeUpdate_FileFoundSHA1! (
				echo %red%File Bad: %%~nxa%ef%

				attrib -s -h -r /s /d "%%a" 1> nul

				If Not Exist "!OfficeUpdatePathBroken!\" md "!OfficeUpdatePathBroken!\" 1> nul
				Move /y "!OfficeUpdatePath!\%%a" "!OfficeUpdatePathBroken!\" 1> nul
				If exist "%%a" (
					echo.
					echo %red%Error: Unable to move corrupt update...%ef%
					echo %red%"%%a"%ef%
					Set Office2013RT_Abort=True
					goto Office2013RTComplete
				) else (
					echo Moved To: "!OfficeUpdatePathBroken!\"
				)

				Set OfficeUpdate_Retry=True
			) else (
				echo %green%File OK: %%~nxa%ef%
			)

		)

	Set Office2013RT_UpdateFileNameList=

	)

	If "!OfficeUpdate_Retry!" == "True" (
		echo.

		If "!OfficeUpdate_RetryCount!" == "1" (
			echo %red%Error: Failed to replace corrupt Office files.%ef%
			Set Office2013RT_Abort=True
			goto Office2013RTComplete
		) else (
			echo %white%Corrupt Office Files Found ^& Moved.%ef%
			echo.
			echo Attempting to replace corrupt files...

			If exist "%TmpPath%\Office\" (
				attrib -s -h -r /s /d "%TmpPath%\Office\*.*" > NUL 2>&1
				del "%TmpPath%\Office\*.*" /F /Q /S > NUL 2>&1
				rmdir /Q /S "%TmpPath%\Office" > NUL 2>&1
			)

			If exist "%TmpPath%\Office\" (
				echo %red%Error: Failed to delete Office temporary files.%ef%
				Set Office2013RT_Abort=True
				goto Office2013RTComplete
			) else (
				Set OfficeUpdate_RetryCount=1
			)

		)

	) else (
		echo.
		echo %white%Verified Office Files.%ef%
	)

)

Goto Office2013RTComplete

REM ====== Extract Office 2013 RT Updates ==============================================================================================================================

:Office2013RTUpdates

If "!OfficeUpdate_Retry!" == "True" goto Office2013RTComplete
If "!DownloadPreset!" == "True" goto Office2013RTComplete

Set Office2013RT_UpdatePrefix=100

rem echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
echo %white%Preparing Updates.%ef%
echo Please wait...
echo.

For %%a in (
	%Office2013RT_UpdateList%
) do (
	
	For /F "usebackq tokens=*" %%b in (%%a) do (

		Set Office2013RT_UpdateURL=%%b

		For %%c in ("!Office2013RT_UpdateURL!") do (
			Set Office2013RT_UpdateFileName=%%~NXc
		)

		Set Office2013RT_UpdateFileNameList=!Office2013RT_UpdateFileNameList!;!Office2013RT_UpdateFileName!

	)

	For %%d in (!Office2013RT_UpdateFileNameList!) do (

		For /f "tokens=1,2,3 delims=_." %%x in ("%%d") do (
			Set Office2013RT_UpdateFileNameStart=%%x
			Set Office2013RT_UpdateFileNameEnd=%%y
			Set Office2013RT_UpdateFileNameExt=%%z
		)
		
		"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%Office2013RT_Downloads%\%%~na\%%d" -o"%Office2013RT_UpdateTmp%" "!Office2013RT_UpdateFileNameStart!.msp" >nul 2>&1

		If "!ErrorLevel!" NEQ "0" (
			echo Failed to extract: %%d
			Set Office2013RT_Abort=True
			goto Office2013RTComplete
		) else (
			echo Extracted: %%d
			Rename "%Office2013RT_UpdateTmp%\!Office2013RT_UpdateFileNameStart!.msp" "!Office2013RT_UpdateFileNameStart!_!Office2013RT_UpdateFileNameEnd!.msp" 1> nul
		)

	)

	Set Office2013RT_UpdateFileNameList=
)

If not "%Office2013RT_Abort%" == "True" (
	echo.
	echo %white%Updates Prepared.%ef%
)

For /f "USEBACKQ delims=|" %%e in (`dir /b /od "%Office2013RT_UpdateTmp%\*.msp"`) do (
	Rename "%Office2013RT_UpdateTmp%\%%e" "!Office2013RT_UpdatePrefix!_%%e"
	Set /a Office2013RT_UpdatePrefix+=1
)

Goto Office2013RTComplete

REM ====== Copy Office 2013 RT =========================================================================================================================================

:Office2013RTCopy

echo.
echo %white%Extracting Office 2013 RT Home ^& Student Plus Installation Files.%ef%
echo.

For %%a in (
	"%Office2013RT_Destination%\Office_2013_RT\activation"
	"%Office2013RT_Destination%\Office_2013_RT\updates"
	"%Office2013RT_Destination%\Office_2013_RT\temp_lp"
	"%Office2013RT_Destination%\Office_2013_RT\temp_installer"
) do (
	If not exist %%a md %%a 1> nul
)

copy "%Office2013RT_Downloads%\%Office2013RT_Installer_FileName%" "%Office2013RT_Destination%\Office_2013_RT\temp_installer\%Office2013RT_Installer_FileName%" 1> nul
If not exist "%Office2013RT_Destination%\Office_2013_RT\temp_installer\%Office2013RT_Installer_FileName%" (
	echo %red%Error: Failed to copy Office 2013 RT Home ^& Student Plus.%ef%
) else (
	echo %green%Copied Office 2013 RT Home ^& Student Plus: %Office2013RT_Installer_FileName%%ef%
)

copy "%Office2013RT_Downloads%\%Office2013RT_LP_FileName%" "%Office2013RT_Destination%\Office_2013_RT\temp_lp\%Office2013RT_LP_FileName%" 1> nul
If not exist "%Office2013RT_Destination%\Office_2013_RT\temp_lp\%Office2013RT_LP_FileName%" (
	echo %red%Error: Failed to copy language pack.%ef%
) else (
	echo %green%Copied Language Pack: %Office2013RT_LP_FileName%%ef%
)

"%CD%\Bin\7z\%PROCESSOR_ARCHITECTURE%\7z.exe" x "%Office2013RT_Source%\XrML\%Office2013RT_XrMLZip%" -o"%Office2013RT_Destination%\Office_2013_RT\activation" "*.xrm-ms" > nul
If "!ErrorLevel!" NEQ "0" (
	echo %red%Error: Unable to extract XrML files.%ef%
) else (
	echo %green%Copied XrML Files: %Office2013RT_XrMLZip%%ef%
)

If "%Office2013RT_Update%" == "True" (
	Move /Y "%Office2013RT_UpdateTmp%\*.msp" "%Office2013RT_Destination%\Office_2013_RT\updates" 1> nul
	If "!ErrorLevel!" NEQ "0" (
		echo %red%Error Copying Updates: !ErrorLevel!%ef%
	) else (
		echo %green%Copied Office Updates.%ef%
	)
)

(
	echo ^<Configuration^>
	echo ^<Display Level="Basic" CompletionNotice="No" SuppressModal="Yes" AcceptEula="Yes" /^>
	echo ^<USERNAME Value="" /^>
	echo ^<USERINITIALS Value="" /^>
	echo ^<COMPANYNAME Value="" /^>
	echo ^<PIDKEY Value="" /^>
	echo ^<Setting Id="AUTO_ACTIVATE" Value="0" /^>
	echo ^<Setting Id="SETUP_REBOOT" Value="Never" /^>
	echo ^<INSTALLLOCATION Value="" /^>
	echo ^</Configuration^>
) > "%Office2013RT_Destination%\Office_2013_RT\Office_2013_RT_Config.xml"


(
	echo @echo off
	echo @setlocal enableextensions
	echo echo Do not close while installer preperation is in progress^^!
	echo echo.
	echo "%%systemdrive%%\Office_2013_RT\temp_installer\%Office2013RT_Installer_FileName%" /extract:"%%systemdrive%%\Office_2013_RT\temp_installer"
	echo echo.
	echo For %%%%a in ^(
	echo		catalog
	echo		homestudentpls.ww
	echo		updates
	echo		setup.exe
	echo		setup.dll
	echo		autorun.inf
	echo ^) do ^(
	echo		move /y "%%systemdrive%%\Office_2013_RT\temp_installer\%%%%a" "%%systemdrive%%\Office_2013_RT" 1^> nul
	echo ^)
	echo echo.
	echo "%%systemdrive%%\Office_2013_RT\temp_lp\%Office2013RT_LP_FileName%" /extract:"%%systemdrive%%\Office_2013_RT\temp_lp"
	echo echo.
	echo For %%%%b in ^(
	echo		excel
	echo		office
	echo		onenote
	echo		outlook
	echo		powerpoint
	echo		proofing
	echo		word
	echo		xmui
	echo		*.htm
	echo ^) do ^(
	echo		move /y "%%systemdrive%%\Office_2013_RT\temp_lp\%%%%b.%Office2013RT_LP_Tag%" "%%systemdrive%%\Office_2013_RT" 1^> nul
	echo ^)
	echo echo.
	echo exit
) > "%Office2013RT_Destination%\Office_2013_RT\Office_2013_RT_Installer.cmd"


(
	echo @echo off
	echo @setlocal enableextensions
	echo echo Do not close while license modification is in progress^^!
	echo echo.
	echo echo Removing Office 2013 RT Home ^^^& Student Plus Product Key
	echo slmgr /upk //b ebef9f05-5273-404a-9253-c5e252f50555
	echo echo.
	echo echo Installing License Files...
	echo echo.
	echo pushd "%%~dp0"
	echo for %%%%a in ^(*.xrm-ms^) do ^(
	echo 	echo %%%%~nxa
	echo 	slmgr //b /ilc %%%%~nxa
	echo 	^)
	echo popd
	echo echo.
If "%AltOfficeActivation%" == "True" (
	echo echo Entering Office 2013 Home ^^^& Business Retail Product Key
) else (
	echo echo Entering Office 2013 Standard Volume License Product Key
	echo slmgr /skms //b !KMS!
)
	echo slmgr /ipk //b %OfficeProductKey%
	echo slmgr /ato //b
	echo exit
) > "%Office2013RT_Destination%\Office_2013_RT\activation\Office_2013_RT_License.cmd"

(
	echo @echo off
	echo @setlocal enableextensions
	echo echo Do not close while cleanup is in progress^^!
	echo echo.
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Office15.HOMESTUDENTPLS" /t REG_DWORD /v "NoModify" /d 00000001 /f
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Office15.HOMESTUDENTPLS" /t REG_DWORD /v "SystemComponent" /d 00000000 /f
	echo For %%%%a in ^(
	echo		%%systemdrive%%\Office_2013_RT
rem	echo		%%systemdrive%%\MSOCache
	echo		%%systemdrive%%\Windows\Installer\$PatchCache$
	echo ^) do ^(
	echo		echo.
	echo		If exist "%%%%a\" ^(
	echo			attrib -s -h -r /s /d "%%%%a\*.*" ^> nul
	echo			del "%%%%a\*.*" /F /Q /S ^> nul
	echo			rmdir /Q /S "%%%%a\" ^> nul
	echo		^)
	echo ^)
	echo echo.
	echo del "%%systemdrive%%\Windows\Temp\Office_2013_RT_Cleanup.cmd" ^& exit
) > "%Office2013RT_Destination%\Windows\Temp\Office_2013_RT_Cleanup.cmd"

Goto Office2013RTComplete

REM ====== Office 2013 RT OOBE.cmd Commands ============================================================================================================================

:Office2013RTOOBE

	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99000" /VE /D "Microsoft Office 2013 RT (%Office2013RT_LP_Language%)" /f
	echo echo.
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99005" /VE /D " - Preparing Installation Files" /f
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99005" /V 1 /D "%%systemdrive%%\Office_2013_RT\Office_2013_RT_Installer.cmd" /f
	echo echo.
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99010" /VE /D " - Installing" /f
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99010" /V 1 /D "%%systemdrive%%\Office_2013_RT\setup.exe /config %%systemdrive%%\Office_2013_RT\Office_2013_RT_Config.xml"
	echo echo.
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99020" /VE /D " - Modifying License" /f
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99020" /V 1 /D "%%systemdrive%%\Office_2013_RT\activation\Office_2013_RT_License.cmd" /f
	echo echo.
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99030" /VE /D " - Cleanup" /f
	echo "%%systemroot%%\System32\reg.exe" add "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx\99030" /V 1 /D "%%systemdrive%%\Windows\Temp\Office_2013_RT_Cleanup.cmd" /f
	echo echo.

goto Office2013RTComplete

REM ====== Error =======================================================================================================================================================

:Office2013RTError

Set Office2013RT_Install=False
Set Office2013RT_Update=False
Set Office2013RT_FileMissing=True

goto Office2013RTComplete

REM ====== End =========================================================================================================================================================

:Office2013RTComplete

If "%OfficeStage%" == "" (
	echo This file is an addon for the Windows 10 Build 15035 Media Builder, it is not a separate Office installation package.
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "OfficeStage="