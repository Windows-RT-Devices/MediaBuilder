@echo off

REM ====== Set =========================================================================================================================================================

Set AppxStage=%1

If "%AppxStage%" == "" (
	goto AppxComplete
) else (
	goto %AppxStage%
)

REM ====== Appx Options ================================================================================================================================================

:AppxMenu

Set AppxList=%TmpPath%\AppxListFile.txt

Set AppxDest=%TmpPath%\Mount\install
Set AppxSource=%CD%\Addons\Appx\Apps
Set AppxStoreSource=%CD%\Addons\Appx\Store
Set DependencySource=%CD%\Addons\Appx\Dependency
Set AppxLicenseSource=%CD%\Addons\Appx\License

Set ModAppxSource=%CD%\Addons\Appx\Modified

Set AppxRegMod=True

For %%a in (
	"%CD%\Addons\Appx\Install_Appx_AllowAllTrustedApps.cmd"
	"%ModAppxSource%\Microsoft.MicrosoftStickyNotes_2.1.18.0_neutral_~_8wekyb3d8bbwe.appx"
	"%ModAppxSource%\Microsoft.MicrosoftStickyNotes_2.1.18.0_neutral_~_8wekyb3d8bbwe.cer"
	"%ModAppxSource%\Microsoft.MSPaint_4.1807.17017.1000_neutral_~_8wekyb3d8bbwe.appx"
	"%ModAppxSource%\Microsoft.MSPaint_4.1807.17017.1000_neutral_~_8wekyb3d8bbwe.cer"
	"%ModAppxSource%\Microsoft.Office.Excel_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.appx"
	"%ModAppxSource%\Microsoft.Office.Excel_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.cer"
	"%ModAppxSource%\Microsoft.Office.PowerPoint_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.appx"
	"%ModAppxSource%\Microsoft.Office.PowerPoint_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.cer"
	"%ModAppxSource%\Microsoft.Office.Word_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.appx"
	"%ModAppxSource%\Microsoft.Office.Word_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.cer"
	"%AppxStoreSource%\Microsoft.StorePurchaseApp_11808.1001.413.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxStoreSource%\Microsoft.WindowsStore_11803.1001.1113.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.BingFinance_4.26.12334.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.BingNews_4.25.11802.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.BingSports_4.25.11802.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.BingWeather_4.26.12153.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.DesktopAppInstaller_2019.1019.1.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.Getstarted_5.12.2691.2000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.Messaging_2018.124.707.1000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\microsoft.microsoftskydrive_17.30.3.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.MicrosoftSolitaireCollection_4.4.6132.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.NetworkSpeedTest_1.0.0.23_arm_~_8wekyb3d8bbwe.appx"
	"%AppxSource%\Microsoft.Office.OneNote_16001.11629.20028.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.Office.Sway_18.2003.51105.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.OfficeLens_16.0.32001.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.OfficeLens_16.0.32000.0_neutral_~_8wekyb3d8bbwe.Appxbundle"
	"%AppxSource%\Microsoft.People_2017.1006.1846.2000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.RemoteDesktop_10.1.1148.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.SkypeApp_12.1815.210.1000_neutral_~_kzf8qxf38zg5c.appxbundle"
	"%AppxSource%\Microsoft.SurfaceWirelessDisplayAdapter_3.4.137.1000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.Todos_1.48.21892.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.Whiteboard_52.10201.5809.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.Office.Whiteboard_19.10617.3824.0_neutral_~_8wekyb3d8bbwe.AppxBundle"
	"%AppxSource%\Microsoft.Windows.Photos_2017.35063.44410.1000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.WindowsAlarms_2017.510.2201.2000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.WindowsCalculator_2019.430.2124.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.WindowsCamera_2017.727.40.2000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\microsoft.windowscommunicationsapps_16005.11001.20116.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.WindowsFeedbackHub_2018.425.657.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.WindowsMaps_2017.519.1645.2000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.WindowsPhone_2018.131.1041.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.WindowsScan_2014.523.326.3026_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.WindowsSoundRecorder_2017.510.2143.2000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.XboxApp_48.89.25001.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.XboxIdentityProvider_2017.523.613.1000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.ZuneMusic_2019.18052.11111.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.ZuneVideo_2019.18052.10711.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.3DBuilder_14.1.1302.1000_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.Wallet_1.0.16328.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxSource%\Microsoft.XboxSpeechToTextOverlay_1.21.13002.0_neutral_~_8wekyb3d8bbwe.appxbundle"
	"%AppxLicenseSource%\microsoft.windowsscan_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.microsoftskydrive_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.microsoftpowerbiforwindows_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.office.whiteboard_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.office.word_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.office.powerpoint_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.office.excel_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.3dbuilder_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.bingweather_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.desktopappinstaller_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.getstarted_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.messaging_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.microsoft3dviewer_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.microsoftofficehub_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.microsoftsolitairecollection_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.microsoftstickynotes_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.mspaint_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.office.onenote_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.oneconnect_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.people_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.skypeapp_kzf8qxf38zg5c.xml"
	"%AppxLicenseSource%\microsoft.storepurchaseapp_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.wallet_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windows.photos_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windowsalarms_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windowscalculator_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windowscamera_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windowscommunicationsapps_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windowsfeedbackhub_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windowsmaps_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windowssoundrecorder_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.windowsstore_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.xboxapp_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.xboxgameoverlay_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.xboxidentityprovider_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.xboxspeechtotextoverlay_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.zunemusic_8wekyb3d8bbwe.xml"
	"%AppxLicenseSource%\microsoft.zunevideo_8wekyb3d8bbwe.xml"
	"%DependencySource%\Microsoft.Advertising.Xaml_10.1811.1.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Framework.1.3_1.3.24211.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Framework.1.7_1.7.27413.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Framework.2.1_2.1.27427.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Framework.2.2_2.2.29512.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Runtime.1.3_1.3.23901.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Runtime.1.4_1.4.24201.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Runtime.1.7_1.7.27422.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Runtime.2.1_2.1.26424.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.NET.Native.Runtime.2.2_2.2.28604.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.Services.Store.Engagement_10.0.19011.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.VCLibs.120.00.Universal_12.0.30501.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"%DependencySource%\Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If not exist %%a (
		Set UpdateAppx=False
		Set AppxFileMissing=True
		goto AppxComplete
	)
)

:AppxUpdateSelect

If "!ReadPreset!" == "True" goto SelectAppxMode
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
Set /p AppxUpdatePrompt=Would you like to install app pack (Y/N)? 
If /i "%AppxUpdatePrompt%"=="Y" Set UpdateAppx=True
If /i "%AppxUpdatePrompt%"=="N" Set UpdateAppx=False
If "%UpdateAppx%" == "" goto AppxUpdateSelect

:SelectAppxMode

Set AltApps=False
Set ModApps=False

Set CustomConfig=%CD%\Addons\Appx\Appx.cfg

If not exist "%CustomConfig%" (
	(
		echo AltApps=!AltApps!
		echo ModApps=!ModApps!
	) > "%CustomConfig%"
)

For /f "usebackq tokens=*" %%a in ("%CustomConfig%") do (
	For /f "tokens=1* delims==" %%a in ("%%a") do (
		If not "%%b" == "" Set "%%a=%%b"
	)
)

If "%UpdateAppx%" == "False" (
	goto AppxComplete
) else (
	If "!ReadPreset!" == "True" goto SkipAppxModeSelection
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %white%Select App Pack Options:%ef%
	echo.
	echo		1: %blue%Minimal%ef%
	echo.
	echo		Desktop App Installer, Store ^& Store Purchase App.
	echo.
	echo		2: %blue%Standard%ef%
	echo.
	echo		Alarms ^& Clock, Calculator, Calendar, Camera, Desktop App Installer, Groove Music, Mail, Maps,
	echo		Movies ^& TV, People, Photos, Remote Desktop, Store, Store Purchase App, ^& Voice Recorder.
	echo.
	echo		3: %blue%Complete%ef%
	echo.
	If "!ModApps!" == "True" (
	echo		3D Builder, Alarms ^& Clock, Calculator, Calendar, Camera, Desktop App Installer, Excel Mobile, Feedback 
	echo		Hub, Groove Music, Mail, Maps, Messaging, Solitaire Collection, To-Do, Whiteboard, Money, Movies ^& TV,
	echo		Network Speed Test, Office Lens, OneDrive, OneNote, Paint 3D, People, Phone Companion, Photos, PowerPoint 
	echo		Mobile, Remote Desktop, Scan, Skype, Sports, Store, Store Purchase App, News, Sticky Notes, Sway, Tips, 
	If "%Device%" == "Surface2" (
	echo		Voice Recorder, Weather, Wireless Display Adapter, Word Mobile ^& Xbox Console Companion.
	) else (
	echo		Voice Recorder, Weather, Word Mobile ^& Xbox Console Companion.
	)
	) else (
	echo		3D Builder, Alarms ^& Clock, Calculator, Calendar, Camera, Desktop App Installer, Feedback Hub, Groove 
	echo		Music, Mail, Maps, Messaging, Solitaire Collection, To-Do, Whiteboard, Money, Movies ^& TV, Network Speed
	echo		Test, Office Lens, OneDrive, OneNote, People, Phone Companion, Photos, Remote Desktop, Scan, Skype, Sports, 
	If "%Device%" == "Surface2" (
	echo		Store, Store Purchase App, News, Sway, Tips, Voice Recorder, Weather, Wireless Display Adapter ^& Xbox
	echo		Console Companion.
	) else (
	echo		Store, Store Purchase App, News, Sway, Tips, Voice Recorder, Weather ^& Xbox Console Companion.
	)
	)
	echo.
	echo		0: %red%Cancel App Pack Installation%ef%
	echo.

	Set /p AppxModeSelection=%white%Enter Selection: 
	echo. %ef%
	cls
	:SkipAppxModeSelection
	If "!AppxModeSelection!"=="1" goto AppxGroup1
	If "!AppxModeSelection!"=="2" goto AppxGroup2
	If "!AppxModeSelection!"=="3" goto AppxGroup3
	If "!AppxModeSelection!"=="0" goto AppxCancel
	goto SelectAppxMode

	:AppxGroup1
	Set AppxGroup1=True
	Set AppxGroup2=False
	Set AppxGroup3=False
	Set AppxUpdateLevel= - Minimal
	goto AppxComplete

	:AppxGroup2
	Set AppxGroup1=True
	Set AppxGroup2=True
	Set AppxGroup3=False
	Set AppxUpdateLevel= - Standard
	goto AppxComplete

	:AppxGroup3
	Set AppxGroup1=True
	Set AppxGroup2=True
	Set AppxGroup3=True
	Set AppxUpdateLevel= - Complete
	goto AppxComplete

	:AppxCancel
	Set UpdateAppx=False
	goto AppxComplete

)

goto AppxComplete

REM ====== Appx Info ===================================================================================================================================================

:AppxInfo

echo		%white%%ul%App Pack%ef%%white% - Not all apps are tested, some may be end-of-life or otherwise unreliable. Auto app update
echo		is disabled by default, if the Store is allowed to update itself to a version newer than that included
echo		it will not be able to install new apps from the store.%ef%
echo.

goto AppxComplete

REM ====== Appx OOBE ===================================================================================================================================================

:AppxOOBE

If "!AppxRegMod!" == "True" Call "%CD%\Addons\Appx\Install_Appx_AllowAllTrustedApps.cmd" AllowAllTrustedAppsOOBE

goto AppxComplete

REM ====== Install Appx ================================================================================================================================================

:AppxCopy

echo.
echo %white%Installing App Pack.%ef%

REM ====== Uninstall Old Apps ==========================================================================================================================================

For %%l in (
	"Microsoft.Microsoft3DViewer_1.1701.30049.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.XboxGameOverlay_1.13.27001.0_neutral_~_8wekyb3d8bbwe"
) do (
	If not "!AppxGroup3!"=="True" Set RemoveAppxList=!RemoveAppxList!;%%l
)

For %%l in (
	"Microsoft.Getstarted_4.5.6.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.Messaging_3.2.2001.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.People_2017.203.2255.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.StorePurchaseApp_1.0.454.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.WindowsAlarms_2017.203.236.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.WindowsCalculator_2017.131.1904.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.WindowsFeedbackHub_1.1611.3471.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.WindowsSoundRecorder_2017.130.1208.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.XboxApp_2017.113.1250.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.XboxIdentityProvider_2016.719.1035.0_neutral_~_8wekyb3d8bbwe"
	"Microsoft.XboxSpeechToTextOverlay_1.14.2002.0_neutral_~_8wekyb3d8bbwe"
) do (
	Set RemoveAppxList=!RemoveAppxList!;%%l
)

For %%b in (
	!RemoveAppxList!
) do (
	echo.
	echo %white%Removing Package: %%~nb%ef%
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%AppxDest%" /Remove-Provisionedappxpackage /PackageName:%%~b
	echo.
	If "!ErrorLevel!" NEQ "0" (
		echo %red%Error Removing Package: %%~nb%ef%
		echo %red%DISM Error: !ErrorLevel!%ef%
	) else (
		echo %green%Removed Package: %%~nb%ef%
	)
)

REM ====== Allow All Trusted Apps ======================================================================================================================================

If "!AppxRegMod!" == "True" Call "%CD%\Addons\Appx\Install_Appx_AllowAllTrustedApps.cmd" AllowAllTrustedApps

REM ====== Install Selected Apps =======================================================================================================================================

If Exist "%AppxList%" Del "%AppxList%" /F /Q 1> nul

For %%l in (
	"Microsoft.DesktopAppInstaller_2019.1019.1.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsStore_11803.1001.1113.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxStoreSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.3_1.3.24211.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.4_1.4.24201.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.StorePurchaseApp_11808.1001.413.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxStoreSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If /i "%AppxGroup1%" == "True" echo %%l>>"%AppxList%"
)

For %%l in (
	"Microsoft.windowscommunicationsapps_16005.11001.20116.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.Advertising.Xaml_10.1811.1.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.People_2017.1006.1846.2000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.Services.Store.Engagement_10.0.19011.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsMaps_2017.519.1645.2000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.3_1.3.24211.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.4_1.4.24201.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.ZuneVideo_2019.18052.10711.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.ZuneMusic_2019.18052.11111.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsSoundRecorder_2017.510.2143.2000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Windows.Photos_2017.35063.44410.1000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.3_1.3.24211.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.4_1.4.24201.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsCamera_2017.727.40.2000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsAlarms_2017.510.2201.2000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsCalculator_2019.430.2124.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.RemoteDesktop_10.1.1148.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.7_1.7.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.7_1.7.27422.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.Services.Store.Engagement_10.0.19011.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.120.00.Universal_12.0.30501.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If /i "%AppxGroup2%" == "True" echo %%l>>"%AppxList%"
)

For %%l in (
	"Microsoft.BingWeather_4.26.12153.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.Advertising.Xaml_10.1811.1.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingNews_4.25.11802.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.Advertising.Xaml_10.1811.1.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingFinance_4.26.12334.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.Advertising.Xaml_10.1811.1.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.BingSports_4.25.11802.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.Advertising.Xaml_10.1811.1.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Getstarted_5.12.2691.2000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Messaging_2018.124.707.1000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.microsoftskydrive_17.30.3.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.MicrosoftSolitaireCollection_4.4.6132.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.1.7_1.7.27422.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.7_1.7.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.NetworkSpeedTest_1.0.0.23_arm_~_8wekyb3d8bbwe.appx"#"AppxSource"#"True"#"False"#
	"Microsoft.Office.OneNote_16001.11629.20028.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Office.Sway_18.2003.51105.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.4_1.4.24201.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.SkypeApp_12.1815.210.1000_neutral_~_kzf8qxf38zg5c.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Todos_1.48.21892.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsFeedbackHub_2018.425.657.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsScan_2014.523.326.3026_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.120.00_12.0.21005.1_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.XboxApp_48.89.25001.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.7_1.7.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.7_1.7.27422.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.XboxIdentityProvider_2017.523.613.1000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.3_1.3.24211.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.3_1.3.23901.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.3DBuilder_14.1.1302.1000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Wallet_1.0.16328.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.3_1.3.24211.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.3_1.3.23901.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.XboxSpeechToTextOverlay_1.21.13002.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.WindowsPhone_2018.131.1041.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.6_1.6.27413.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.6_1.6.24903.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If /i "%AppxGroup3%" == "True" echo %%l>>"%AppxList%"
)

For %%l in (
	"Microsoft.SurfaceWirelessDisplayAdapter_3.4.137.1000_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.7_1.7.27422.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.1.7_1.7.27413.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If "%AppxGroup3%" == "True" If /i "%Device%" == "Surface2" echo %%l>>"%AppxList%"
)

For %%l in (
	"Microsoft.Office.Word_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.appx"#"ModAppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Office.PowerPoint_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.appx"#"ModAppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Office.Excel_16002.11629.20114.0_neutral_~_8wekyb3d8bbwe.appx"#"ModAppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.MicrosoftStickyNotes_2.1.18.0_neutral_~_8wekyb3d8bbwe.appx"#"ModAppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.7_1.7.27413.0_arm_~_8wekyb3d8bbwe.Appx,Microsoft.NET.Native.Runtime.1.7_1.7.27422.0_arm_~_8wekyb3d8bbwe.Appx,Microsoft.Services.Store.Engagement_10.0.19011.0_arm_~_8wekyb3d8bbwe.Appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.MSPaint_4.1807.17017.1000_neutral_~_8wekyb3d8bbwe.appx"#"ModAppxSource"#"True"#"False"#"Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If "%AppxGroup3%" == "True" If /i "!ModApps!" == "True" echo %%l>>"%AppxList%"
)

For %%l in (
	"Microsoft.OfficeLens_16.0.32000.0_neutral_~_8wekyb3d8bbwe.Appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.3_1.3.24211.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.4_1.4.24201.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Office.Whiteboard_19.10617.3824.0_neutral_~_8wekyb3d8bbwe.AppxBundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.2.1_2.1.26424.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.2.1_2.1.27427.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.Services.Store.Engagement_10.0.19011.0_arm_~_8wekyb3d8bbwe.Appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If "%AppxGroup3%" == "True" If /i "!AltApps!" == "True" echo %%l>>"%AppxList%"
)

For %%l in (
	"Microsoft.OfficeLens_16.0.32001.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Framework.1.3_1.3.24211.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Runtime.1.4_1.4.24201.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
	"Microsoft.Whiteboard_52.10201.5809.0_neutral_~_8wekyb3d8bbwe.appxbundle"#"AppxSource"#"True"#"False"#"Microsoft.NET.Native.Runtime.2.2_2.2.28604.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.NET.Native.Framework.2.2_2.2.29512.0_arm_~_8wekyb3d8bbwe.appx,Microsoft.VCLibs.140.00_14.0.30704.0_arm_~_8wekyb3d8bbwe.appx"
) do (
	If "%AppxGroup3%" == "True" If /i not "!AltApps!" == "True" echo %%l>>"%AppxList%"
)

For /f "usebackq tokens=1-5 delims=#" %%a in ("%AppxList%") do (
	echo.
	echo %white%Installing Package: %%~na%ef%
	Set AppxDependenciesList=
	For %%a in (%%~e) do (
		Set AppxDependenciesList=!AppxDependenciesList!/DependencyPackagePath:"%DependencySource%\%%a" 
	)

	If /i %%c == "True" Set AppxLicenseCommand=/SkipLicense
	If /i %%c == "False" Set AppxLicenseCommand=/LicensePath:"%AppxLicenseSource%\%%~d"
	start /b /wait "" "%DISMEXE%" /ScratchDir:"%TmpPath%\ScratchDir" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Image:"%AppxDest%" /Add-ProvisionedAppxPackage /PackagePath:"!%%~b!\%%~a" !AppxLicenseCommand! !AppxDependenciesList!
	echo.
	If "!ErrorLevel!" NEQ "0" (
		echo %red%Error Intsalling Package: %%~na%ef%
		echo %red%DISM Error: !ErrorLevel!%ef%
	) else (
		echo %green%Intsalled Package: %%~na%ef%
	)
)

If not exist "%AppxDest%\ProgramData\Microsoft\Windows\ClipSVC\Install\Apps\" md "%AppxDest%\ProgramData\Microsoft\Windows\ClipSVC\Install\Apps\" 1> nul
If exist "%AppxLicenseSource%" copy "%AppxLicenseSource%\*.xml" "%AppxDest%\ProgramData\Microsoft\Windows\ClipSVC\Install\Apps\" /b 1> nul

REM ====== Start Menu ==================================================================================================================================================

(
	echo ^<LayoutModificationTemplate xmlns:defaultlayout="http://schemas.microsoft.com/Start/2014/FullDefaultLayout" xmlns:start="http://schemas.microsoft.com/Start/2014/StartLayout" Version="1" xmlns="http://schemas.microsoft.com/Start/2014/LayoutModification"^>
If "%AppxGroup3%" == "True" (
	echo   ^<LayoutOptions StartTileGroupCellWidth="6" StartTileGroupsColumnCount="2" /^>
) else (
	echo   ^<LayoutOptions StartTileGroupCellWidth="6" StartTileGroupsColumnCount="1" /^>
)
	echo   ^<DefaultLayoutOverride^>
	echo     ^<StartLayoutCollection^>
	echo       ^<defaultlayout:StartLayout GroupCellWidth="6"^>

If "%AppxGroup1%" == "True" If "%AppxGroup2%" == "False" If "%AppxGroup3%" == "False" (
rem	echo         ^<start:Group Name="Explore"^>
	echo         ^<start:Group LocalizedNameResourceTag="TileGrid_DefaultGroup3"^>
	echo           ^<start:Tile Size="4x2" Column="0" Row="0" AppUserModelID="Microsoft.WindowsStore_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="2x2" Column="4" Row="0" AppUserModelID="Microsoft.MicrosoftEdge_8wekyb3d8bbwe^!MicrosoftEdge" /^>
	echo         ^</start:Group^>
)

If "%AppxGroup1%" == "True" If "%AppxGroup2%" == "True" If "%AppxGroup3%" == "False" (
rem	echo         ^<start:Group Name="Create"^>
	echo         ^<start:Group LocalizedNameResourceTag="TileGrid_DefaultGroup1"^>
	echo           ^<start:Tile Size="2x2" Column="0" Row="0" AppUserModelID="microsoft.windowscommunicationsapps_8wekyb3d8bbwe^!Microsoft.WindowsLive.Calendar" /^>
	echo           ^<start:Tile Size="4x2" Column="2" Row="0" AppUserModelID="microsoft.windowscommunicationsapps_8wekyb3d8bbwe^!microsoft.windowslive.mail" /^>
	echo         ^</start:Group^>
rem	echo         ^<start:Group Name="Play"^>
	echo         ^<start:Group LocalizedNameResourceTag="TileGrid_DefaultGroup2"^>
	echo           ^<start:Tile Size="1x1" Column="3" Row="1" AppUserModelID="Microsoft.WindowsMaps_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="1x1" Column="2" Row="0" AppUserModelID="Microsoft.ZuneVideo_8wekyb3d8bbwe^!Microsoft.ZuneVideo" /^>
	echo           ^<start:Tile Size="1x1" Column="3" Row="0" AppUserModelID="Microsoft.ZuneMusic_8wekyb3d8bbwe^!Microsoft.ZuneMusic" /^>
	echo           ^<start:Tile Size="1x1" Column="2" Row="1" AppUserModelID="Microsoft.WindowsSoundRecorder_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="2x2" Column="4" Row="0" AppUserModelID="Microsoft.Windows.Photos_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="2x2" Column="0" Row="0" AppUserModelID="Microsoft.WindowsCamera_8wekyb3d8bbwe^!App" /^>
	echo         ^</start:Group^>
rem	echo         ^<start:Group Name="Explore"^>
	echo         ^<start:Group LocalizedNameResourceTag="TileGrid_DefaultGroup3"^>
	echo           ^<start:Tile Size="4x2" Column="0" Row="0" AppUserModelID="Microsoft.WindowsStore_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="2x2" Column="4" Row="0" AppUserModelID="Microsoft.MicrosoftEdge_8wekyb3d8bbwe^!MicrosoftEdge" /^>
	echo         ^</start:Group^>
)

If "%AppxGroup1%" == "True" If "%AppxGroup2%" == "True" If "%AppxGroup3%" == "True" (
rem	echo         ^<start:Group Name="Create"^>
	echo         ^<start:Group LocalizedNameResourceTag="TileGrid_DefaultGroup1"^>
If "!ModApps!" == "True" (
	echo           ^<start:Tile Size="1x1" Column="5" Row="3" AppUserModelID="Microsoft.Office.OneNote_8wekyb3d8bbwe^!microsoft.onenoteim" /^>
	echo           ^<start:Tile Size="1x1" Column="4" Row="2" AppUserModelID="Microsoft.Office.Word_8wekyb3d8bbwe^!microsoft.word" /^>
	echo           ^<start:Tile Size="1x1" Column="5" Row="2" AppUserModelID="Microsoft.Office.PowerPoint_8wekyb3d8bbwe^!microsoft.pptim" /^>
	echo           ^<start:Tile Size="1x1" Column="4" Row="3" AppUserModelID="Microsoft.Office.Excel_8wekyb3d8bbwe^!microsoft.excel" /^>
) else (
	echo           ^<start:Tile Size="2x2" Column="4" Row="2" AppUserModelID="Microsoft.Office.OneNote_8wekyb3d8bbwe^!microsoft.onenoteim" /^>
)
	echo           ^<start:Tile Size="2x2" Column="0" Row="0" AppUserModelID="microsoft.windowscommunicationsapps_8wekyb3d8bbwe^!Microsoft.WindowsLive.Calendar" /^>
	echo           ^<start:Tile Size="4x2" Column="2" Row="0" AppUserModelID="microsoft.windowscommunicationsapps_8wekyb3d8bbwe^!Microsoft.WindowsLive.Mail" /^>
	echo           ^<start:Tile Size="2x2" Column="2" Row="2" AppUserModelID="Microsoft.OfficeLens_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="2x2" Column="0" Row="2" AppUserModelID="Microsoft.Office.Sway_8wekyb3d8bbwe^!Microsoft.Sway" /^>
	echo         ^</start:Group^>
rem	echo         ^<start:Group Name="Play"^>
	echo         ^<start:Group LocalizedNameResourceTag="TileGrid_DefaultGroup2"^>
	echo           ^<start:Tile Size="1x1" Column="3" Row="1" AppUserModelID="Microsoft.WindowsMaps_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="2x2" Column="0" Row="0" AppUserModelID="Microsoft.XboxApp_8wekyb3d8bbwe^!Microsoft.XboxApp" /^>
	echo           ^<start:Tile Size="1x1" Column="3" Row="0" AppUserModelID="Microsoft.ZuneMusic_8wekyb3d8bbwe^!Microsoft.ZuneMusic" /^>
	echo           ^<start:Tile Size="1x1" Column="2" Row="1" AppUserModelID="Microsoft.WindowsSoundRecorder_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="1x1" Column="2" Row="0" AppUserModelID="Microsoft.ZuneVideo_8wekyb3d8bbwe^!Microsoft.ZuneVideo" /^>
	echo           ^<start:Tile Size="2x2" Column="4" Row="0" AppUserModelID="Microsoft.Windows.Photos_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="2x2" Column="0" Row="2" AppUserModelID="Microsoft.WindowsCamera_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="4x2" Column="2" Row="2" AppUserModelID="Microsoft.MicrosoftSolitaireCollection_8wekyb3d8bbwe^!App" /^>
	echo         ^</start:Group^>
rem	echo         ^<start:Group Name="Explore"^>
	echo         ^<start:Group LocalizedNameResourceTag="TileGrid_DefaultGroup3"^>
	echo           ^<start:Tile Size="4x2" Column="0" Row="0" AppUserModelID="Microsoft.WindowsStore_8wekyb3d8bbwe^!App" /^>
	echo           ^<start:Tile Size="2x2" Column="4" Row="0" AppUserModelID="Microsoft.MicrosoftEdge_8wekyb3d8bbwe^!MicrosoftEdge" /^>
	echo         ^</start:Group^>
)

	echo       ^</defaultlayout:StartLayout^>
	echo     ^</StartLayoutCollection^>
	echo   ^</DefaultLayoutOverride^>
	echo ^</LayoutModificationTemplate^>
) > "%TmpPath%\LayoutModification.xml"

goto AppxComplete

REM ====== End =========================================================================================================================================================

:AppxComplete

If "%AppxStage%" == "" (
	echo This file is an addon for the Windows 10 Build 15035 Media Builder, it is not a separate app installation package.
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "AppxStage="