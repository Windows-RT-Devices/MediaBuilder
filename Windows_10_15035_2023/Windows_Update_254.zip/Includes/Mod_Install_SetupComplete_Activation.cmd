@echo off

REM ====== Set =========================================================================================================================================================

Set SetupCompleteActivationStage=%1

If "%SetupCompleteActivationStage%" == "" (
	goto ActivationComplete
) else (
	goto %SetupCompleteActivationStage%
)

REM ====== Activation Options ==========================================================================================================================================

:ActivationMenu

If "%AltWindowsActivation%" == "True" (
	Set WindowsActTypText=OEM:NONSLP
	If "%HWIDTicket%" == "True" (
		Set WindowsActTypPromptText= activate Windows when connected to the internet
		Set WindowsActTypText1=/HWID
		Set WindowsActInfoText=Activate Windows
	) else (
		Set WindowsActTypPromptText= set a Windows product key?
		Set WindowsActTypText1=
		Set WindowsActInfoText=Set Windows Product Key
	)
) else (
	Set WindowsActTypText=GVLK
	If "%KMS38%" == "True" (
		Set WindowsActTypPromptText= activate Windows using offline activation
		Set WindowsActTypText1=/KMS38
		Set WindowsActInfoText=Activate Windows
	) else (
		Set WindowsActTypPromptText= activate Windows when connected to the internet
		Set WindowsActTypText1=/KMS
		Set WindowsActInfoText=Activate Windows
	)
)

:ActLinkSelect
If "!ReadPreset!" == "True" goto ActivationComplete
echo %ul%________________________________________________________________________________________________________________________%ef%
echo.

Set /p ActLinkPrompt=Would you like to automatically!WindowsActTypPromptText! (!WindowsActTypText!!WindowsActTypText1!) (Y/N)? 
If /i "%ActLinkPrompt%"=="Y" Set ActLink=True
If /i "%ActLinkPrompt%"=="N" Set ActLink=False
If "%ActLink%" == "" goto ActLinkSelect

goto ActivationComplete

REM ====== Windows Activation ==========================================================================================================================================

:ActivationSetupComplete

	echo echo.
	echo REM ====== Activation =================================================================================================================================================
	echo echo Do not close while license modification is in progress^^!
	echo echo.
	echo echo Removing Windows Product Key
	echo slmgr /upk //b
	echo echo.
	echo echo Entering Windows Product Key
	echo slmgr /ipk //b %WindowsProductKey%
If "%AltWindowsActivation%" == "True" (
	If "%HWIDTicket%" == "True" (
		echo Set ActXMLPath=%%systemdrive%%\ProgramData\Microsoft\Windows\ClipSVC\GenuineTicket
		echo If not exist "%%ActXMLPath%%" md "%%ActXMLPath%%" ^> nul
		echo ^(
		echo echo ^^^<?xml version="1.0" encoding="UTF-8"?^^^>
		echo echo ^^^<genuineAuthorization xmlns="http://www.microsoft.com/DRM/SL/GenuineAuthorization/1.0"^^^>
		echo echo    ^^^<version^^^>1.0^^^</version^^^>
		echo echo    ^^^<genuineProperties origin="sppclient"^^^>
		echo echo        ^^^<properties^^^>SessionId=TwBTAE0AYQBqAG8AcgBWAGUAcgBzAGkAbwBuAD0ANQA7AE8AUwBNAGkAbgBvAHIAVgBlAHIAcwBpAG8AbgA9ADEAOwBPAFMAUABsAGEAdABmAG8AcgBtAEkAZAA9ADIAOwBQAFAAPQAwADsASAB3AGkAZAA9AEcAYQBtAGUAcgBzAEEAZwBhAGkAbgBzAHQAVwBlAGUAZAA7AFAAZgBuAD0ATQBpAGMAcgBvAHMAbwBmAHQALgBXAGkAbgBkAG8AdwBzAC4ANAAuAFgAMQA5AC0AOQA5ADYAOAAzAF8AOAB3AGUAawB5AGIAMwBkADgAYgBiAHcAZQA7AEQAbwB3AG4AbABlAHYAZQBsAEcAZQBuAHUAaQBuAGUAUwB0AGEAdABlAD0AMQA7AAAA;TimeStampClient=2022-10-11T23:56:07Z^^^</properties^^^>
	rem	echo echo        ^^^<properties^^^>OA3xOriginalProductId=;OA3xOriginalProductKey=;SessionId=TwBTAE0AYQBqAG8AcgBWAGUAcgBzAGkAbwBuAD0ANQA7AE8AUwBNAGkAbgBvAHIAVgBlAHIAcwBpAG8AbgA9ADEAOwBPAFMAUABsAGEAdABmAG8AcgBtAEkAZAA9ADIAOwBQAFAAPQAwADsAUABmAG4APQBNAGkAYwByAG8AcwBvAGYAdAAuAFcAaQBuAGQAbwB3AHMALgA0AC4AWAAxADkALQA5ADkANgA4ADMAXwA4AHcAZQBrAHkAYgAzAGQAOABiAGIAdwBlADsAUABLAGUAeQBJAEkARAA9ADQANgA1ADEANAA1ADIAMQA3ADEAMwAxADMAMQA0ADMAMAA0ADIANgA0ADMAMwA5ADQAOAAxADEAMQA3ADgANgAyADIANgA2ADIANAAyADAAMwAzADQANQA3ADIANgAwADMAMQAxADgAMQA5ADYANgA0ADcAMwA1ADIAOAAwADsAAAA=;TimeStampClient=2022-10-11T12:00:00Z^^^</properties^^^>
		echo echo        ^^^<signatures^^^>
		echo echo            ^^^<signature name="downlevelGTkey" method="rsa-sha256" key="BgIAAACkAABSU0ExAAgAAAEAAQARq+V11k+dvHMCaLWVCaSbeQNlOdWTLkkl0hdMh5V3YhLU2R4h0Jd+7k7qfZ4aIo4ussduwGgmyDRikj5L2R77GG2ciHk4i8siK8qg7frOU0KT5rEks3qVj38C3dS1wS6D67shBFrxPlOEP8+JlelgP7Gxmwdao7NF4LXZ3+KdbJ//9jkmN8iAOP0N2XzW0/cJp9P1q6hE7eeqc/3Qn3zMr0q1Dx7vstN98oV17hNYCwumOxxS1rH+3n7ap2JKRSelo8Jvi214jZLBL+hOtYaGpxs7zIL3ofpoaYy5g7pc/DaTvyfpJho5634jK7dXVFMpzJZMn9w0F/3rkquk0Amm"^^^>i1nx/uMFXzLlv+6/MhuTExaXYEa3w9tu7vofwbw5YGSPV5TztgbjEl6xiFSRF0mq5DAnLhQgAK60a/ZFxUQCBrRvKhHekWzNOvRGHZNTZNU2mrewP9sozPMZJyn2pmJVAOkCTTkfC8pBzUdoOXyumB6H/esmGlagvqpVFNL/XeaEmYxfnpQpI5oSzwUbe6W1d+xOzeNljTNj/7b9SVH8Ew0CzSqsI+YpNwOxO/vfGCIk3LJPH8aGqRe+d0JnB7UhfxVFZVBJ1LlOXR5hmYn0zyCCpRJ359zP8UhqnQtY+XlZcAauHI/lrQtyUdsKZLwCNm8vT8LCSlGHdtiC3b/CHw==^^^</signature^^^>
	rem	echo echo            ^^^<signature name="clientLockboxKey" method="rsa-sha256"^^^>HGNKjkKcKQHO6n8srMUrDh/MElffBZarLqCMD9rWtgFKf3YzYOLDPEMGhuO/auNMKCeiU7ebFbQALS/MyZ7TvidMQ2dvzXeXXKzPBjfwQx549WJUU7qAQ9Txg9cR9SAT8b12Pry2iBk+nZWD9VtHK3kOnEYkvp5WTCTsrSi6Re4=^^^</signature^^^>
		echo echo        ^^^</signatures^^^>
		echo echo    ^^^</genuineProperties^^^>
		echo echo ^^^</genuineAuthorization^^^>
		echo ^) ^> "%%ActXMLPath%%\Microsoft.Windows.4.X19-99683_8wekyb3d8bbwe.xml"
		echo %%systemdrive%%\Windows\System32\ClipUp.exe -v -o
	)
) else (
	If "%KMS38%" == "True" (
		echo Set ActXMLPath=%%systemdrive%%\ProgramData\Microsoft\Windows\ClipSVC\GenuineTicket
		echo If not exist "%%ActXMLPath%%" md "%%ActXMLPath%%" ^> nul
		echo ^(
		echo echo ^^^<?xml version="1.0" encoding="UTF-8"?^^^>
		echo echo ^^^<genuineAuthorization xmlns="http://www.microsoft.com/DRM/SL/GenuineAuthorization/1.0"^^^>
		echo echo    ^^^<version^^^>1.0^^^</version^^^>
		echo echo    ^^^<genuineProperties origin="sppclient"^^^>
		echo echo        ^^^<properties^^^>OA3xOriginalProductId=;OA3xOriginalProductKey=;SessionId=TwBTAE0AYQBqAG8AcgBWAGUAcgBzAGkAbwBuAD0ANQA7AE8AUwBNAGkAbgBvAHIAVgBlAHIAcwBpAG8AbgA9ADEAOwBPAFMAUABsAGEAdABmAG8AcgBtAEkAZAA9ADIAOwBQAFAAPQAwADsARwBWAEwASwBFAHgAcAA9ADIAMAAzADgALQAwADEALQAxADkAVAAwADMAOgAxADQAOgAwADcAWgA7AEQAbwB3AG4AbABlAHYAZQBsAEcAZQBuAHUAaQBuAGUAUwB0AGEAdABlAD0AMQA7AAAA;TimeStampClient=2022-10-11T12:00:00Z^^^</properties^^^>
		echo echo        ^^^<signatures^^^>
		echo echo            ^^^<signature method="rsa-sha256" name="clientLockboxKey"^^^>C52iGEoH+1VqzI6kEAqOhUyrWuEObnivzaVjyef8WqItVYd/xGDTZZ3bkxAI9hTpobPFNJyJx6a3uriXq3HVd7mlXfSUK9ydeoUdG4eqMeLwkxeb6jQWJzLOz41rFVSMtBL0e+ycCATebTaXS4uvFYaDHDdPw2lKY8ADj3MLgsA=^^^</signature^^^>
		echo echo        ^^^</signatures^^^>
		echo echo    ^^^</genuineProperties^^^>
		echo echo ^^^</genuineAuthorization^^^>
		echo ^) ^> "%%ActXMLPath%%\KMS.xml"
		echo %%systemdrive%%\Windows\System32\ClipUp.exe -v -o
	) else ( 
		echo slmgr /skms //b !KMS!
		echo slmgr /ato //b
	)
)

goto ActivationComplete

REM ====== End =========================================================================================================================================================

:ActivationComplete

If "%SetupCompleteActivationStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "SetupCompleteActivationStage="