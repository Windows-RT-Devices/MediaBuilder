@echo off

REM ====== Set =========================================================================================================================================================

Set ConfigStage=%1

If "%ConfigStage%" == "" (
	goto BuildConfigComplete
) else (

	If not exist "!CD!\Config" md "!CD!\Config" 1> nul
	Set MBConfig=!CD!\Config\Build_Config.cfg

	If exist "!MBConfig!" (
		Attrib -r -s -h "!MBConfig!" 1> nul
	)

	goto %ConfigStage%
)

:BuildConfig

REM ====== Write Build_Config.cfg if not found using the default values or read values from Build_Config.cfg if it is found ============================================

REM The values below are defaults if no Build_Config.cfg is found.

Set DownloadsFolderName=Downloads
Set DownloadsSpaceReq=6
Set OutputFolderName=Windows_Media
Set OutputFolderSpaceReq=12
Set TmpFolderName=Tmp
Set TmpFolderSpaceReq=24
Set TmpFolderPathLen=46

Set SysDriveSpaceReq=1

Set DownloadsPath=%CD%\%DownloadsFolderName%
Set OutputPath=%CD%\%OutputFolderName%
Set TmpPath=%CD%\%TmpFolderName%
Set BundledDISM=False
Set SkipOSCheck=False
Set MediaLabel=Win_10_ARM
Set USBInstallMediaFixedOnly=False
Set SHA1Check=True
Set OpenFolderISO=False
Set RecoveryMode=False
Set KMS=kms9.MSGuides.com
Set ExportBootWinREWIM=True
Set ExportInstallWIM=True
Set SkipServiceChecks=False
Set SkipDriveSpaceCheck=False
Set SkipDriveFileSystemCheck=False
Set SkipOOBE=False
Set WinToGo=False
Set WinToGoUseGPT=True
Set WinToGoDriveFixedOnly=False
Set ActivationBackupScript=True
Set ShowUSBCopyProgress=True
Set FileSource=A
Set OnlyUseLatestCLR=True
Set FODInstallIE=True
Set FODInstallDotNet35=False
Set InstallXPSPDFDrivers=True
Set DISMLogLevel=2
Set DISMLogPath=%CD%\DISM_Logs
Set DISMLogFile=Log-DISM
Set DISMLogFileExt=txt
Set CustomAddon=False
Set UseCMDColours=True
Set MBInfoLink=True
Set RunStartUpActions=True
Set UseTestVersion=False

Set DefaultWindowsProductKey=NPPR9-FWDCX-D2C8J-H872K-2YT43
Set WindowsProductKey=!DefaultWindowsProductKey!
Set DefaultOfficeProductKey=KBKQT-2NMXY-JJWGP-M62JB-92CD4
Set OfficeProductKey=!DefaultOfficeProductKey!

If "%TorrentClientFound%" == "True" Set ArchiveOrgTorrent=True

Set AltWindowsActivation=False
Set AltWindowsProductKey=XGVPP-NMH47-7TTHJ-W3FW7-8HV2C
Set AltOfficeActivation=False
Set AltOfficeProductKey=MNGCG-Q62BY-2V7R9-F64XX-KP8C3

Set HWIDTicket=False

Set KMS38=True

Set WindowsForceAltDownload=False
Set OfficeForceAltDownload=False
Set OfficeUpdateForceAltDownload=False
Set OfficeLangPackForceAltDownload=False

Set MediaBuilderInfoURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/mediabuilder
Set WindowsListsURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/Windows_10_15035_2023/Windows
Set OfficeListsURL=https://raw.githubusercontent.com/Windows-RT-Devices/MediaBuilder/main/Office_2013_RT_HSP_2023/Office

REM ====== Read / Write Build_Config.cfg ===============================================================================================================================

If not exist "%MBConfig%" (

	setlocal DisableDelayedExpansion
	(
		echo ###### Created by %~nx0 ######
		echo DownloadsPath=!CD!\%DownloadsFolderName%
		echo OutputPath=!CD!\%OutputFolderName%
		echo TmpPath=!CD!\%TmpFolderName%
		echo BundledDISM=%BundledDISM%
		echo SkipOSCheck=%SkipOSCheck%
		echo MediaLabel=%MediaLabel%
		echo USBInstallMediaFixedOnly=%USBInstallMediaFixedOnly%
		echo SHA1Check=%SHA1Check%
		echo OpenFolderISO=%OpenFolderISO%
		echo RecoveryMode=%RecoveryMode%
		echo KMS=%KMS%
		echo WindowsProductKey=%WindowsProductKey%
		echo OfficeProductKey=%OfficeProductKey%
		If "%TorrentClientFound%" == "True" echo ArchiveOrgTorrent=%ArchiveOrgTorrent%
		echo ExportBootWinREWIM=%ExportBootWinREWIM%
		echo ExportInstallWIM=%ExportInstallWIM%
		echo SkipServiceChecks=%SkipServiceChecks%
		echo SkipDriveSpaceCheck=%SkipDriveSpaceCheck%
		echo SkipDriveFileSystemCheck=%SkipDriveFileSystemCheck%
		echo SkipOOBE=%SkipOOBE%
		echo WinToGo=%WinToGo%
		echo WinToGoUseGPT=%WinToGoUseGPT%
		echo WinToGoDriveFixedOnly=%WinToGoDriveFixedOnly%
		echo ActivationBackupScript=%ActivationBackupScript%
		echo ShowUSBCopyProgress=%ShowUSBCopyProgress%
		echo OnlyUseLatestCLR=%OnlyUseLatestCLR%
		echo FODInstallIE=%FODInstallIE%
		echo FODInstallDotNet35=%FODInstallDotNet35%
		echo InstallXPSPDFDrivers=%InstallXPSPDFDrivers%
		echo DISMLogLevel=%DISMLogLevel%
		echo CustomAddon=%CustomAddon%
		echo UseCMDColours=%UseCMDColours%
		echo AltWindowsActivation=%AltWindowsActivation%
		echo AltOfficeActivation=%AltOfficeActivation%
		echo HWIDTicket=%HWIDTicket%
		echo KMS38=%KMS38%
		echo WindowsForceAltDownload=%WindowsForceAltDownload%
		echo OfficeForceAltDownload=%OfficeForceAltDownload%
		echo OfficeUpdateForceAltDownload=%OfficeUpdateForceAltDownload%
		echo OfficeLangPackForceAltDownload=%OfficeLangPackForceAltDownload%
		echo MBInfoLink=%MBInfoLink%
		echo RunStartUpActions=%RunStartUpActions%
		echo UseTestVersion=%UseTestVersion%
	) > "%MBConfig%"
	setlocal EnableDelayedExpansion

) else (

	For /f "usebackq skip=1 tokens=*" %%a in ("%MBConfig%") do (
		For /f "tokens=1* delims==" %%a in ("%%a") do (
			If not "%%b" == "" Set "%%a=%%b"
		)
	)

)

goto BuildConfigComplete

REM ====== Save Build_Config.cfg with current values ===================================================================================================================

:BuildSaveCurrentConfig

(
	echo ###### Created by %~nx0 ######

	If "%DownloadsPath%" == "!CD!\%DownloadsFolderName%" (
		setlocal DisableDelayedExpansion
		echo DownloadsPath=!CD!\%DownloadsFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo DownloadsPath=!DownloadsPath!
	)

	If "%OutputPath%" == "!CD!\%OutputFolderName%" (
		setlocal DisableDelayedExpansion
		echo OutputPath=!CD!\%OutputFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo OutputPath=!OutputPath!
	)

	If "%TmpPath%" == "!CD!\%TmpFolderName%" (
		setlocal DisableDelayedExpansion
		echo TmpPath=!CD!\%TmpFolderName%
		setlocal EnableDelayedExpansion
	) else (
		echo TmpPath=!TmpPath!
	)

rem	echo DownloadsPath=!DownloadsPath!
rem	echo OutputPath=!OutputPath!
rem	echo TmpPath=!TmpPath!
	echo BundledDISM=!BundledDISM!
	echo SkipOSCheck=!SkipOSCheck!
	echo MediaLabel=!MediaLabel!
	echo USBInstallMediaFixedOnly=!USBInstallMediaFixedOnly!
	echo SHA1Check=!SHA1Check!
	echo OpenFolderISO=!OpenFolderISO!
	echo RecoveryMode=!RecoveryMode!
	echo KMS=!KMS!
	echo WindowsProductKey=!WindowsProductKey!
	echo OfficeProductKey=!OfficeProductKey!
	If "%TorrentClientFound%" == "True" echo ArchiveOrgTorrent=!ArchiveOrgTorrent!
	echo ExportBootWinREWIM=!ExportBootWinREWIM!
	echo ExportInstallWIM=!ExportInstallWIM!
	echo SkipServiceChecks=!SkipServiceChecks!
	echo SkipDriveSpaceCheck=!SkipDriveSpaceCheck!
	echo SkipDriveFileSystemCheck=!SkipDriveFileSystemCheck!
	echo SkipOOBE=!SkipOOBE!
	echo WinToGo=!WinToGo!
	echo WinToGoUseGPT=!WinToGoUseGPT!
	echo WinToGoDriveFixedOnly=!WinToGoDriveFixedOnly!
	echo ActivationBackupScript=!ActivationBackupScript!
	echo ShowUSBCopyProgress=!ShowUSBCopyProgress!
	echo OnlyUseLatestCLR=!OnlyUseLatestCLR!
	echo FODInstallIE=!FODInstallIE!
	echo FODInstallDotNet35=!FODInstallDotNet35!
	echo InstallXPSPDFDrivers=!InstallXPSPDFDrivers!
	echo DISMLogLevel=!DISMLogLevel!
	echo CustomAddon=!CustomAddon!
	echo UseCMDColours=!UseCMDColours!
	echo AltWindowsActivation=!AltWindowsActivation!
	echo AltOfficeActivation=!AltOfficeActivation!
	echo HWIDTicket=!HWIDTicket!
	echo KMS38=!KMS38!
	echo WindowsForceAltDownload=!WindowsForceAltDownload!
	echo OfficeForceAltDownload=!OfficeForceAltDownload!
	echo OfficeUpdateForceAltDownload=!OfficeUpdateForceAltDownload!
	echo OfficeLangPackForceAltDownload=!OfficeLangPackForceAltDownload!
	echo MBInfoLink=!MBInfoLink!
	echo RunStartUpActions=!RunStartUpActions!
	echo UseTestVersion=!UseTestVersion!
) > "%MBConfig%"

goto BuildConfigComplete

REM ====== Set default Build_Config.cfg values =========================================================================================================================

:BuildSetDefault

If exist "%MBConfig%" (
	Del "%MBConfig%" /F /Q 1> nul
)

goto BuildConfig

REM ====== End =========================================================================================================================================================

:BuildConfigComplete

If "%ConfigStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "ConfigStage="