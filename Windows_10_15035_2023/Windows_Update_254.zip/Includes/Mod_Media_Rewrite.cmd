@echo off

REM ====== Set =========================================================================================================================================================

Set RewriteStage=%1

If "%RewriteStage%" == "" (
	goto Windows_Media_Select_Complete
) else (
	goto %RewriteStage%
)

REM ====== Rewrite =================================================================================================================================================

:Windows_Media_Select_Start
cls
Set Windows_Media_Selection=
Set /a Windows_Media_Number=1
Set Windows_Media=%OutputPath%

echo %ul%________________________________________________________________________________________________________________________%ef%
echo.
echo Please select installation files to write to USB/ISO (Listed newest to oldest by directory modification date):
echo.
If exist "%Windows_Media%" (

	For /f "USEBACKQ delims=|" %%f in (`dir "%Windows_Media%" /ad /o-d /b`) do (

		Set Windows_Media_Type=
		If exist "%Windows_Media%\%%f\setup.exe" (
			Set Windows_Media_Type=%magenta%Windows Setup%ef%
			For %%a in (esd swm wim) do (
				If Exist "%Windows_Media%\%%f\sources\install.%%a" Set Windows_Media_InstallWIM="%Windows_Media%\%%f\sources\install.%%a"
			)

			Set SetupMode=Setup
			Set OpenFolderOnly=False
		)
		If exist "%Windows_Media%\%%f\sources\ResetConfig.xml" (
			Set Windows_Media_Type=%blue%Windows Recovery Environment%ef%
			For %%a in (esd swm wim) do (
				If Exist "%Windows_Media%\%%f\sources\install.%%a" Set Windows_Media_InstallWIM="%Windows_Media%\%%f\sources\install.%%a"
			)

			Set SetupMode=WinRE
			Set OpenFolderOnly=False
		)
		If exist "%Windows_Media%\%%f\install.wim" (
			Set Windows_Media_Type=%white%WIM%ef%
			For %%a in (esd swm wim) do (
				If Exist "%Windows_Media%\%%f\install.%%a" Set Windows_Media_InstallWIM="%Windows_Media%\%%f\install.%%a"
			)

			Set SetupMode=WimOnly
			Set OpenFolderOnly=False
		)
		If exist "%Windows_Media%\%%f\Launch.cmd" (
			Set Windows_Media_Type=%red%QEMU Click-to-Run Package%ef%
			Set Windows_Media_InstallWIM=None
			Set SetupMode=None
			Set OpenFolderOnly=True
		)

		If exist "%Windows_Media%\%%f\logs\Info-Boot9600.txt" (
			Call "%CD%\Addons\WinRE9600\WinRE9600.cmd" WinRE9600MediaRewrite
		)

		If !Windows_Media_Number! EQU 21 (
			goto Windows_Media_Select
		)

		If not "!Windows_Media_Type!" == "" (
			echo		!Windows_Media_Number!: %%f ^(!Windows_Media_Type!^)
			Set Windows_Media_List=!Windows_Media_List!;!Windows_Media_Number!#"!Windows_Media!\%%f"#"%%f"#!SetupMode!#!Windows_Media_InstallWIM!#!OpenFolderOnly!
			Set /a Windows_Media_Number+=1
		)

	)

)

:Windows_Media_Select
If "!Windows_Media_List!" == "" (
	echo		   %white%No installation files found.%ef%
rem	echo.
rem	pause
	goto Windows_Media_Select_Complete
)
echo.
echo		C: %red%Cancel%ef%
echo.
Set /p Windows_Media_Selection=Select Media: 
If /i "!Windows_Media_Selection!" == "C" goto Windows_Media_Select_Complete

For %%i in (
	!Windows_Media_List!
) do (
	For /f "tokens=1-6 delims=#" %%a in ("%%i") do (
		If !Windows_Media_Selection! EQU %%a (
			Set MediaFolder=Windows_Media
			Set MediaFolderOutputPath=%%~b
			Set MediaFolderName=%%~c
			Set SetupMode=%%d
			Set MediaFolderInstallWIM=%%~e
			Set SkipWriteMedia=%%f
			Goto Windows_Media_Write
		)
	)
)
Set Windows_Media_Selection=
Goto Windows_Media_Select_Start

:Windows_Media_Write

If not "!SkipWriteMedia!" == "True" goto ContinueWrite

:OpenFolderSelect
echo %ef%%ul%________________________________________________________________________________________________________________________%ef%
echo.
echo The selected files are located at:
echo "%MediaFolderOutputPath%"
echo.
Set /p OpenFolderPrompt=Would you like to open this folder (Y/N)? 
If /i "%OpenFolderPrompt%"=="Y" Set OpenFolder=True
If /i "%OpenFolderPrompt%"=="N" Set OpenFolder=False
If "%OpenFolder%" == "" goto OpenFolderSelect

If "%OpenFolder%" == "True" (
	explorer.exe "%MediaFolderOutputPath%"
)

goto Windows_Media_Select_Complete

:ContinueWrite

For /f "tokens=*" %%F in ('dir /s /b /a:-d "%MediaFolderInstallWIM%"') do (

	Set Padding=000000000000000
	Set InstallWIMSize=!Padding!%%~zF
	Set InstallWIMMaxSize=!Padding!4294967296

	If /i "%%~xF" == ".esd" Set InstallESD=True

	If !InstallWIMSize:~-15! GEQ !InstallWIMMaxSize:~-15! (
		Set WimFAT32Warning=True
	)

)

If exist "%MediaFolderOutputPath%\logs\Info.txt" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	echo %white%Media Information File:%ef%
	echo.
	For /F "skip=1 usebackq tokens=*" %%a in (
		"%MediaFolderOutputPath%\logs\Info.txt"
	) do (
		Set InfoLine=%%a
		If "!InfoLine:~100,1!" == "" (
		echo 	!InfoLine:~0,100!
		) else (
		echo 	!InfoLine:~0,100!...
		)
	)
)

:Windows_Media_Confirm_Prompt
echo.
Set Windows_Media_Confirm=
Set /p Windows_Media_Confirm=Would you like to proceed (Y/N)? 
If /i "%Windows_Media_Confirm%" == "Y" (
	Call "%CD%\Includes\Mod_Media.cmd" MediaMenu %MediaLabel% "%MediaFolderOutputPath%"
	If exist "%CD%\Includes\Mod_WinToGo.cmd" Call "%CD%\Includes\Mod_WinToGo.cmd" WinToGoMenu "%MediaFolderOutputPath%" 10
rem	echo.
rem	pause
	goto Windows_Media_Select_Complete
)
If /i "%Windows_Media_Confirm%" == "N" goto Windows_Media_Select_Complete
goto Windows_Media_Confirm_Prompt

goto Windows_Media_Select_Complete

REM ====== End =========================================================================================================================================================

:Windows_Media_Select_Complete

If "%RewriteStage%" == "" (
	echo %ul%________________________________________________________________________________________________________________________%ef%
	echo.
	Echo Goodbye!
	pause
)

Set "RewriteStage="