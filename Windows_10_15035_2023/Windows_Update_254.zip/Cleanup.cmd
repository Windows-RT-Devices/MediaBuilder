@echo off
@setlocal enableextensions
@setlocal EnableDelayedExpansion

@Title Windows Media Builder Cleanup

REM ====== Network Drive/Share Check ===================================================================================================================================

If "%~d0" == "\\" (
	Set BuildAbort=True
)

"%SystemRoot%\System32\net.exe" use > NUL 2>&1
If "!ErrorLevel!" EQU "2" goto SkipMappedDriveCheck

"%SystemRoot%\System32\net.exe" use | "%SystemRoot%\System32\findstr.exe" /I /L /C:" %~d0 " >nul
If not "!ErrorLevel!" EQU "1" (
	Set BuildAbort=True
)

:SkipMappedDriveCheck

If "%BuildAbort%" == "True" (
	echo Error: Media Builder cannot be run from a mapped drive or network share.
	goto ExitNoTempClear
)

@cd /d "%~dp0"

REM ====== Check only one instance is running ==========================================================================================================================

9>&2 2>nul (call :LockAndRestoreStdErr %* 8>>"%~f0") || (
	echo Error: Only one instance allowed. >&2
)
goto Exit

:LockAndRestoreStdErr
call :SingleInstance %* 2>&9
exit /b 0

:SingleInstance

9>&2 2>nul (call :LockAndRestoreStdErr1 %* 8>>"!CD!\Build.cmd") || (
	echo Error: Only one instance allowed. >&2
)
goto Exit

:LockAndRestoreStdErr1
call :SingleInstance1 %* 2>&9
exit /b 0

:SingleInstance1

REM ====== Checks ======================================================================================================================================================

:Start
setlocal

Set SkipDriveCheckInt=True
Set CleanupOnly=True

If exist "%CD%\Includes\Build_Common.cmd" (
	echo Please Wait...
	Call "%CD%\Includes\Build_Common.cmd" BuildCommon %~nx0
) else (
	echo %red%Error: File Missing...%ef%
	echo "!CD!\Includes\Build_Common.cmd"
	BuildAbort=True
)

If "%BuildRestart%"=="True" (
	cls
	endlocal
	goto Start
)

If "%BuildAbort%"=="True" goto Exit

REM ====== Menu ========================================================================================================================================================
:Select
cls
Set "Action="
echo _____________________________
echo.
echo Windows Media Builder Cleanup
echo _____________________________
echo.
echo Select Action:	 1: Unmount Mounted WIM/VHD
echo			 2: Delete Temporary Files
echo			 3: Delete Windows Downloads
REM echo			 4: Delete Windows Update Downloads
echo			 5: Delete Office Downloads
echo			 6: Delete DISM Logs
echo.
echo			 9: Delete Windows Installation Media
echo.
echo			 E: Exit
echo.
set /p Action=Enter Selection: 
echo.

if /i "%Action%"=="E" goto Exit
if "%Action%"=="1" goto Unmount
if "%Action%"=="2" goto DeleteTempFiles
if "%Action%"=="3" goto DeleteWindowsDownloads
REM if "%Action%"=="4" goto DeleteWindowsUpdateDownloads
if "%Action%"=="5" goto DeleteOfficeDownloads
if "%Action%"=="6" goto DeleteDISMLogs
rem if "%Action%"=="8" goto CreateFolders
if "%Action%"=="9" goto DeleteUpdatedWindowsMedia
cls
goto Select

:Unmount
rem @echo on
start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\install" /discard
start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\boot" /discard
start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre" /discard
start /b /wait "" "%DISMEXE%" /LogPath:"%DISMLogPath%\%DISMLogCurrent%" /LogLevel:%DISMLogLevel% /Unmount-Wim /MountDir:"%TmpPath%\Mount\winre9600" /discard

Set QEMUDiskpartScript3="%Temp%\QEMUDiskpartScript3.txt"
(
	echo select vdisk file="%TmpPath%\QEMU\VHDTemp\%MediaLabel%.vhd"
	echo detach vdisk noerr
) > "!QEMUDiskpartScript3!"
diskpart /s !QEMUDiskpartScript3!

Set WinToGoDiskpartScript00="%Temp%\WinToGoDiskpartScript00.txt"
(
	echo select vdisk file="%TmpPath%\WTG\%MediaLabel%.vhd"
	echo detach vdisk noerr
) > !WinToGoDiskpartScript00!
diskpart /s !WinToGoDiskpartScript00!

rem @echo off
echo.
pause
cls
goto Start

:DeleteTempFiles
If not "%TmpPath%" == "" If exist "%TmpPath%\" (
	@echo on
	attrib -s -h -r /s /d "%TmpPath%\*.*"
	del "%TmpPath%\*.*" /F /Q /S
	rmdir /Q /S "%TmpPath%\"
	@echo off
)
echo.
pause
cls
goto Start

:DeleteWindowsDownloads
For %%d in (
	"!DownloadsPath!\Windows"
	"!DownloadsPath!\Windows_Corrupt"
) do (
	If not "%%~d" == "" If exist "%%~d" (
		@echo on
		attrib -s -h -r /s /d "%%~d\*.*"
		del "%%~d\*.*" /F /Q /S
		rmdir /Q /S "%%~d\"
		@echo off
	)
)
echo.
pause
cls
goto Start

:DeleteWindowsUpdateDownloads
For %%d in (
	"%DownloadsPath%\Windows_Updates_All"
	"%DownloadsPath%\Windows_Updates_Jailbreak_Safe_Longhorn"
	"%DownloadsPath%\Windows_Updates_Jailbreak_Safe_Myriachan"
	"%DownloadsPath%\Windows_Updates_Update_3"
	"%DownloadsPath%\Windows_Updates_Servicing_Stack"
	"%DownloadsPath%\Windows_Updates_All_Corrupt"
	"%DownloadsPath%\Windows_Updates_Jailbreak_Safe_Longhorn_Corrupt"
	"%DownloadsPath%\Windows_Updates_Jailbreak_Safe_Myriachan_Corrupt"
	"%DownloadsPath%\Windows_Updates_Update_3_Corrupt"
	"%DownloadsPath%\Windows_Updates_Servicing_Stack_Corrupt"
	"%DownloadsPath%\Windows_Updates_All_Unlisted"
	"%DownloadsPath%\Windows_Updates_Jailbreak_Safe_Longhorn_Unlisted"
	"%DownloadsPath%\Windows_Updates_Jailbreak_Safe_Myriachan_Unlisted"
	"%DownloadsPath%\Windows_Updates_Update_3_Unlisted"
	"%DownloadsPath%\Windows_Updates_Servicing_Stack_Unlisted"
) do (
	If not "%%~d" == "" If exist "%%~d" (
		@echo on
		attrib -s -h -r /s /d "%%~d\*.*"
		del "%%~d\*.*" /F /Q /S
		rmdir /Q /S "%%~d\"
		@echo off
	)
)
echo.
pause
cls
goto Start

:DeleteOfficeDownloads
If not "%DownloadsPath%" == "" If exist "%DownloadsPath%" (
	@echo on
	attrib -s -h -r /s /d "%DownloadsPath%\Office\*.*"
	del "%DownloadsPath%\Office\*.*" /F /Q /S
	rmdir /Q /S "%DownloadsPath%\Office\"
	@echo off
)
echo.
pause
cls
goto Start

:DeleteDISMLogs
If not "%DISMLogPath%" == "" If exist "%DISMLogPath%" (
	@echo on
	attrib -s -h -r /s /d "%DISMLogPath%\*.*"
	del "%DISMLogPath%\*.*" /F /Q /S
	rmdir /Q /S "%DISMLogPath%\"
	@echo off
)
echo.
pause
cls
goto Start

:CreateFolders
If not "%DownloadsPath%" == "" If exist "%DownloadsPath%" (
	@echo on
	If not exist "%DownloadsPath%\Windows\" md "%DownloadsPath%\Windows\"
	If not exist "%DownloadsPath%\Office\" md "%DownloadsPath%\Office\"
	@echo off
)
echo.
pause
cls
goto Start

:DeleteUpdatedWindowsMedia
If not "%OutputPath%" == "" If exist "%OutputPath%" (
	@echo on
	attrib -s -h -r /s /d "%OutputPath%\*.*"
	del "%OutputPath%\*.*" /F /Q /S
	rmdir /Q /S "%OutputPath%\"
	@echo off
)
echo.
pause
cls
goto Start

:Exit
echo ________________________________________________________________________________________________________________________
echo.
Echo Goodbye^^!
pause
Exit